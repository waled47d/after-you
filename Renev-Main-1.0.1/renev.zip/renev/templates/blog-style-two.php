<?php
/**
 * @Packge     : Renev
 * @Version    : 1.0
 * @Author     : Mthemeus
 * @Author URI : https://www.mthemeus.com/
 *
 */

// Block direct access
if ( ! defined( 'ABSPATH' ) ) {
    exit;
}

echo '<!-- Single Post -->';
?>
<div <?php post_class(); ?> >
<?php

    echo '<div class="vl-blog-1-item">';
        // Blog Post Content
        do_action( 'renev_blog_post_thumb' );

        // Blog Post Meta
        // do_action( 'renev_blog_post_meta' );
        
        // Excerpt And Read More Button
        do_action( 'renev_blog_post_content' );

    echo '</div>';

echo '</div>';
echo '<!-- End Single Post -->';