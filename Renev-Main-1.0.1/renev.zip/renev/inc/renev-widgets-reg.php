<?php
/**
 * @Packge     : Renev
 * @Version    : 1.0
 * @Author     : Mthemeus
 * @Author URI : https://www.mthemeus.com/
 *
 */


// Block direct access
if( !defined( 'ABSPATH' ) ){
    exit;
}

function renev_widgets_init() {

    //sidebar widgets register
    register_sidebar( array(
        'name'          => esc_html__( 'Blog Sidebar', 'renev' ),
        'id'            => 'renev-blog-sidebar',
        'description'   => esc_html__( 'Add Blog Sidebar Widgets Here.', 'renev' ),
        'before_widget' => '<div id="%1$s" class="search-area %2$s">',
        'after_widget'  => '</div>',
        'before_title'  => '<h3 class="widget-title">',
        'after_title'   => '</h3>',
    ) );    

    // page sidebar widgets register
    register_sidebar( array(
        'name'          => esc_html__( 'Page Sidebar', 'renev' ),
        'id'            => 'renev-page-sidebar',
        'description'   => esc_html__( 'Add Page Sidebar Widgets Here.', 'renev' ),
        'before_widget' => '<div id="%1$s" class="widget %2$s">',
        'after_widget'  => '</div>',
        'before_title'  => '<h3 class="widget_title">',
        'after_title'   => '</h3>',
    ) );

}

add_action( 'widgets_init', 'renev_widgets_init' );