<div class="portfolio-slider2-boxarea owl-carousel">
    <?php 
        // Set up the query to fetch posts
        $number_of_post = !empty($settings['post_per_page']) ? $settings['post_per_page'] : -1;

        $query_args = [
            'post_type'      => 'renev_project',
            'order'          => $settings['order'],
            'posts_per_page' => $number_of_post,
            'post_status'    => 'publish',
        ];

        if (!empty($settings['project_category'])) {
            $query_args['tax_query'] = [
                [
                    'taxonomy' => 'project_category',
                    'field'    => 'slug',
                    'terms'    => $settings['project_category'],
                ],
            ];
        }
        if ('selected' === $settings['post_by'] && !empty($settings['post__in'])) {
            $query_args['post__in'] = (array) $settings['post__in'];
        }
        // Create a new WP_Query
        $args = new \WP_Query($query_args);

        if ($args->have_posts()):
            while ($args->have_posts()): $args->the_post(); 
            $categories = get_the_terms(get_the_ID(), 'project_category');
        ?>

        <div class="portfolio-boxarea border-nane">
            <?php if( has_post_thumbnail() ): ?>
                <div class="img1">
                    <?php the_post_thumbnail('full');?>
                </div>
            <?php endif; ?>
            <div class="content-area">
                <div class="content">
                    <a href="<?php the_permalink(); ?>">
                        <?php the_title(); ?>
                    </a>
                    <?php the_excerpt(); ?>
                </div>
                <div class="arrow">
                    <a href="<?php the_permalink(); ?>">
                        <?php \Elementor\Icons_Manager::render_icon( $settings['project_arrow_icon'], [ 'aria-hidden' => 'true' ] ); ?>
                    </a>
                </div>
            </div>
        </div>
    <?php 
        endwhile; 
        wp_reset_postdata();
        endif; 
    ?>
 </div>