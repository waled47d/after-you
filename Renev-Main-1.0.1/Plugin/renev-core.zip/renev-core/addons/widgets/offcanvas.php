<?php
use \Elementor\Widget_Base;
use \Elementor\Controls_Manager;
use \Elementor\Group_Control_Typography;
use \Elementor\Group_Control_Text_Shadow;
use \Elementor\Group_Control_Border;
use \Elementor\Group_Control_Box_Shadow;
use \Elementor\Repeater;
use \Elementor\Utils;
/**
 *
 * Renev Search Widget .
 *
 */
class Renev_Offcanvas extends Widget_Base {

	public function get_name() {
		return 'renev_offcanvas';
	}

	public function get_title() {
		return __( 'Renev Offcanvas', 'renev' );
	}

	public function get_icon() {
		return 'eicon-code';
    }

	public function get_categories() {
		return [ 'renev' ];
	}

	protected function register_controls() {

        $this->start_controls_section(
            'content_section',
            [
                'label' => __('Content', 'renev'),
                'tab'   => Controls_Manager::TAB_CONTENT,
            ]
        );
        $this->add_control(
            'renev_offcanvas_builder',
            [
                'label'     => __( 'Select Offcanvas', 'renev' ),
                'type'      => Controls_Manager::SELECT,
                'options'   => $this->renev_offcanvas_one(),
                'default'	=> '',
            ]
        );
        $this->add_control(
            'bars_icon',
            [
                'label'   => __( 'Bars Icon', 'renev' ),
                'type'    => Controls_Manager::MEDIA,
                'default' => [
                    
                ],
            ]
        );
        $this->end_controls_section();
        //Offcanvas Style
        $this->start_controls_section(
            'offcanvas_style',
            [
                'label' => __( 'Offcanvas', 'renev' ),
                'tab'   => Controls_Manager::TAB_STYLE,
            ]
        );
        $this->add_responsive_control(
            'offcanvas_width',
            [
                'label' => esc_html__( 'Search width', 'renev' ),
                'type' => Controls_Manager::SLIDER,
                'size_units' => [ 'px', '%', 'em', 'rem' ],
                'range' => [
                    'px' => [
                        'min' => 0,
                        'max' => 1000,
                        'step' => 1,
                    ],
                    '%' => [
                        'min' => 0,
                        'max' => 100,
                    ],
                    'em' => [
                        'min' => 0,
                        'max' => 50,
                    ],
                    'rem' => [
                        'min' => 0,
                        'max' => 50,
                    ],
                ],
                'selectors' => [
                    '{{WRAPPER}} .homepage1-menu .vl-hero-btn button img' => 'width: {{SIZE}}{{UNIT}};',
                ],
            ]
        );   
        $this->add_responsive_control(
            'offcanvas_margin',
            [
                'label' => __( 'Margin', 'renev' ),
                'type' => Controls_Manager::DIMENSIONS,
                'size_units' => [ 'px', 'em', '%' ],
                'selectors' => [
                    '{{WRAPPER}} .homepage1-menu .vl-hero-btn button' => 'margin: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
                ],
            ]
        );
         //Offcanvas Close Style
         $this->add_responsive_control(
            'offcanvas_close_width',
            [
                'label' => esc_html__( 'Close Width', 'renev' ),
                'type' => Controls_Manager::SLIDER,
                'size_units' => [ 'px', '%', 'em', 'rem' ],
                'range' => [
                    'px' => [
                        'min' => 0,
                        'max' => 1000,
                        'step' => 1,
                    ],
                    '%' => [
                        'min' => 0,
                        'max' => 100,
                    ],
                    'em' => [
                        'min' => 0,
                        'max' => 50,
                    ],
                    'rem' => [
                        'min' => 0,
                        'max' => 50,
                    ],
                ],
                'selectors' => [
                    '{{WRAPPER}} .header-site-icon .slide-bar.slide-bar1 .sidebar-info .sidebar-logo .close-mobile-menu a' => 'width: {{SIZE}}{{UNIT}};',
                ],
            ]
        );   
        $this->add_responsive_control(
            'offcanvas_close_height',
            [
                'label' => esc_html__( 'Close Height', 'renev' ),
                'type' => Controls_Manager::SLIDER,
                'size_units' => [ 'px', '%', 'em', 'rem' ],
                'range' => [
                    'px' => [
                        'min' => 0,
                        'max' => 1000,
                        'step' => 1,
                    ],
                    '%' => [
                        'min' => 0,
                        'max' => 100,
                    ],
                    'em' => [
                        'min' => 0,
                        'max' => 50,
                    ],
                    'rem' => [
                        'min' => 0,
                        'max' => 50,
                    ],
                ],
                'selectors' => [
                    '{{WRAPPER}} .header-site-icon .slide-bar.slide-bar1 .sidebar-info .sidebar-logo .close-mobile-menu a' => 'height: {{SIZE}}{{UNIT}};',
                ],
            ]
        );   
        $this->add_control(
            'offcanvas_close-bg',
            [
                'label' => __( 'Close Background', 'renev' ),
                'type' => Controls_Manager::COLOR,
                'selectors' => [
                    '{{WRAPPER}} .header-site-icon .slide-bar.slide-bar1 .sidebar-info .sidebar-logo .close-mobile-menu a' => 'background: {{VALUE}}',
                ],
            ]
        ); 
        $this->add_responsive_control(
            'offcanvas_font_size',
            [
                'label' => esc_html__('Close Font Size', 'renev'),
                'type' => \Elementor\Controls_Manager::SLIDER,
                'size_units' => ['px', 'em', 'rem'],
                'range' => [
                    'px' => [
                        'min' => 10,
                        'max' => 40,
                    ],
                    'em' => [
                        'min' => 0.5,
                        'max' => 3,
                    ],
                ],
                'selectors' => [
                    '{{WRAPPER}} .header-site-icon .slide-bar.slide-bar1 .sidebar-info .sidebar-logo .close-mobile-menu a' => 'font-size: {{SIZE}}{{UNIT}};',
                ],
            ]
        );
        $this->add_control(
            'offcanvas_close_font_color',
            [
                'label' => __( 'Close Font Color', 'renev' ),
                'type' => Controls_Manager::COLOR,
                'selectors' => [
                    '{{WRAPPER}} .header-site-icon .slide-bar.slide-bar1 .sidebar-info .sidebar-logo .close-mobile-menu a' => 'color: {{VALUE}}',
                ],
            ]
        );
        $this->end_controls_section();
    }

     // Offcanvas Public function
     public function renev_offcanvas_one(){

        $renev_post_query = new \WP_Query( array(
            'post_type'				=> 'renev_off_build',
            'posts_per_page'	    => -1,
        ) );

        $renev_tab_builder_title_title = array();
        $renev_tab_builder_title_title[''] = __( 'Select a Title','renev');

        while( $renev_post_query->have_posts() ) {
            $renev_post_query->the_post();
            $renev_tab_builder_title_title[ get_the_ID() ] =  get_the_title();
        }
        wp_reset_postdata();
        return $renev_tab_builder_title_title;
    }

 
    // Render
	protected function render() {
        $settings = $this->get_settings_for_display();
        
        ?>
        <header class="homepage1-menu">
            <div class="vl-hero-btn d-none d-lg-block text-end">
                <button class="hamburger_menu">
                    <img src="<?php echo esc_url( $settings['bars_icon']['url'] ); ?>" alt="">
                </button>
            </div>
        </header>
        <div class="header-site-icon">
            <div class="slide-bar slide-bar1">
                <div class="sidebar-info">
                    <div class="sidebar-logo">
                        <?php  $elementor = \Elementor\Plugin::instance();
                            echo $elementor->frontend->get_builder_content_for_display($settings['renev_offcanvas_builder']); 
                        ?>
                        <div class="close-mobile-menu">
                            <a><i class="fa-solid fa-xmark"></i></a>
                        </div>
                    </div>
                </div>
            </div>
            <div class="body-overlay"></div>
            </div>
        <?php
    }
}
$widgets_manager->register( new \Renev_Offcanvas() );