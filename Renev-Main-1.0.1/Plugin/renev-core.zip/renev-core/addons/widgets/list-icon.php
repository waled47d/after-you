<?php
use \Elementor\Widget_Base;
use \Elementor\Controls_Manager;
use \Elementor\Group_Control_Typography;
use \Elementor\Group_Control_Text_Shadow;
use \Elementor\Group_Control_Border;
use \Elementor\Group_Control_Box_Shadow;
use \Elementor\Repeater;
use \Elementor\Utils;
/**
 *
 * Renev LIst ICon Widget .
 *
 */
class Renev_List_Icon extends Widget_Base {

	public function get_name() {
		return 'renev_list_icon';
	}

	public function get_title() {
		return __( 'Renev List Icon', 'renev' );
	}

	public function get_icon() {
		return 'eicon-code';
    }

	public function get_categories() {
		return [ 'renev' ];
	}

	protected function register_controls() {

        $this->start_controls_section(
            'content_section',
            [
                'label' => __('Content', 'renev'),
                'tab'   => Controls_Manager::TAB_CONTENT,
            ]
        );
        $repeater = new Repeater();

        $repeater->add_control(
			'list_title',
			[
				'label'       => esc_html__( 'List Iteam', 'renev' ),
				'type'        => Controls_Manager::TEXT,
				'label_block' => true,
				'default'     => esc_html__( 'Finance Consultant', 'renev' ),
			]
		);

        $this->add_control(
            'iteams',
            [
                'label'       => __( 'Iteam List', 'renev' ),
                'type'        => Controls_Manager::REPEATER,
                'fields'      => $repeater->get_controls(),
                'default'     => [
                ],
            ]
        );
        $this->end_controls_section();

         //List Style
         $this->start_controls_section(
            'list_section',
            [
                'label' => __( 'List Section', 'renev' ),
                'tab' => Controls_Manager::TAB_STYLE,
            ]
        );
        $this->add_control(
            'list_margin',
            [
                'label'      => __( 'Margin', 'renev' ),
                'type'       => Controls_Manager::DIMENSIONS,
                'size_units' => [ 'px', '%', 'em' ],
                'selectors'  => [
                    '{{WRAPPER}} .project-details-section-area .list-area li' => 'margin: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
                ],
            ]
        );   
       $this->add_control(
            'list_color',
            [
                'label' => __( 'List Color', 'renev' ),
                'type' => Controls_Manager::COLOR,
                'selectors' => [
                    '{{WRAPPER}} .project-details-section-area .list-area li a' => 'color: {{VALUE}} !important',
                ],
            ]
        );
        $this->add_control(
            'list_hover_color',
            [
                'label' => __( 'List Hover Color', 'renev' ),
                'type' => Controls_Manager::COLOR,
                'selectors' => [
                    '{{WRAPPER}} .project-details-section-area .list-area li a:hover' => 'color: {{VALUE}} !important',
                ],
            ]
        );
        $this->add_group_control(
            Group_Control_Typography::get_type(),
            [
                'name' => 'list_typography',
                'label' => __( 'Typography', 'renev' ),
                'selector' => '{{WRAPPER}} .project-details-section-area .list-area li a',
            ]
        );
      
        $this->add_responsive_control(
            'list_radius',
            [
                'label'         => __( 'Border Radius', 'renev' ),
                'type'          => Controls_Manager::DIMENSIONS,
                'size_units'    => [ 'px', '%', 'em' ],
                'selectors'     => [
                    '{{WRAPPER}} .project-details-section-area .list-area li a' => 'border-radius: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
                ],
            ]
        );
        $this->add_control(
            'list_background',
            [
                'label' => __( 'Background', 'renev' ),
                'type' => Controls_Manager::COLOR,
                'selectors' => [
                    '{{WRAPPER}} .project-details-section-area .list-area li a' => 'background: {{VALUE}}',
                ],
            ]
        ); 
        $this->add_control(
            'list_hover_background',
            [
                'label' => __( 'Background Hover', 'renev' ),
                'type' => Controls_Manager::COLOR,
                'selectors' => [
                    '{{WRAPPER}} .project-details-section-area .list-area li a:hover' => 'background: {{VALUE}}',
                ],
            ]
        ); 
        $this->end_controls_section();

        }

    // Render
	protected function render() {
        $settings = $this->get_settings_for_display();
        $list_iteam = $settings['iteams'];
        
        ?>
            <div class="project-details-section-area">
                    <ul class="list-area">
                        <?php foreach ( $list_iteam as $items ): ?>
                            <li>
                                <a href="#">
                                    <span><i class="fa-solid fa-check"></i></span>
                                    <?php echo esc_html( $items[ 'list_title' ]  ); ?>
                                </a>
                            </li>
                        <?php endforeach; ?>
                    </ul>
            </div>

        <?php
    }

}
$widgets_manager->register( new \Renev_List_Icon() );