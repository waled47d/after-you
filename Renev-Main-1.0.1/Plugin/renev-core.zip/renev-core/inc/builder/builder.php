<?php
    /**
     * Class For Builder
     */
    class RenevBuilder{

        function __construct(){
            // register admin menus
        	add_action( 'admin_menu', [$this, 'register_settings_menus'] );

            // Custom Footer Builder With Post Type
			add_action( 'init',[ $this,'post_type' ],0 );

 		    add_action( 'elementor/frontend/after_enqueue_scripts', [ $this,'widget_scripts'] );

			add_filter( 'single_template', [ $this, 'load_canvas_template' ] );

            add_action( 'elementor/element/wp-page/document_settings/after_section_end', [ $this,'renev_add_elementor_page_settings_controls' ],10,2 );

		}

		public function widget_scripts( ) {
			wp_enqueue_script( 'renev-core',RENEV_PLUGDIRURI.'assets/js/renev-core.js',array( 'jquery' ),'1.0',true );
		}


        public function renev_add_elementor_page_settings_controls( \Elementor\Core\DocumentTypes\Page $page ){

			$page->start_controls_section(
                'renev_header_option',
                [
                    'label'     => __( 'Header Option', 'renev' ),
                    'tab'       => \Elementor\Controls_Manager::TAB_SETTINGS,
                ]
            );


            $page->add_control(
                'renev_header_style',
                [
                    'label'     => __( 'Header Option', 'renev' ),
                    'type'      => \Elementor\Controls_Manager::SELECT,
                    'options'   => [
    					'prebuilt'             => __( 'Pre Built', 'renev' ),
    					'header_builder'       => __( 'Header Builder', 'renev' ),
    				],
                    'default'   => 'prebuilt',
                ]
			);

            $page->add_control(
                'renev_header_builder_option',
                [
                    'label'     => __( 'Header Name', 'renev' ),
                    'type'      => \Elementor\Controls_Manager::SELECT,
                    'options'   => $this->renev_header_choose_option(),
                    'condition' => [ 'renev_header_style' => 'header_builder'],
                    'default'	=> ''
                ]
            );

            $page->end_controls_section();

            $page->start_controls_section(
                'renev_footer_option',
                [
                    'label'     => __( 'Footer Option', 'renev' ),
                    'tab'       => \Elementor\Controls_Manager::TAB_SETTINGS,
                ]
            );
            $page->add_control(
    			'renev_footer_choice',
    			[
    				'label'         => __( 'Enable Footer?', 'renev' ),
    				'type'          => \Elementor\Controls_Manager::SWITCHER,
    				'label_on'      => __( 'Yes', 'renev' ),
    				'label_off'     => __( 'No', 'renev' ),
    				'return_value'  => 'yes',
    				'default'       => 'yes',
    			]
    		);
            $page->add_control(
                'renev_footer_style',
                [
                    'label'     => __( 'Footer Style', 'renev' ),
                    'type'      => \Elementor\Controls_Manager::SELECT,
                    'options'   => [
    					'prebuilt'             => __( 'Pre Built', 'renev' ),
    					'footer_builder'       => __( 'Footer Builder', 'renev' ),
    				],
                    'default'   => 'prebuilt',
                    'condition' => [ 'renev_footer_choice' => 'yes' ],
                ]
            );
            $page->add_control(
                'renev_footer_builder_option',
                [
                    'label'     => __( 'Footer Name', 'renev' ),
                    'type'      => \Elementor\Controls_Manager::SELECT,
                    'options'   => $this->renev_footer_choose_option(),
                    'condition' => [ 'renev_footer_style' => 'footer_builder','renev_footer_choice' => 'yes' ],
                    'default'	=> ''
                ]
            );

			$page->end_controls_section();

        }

		public function register_settings_menus(){
			add_menu_page(
				esc_html__( 'Renev Builder', 'renev' ),
            	esc_html__( 'Renev Builder', 'renev' ),
				'manage_options',
				'renev',
				[$this,'register_settings_contents__settings'],
				'dashicons-admin-site',
				2
			);

			add_submenu_page('renev', esc_html__('Footer Builder', 'renev'), esc_html__('Footer Builder', 'renev'), 'manage_options', 'edit.php?post_type=renev_footer');
			add_submenu_page('renev', esc_html__('Header Builder', 'renev'), esc_html__('Header Builder', 'renev'), 'manage_options', 'edit.php?post_type=renev_header');
			add_submenu_page('renev', esc_html__('Tab Builder', 'renev'), esc_html__('Tab Builder', 'renev'), 'manage_options', 'edit.php?post_type=renev_tab_build');
			add_submenu_page('renev', esc_html__('OFF Canvas Builder', 'renev'), esc_html__('OFF Canvas Builder', 'renev'), 'manage_options', 'edit.php?post_type=renev_off_build');
		}

		// Callback Function
		public function register_settings_contents__settings(){
            echo '<h2>';
			    echo esc_html__( 'Welcome To Header And Footer Builder Of This Theme','renev' );
            echo '</h2>';
		}

		public function post_type() {

			$labels = array(
				'name'               => __( 'Footer', 'renev' ),
				'singular_name'      => __( 'Footer', 'renev' ),
				'menu_name'          => __( 'Renev Footer Builder', 'renev' ),
				'name_admin_bar'     => __( 'Footer', 'renev' ),
				'add_new'            => __( 'Add New', 'renev' ),
				'add_new_item'       => __( 'Add New Footer', 'renev' ),
				'new_item'           => __( 'New Footer', 'renev' ),
				'edit_item'          => __( 'Edit Footer', 'renev' ),
				'view_item'          => __( 'View Footer', 'renev' ),
				'all_items'          => __( 'All Footer', 'renev' ),
				'search_items'       => __( 'Search Footer', 'renev' ),
				'parent_item_colon'  => __( 'Parent Footer:', 'renev' ),
				'not_found'          => __( 'No Footer found.', 'renev' ),
				'not_found_in_trash' => __( 'No Footer found in Trash.', 'renev' ),
			);

			$args = array(
				'labels'              => $labels,
				'public'              => true,
				'rewrite'             => false,
				'show_ui'             => true,
				'show_in_menu'        => false,
				'show_in_nav_menus'   => false,
				'exclude_from_search' => true,
				'capability_type'     => 'post',
				'hierarchical'        => false,
				'supports'            => array( 'title', 'elementor' ),
			);

			register_post_type( 'renev_footer', $args );

			$labels = array(
				'name'               => __( 'Header', 'renev' ),
				'singular_name'      => __( 'Header', 'renev' ),
				'menu_name'          => __( 'Renev Header Builder', 'renev' ),
				'name_admin_bar'     => __( 'Header', 'renev' ),
				'add_new'            => __( 'Add New', 'renev' ),
				'add_new_item'       => __( 'Add New Header', 'renev' ),
				'new_item'           => __( 'New Header', 'renev' ),
				'edit_item'          => __( 'Edit Header', 'renev' ),
				'view_item'          => __( 'View Header', 'renev' ),
				'all_items'          => __( 'All Header', 'renev' ),
				'search_items'       => __( 'Search Header', 'renev' ),
				'parent_item_colon'  => __( 'Parent Header:', 'renev' ),
				'not_found'          => __( 'No Header found.', 'renev' ),
				'not_found_in_trash' => __( 'No Header found in Trash.', 'renev' ),
			);

			$args = array(
				'labels'              => $labels,
				'public'              => true,
				'rewrite'             => false,
				'show_ui'             => true,
				'show_in_menu'        => false,
				'show_in_nav_menus'   => false,
				'exclude_from_search' => true,
				'capability_type'     => 'post',
				'hierarchical'        => false,
				'supports'            => array( 'title', 'elementor' ),
			);

			register_post_type( 'renev_header', $args );

            $labels = array(
				'name'               => __( 'Tab Builder', 'renev' ),
				'singular_name'      => __( 'Tab Builder', 'renev' ),
				'menu_name'          => __( 'Renev Tab Builder', 'renev' ),
				'name_admin_bar'     => __( 'Tab Builder', 'renev' ),
				'add_new'            => __( 'Add New', 'renev' ),
				'add_new_item'       => __( 'Add New Tab Builder', 'renev' ),
				'new_item'           => __( 'New Tab Builder', 'renev' ),
				'edit_item'          => __( 'Edit Tab Builder', 'renev' ),
				'view_item'          => __( 'View Tab Builder', 'renev' ),
				'all_items'          => __( 'All Tab Builder', 'renev' ),
				'search_items'       => __( 'Search Tab Builder', 'renev' ),
				'parent_item_colon'  => __( 'Parent Tab Builder:', 'renev' ),
				'not_found'          => __( 'No Tab Builder found.', 'renev' ),
				'not_found_in_trash' => __( 'No Tab Builder found in Trash.', 'renev' ),
			);

			$args = array(
				'labels'              => $labels,
				'public'              => true,
				'rewrite'             => false,
				'show_ui'             => true,
				'show_in_menu'        => false,
				'show_in_nav_menus'   => false,
				'exclude_from_search' => true,
				'capability_type'     => 'post',
				'hierarchical'        => false,
				'supports'            => array( 'title', 'elementor' ),
			);
			register_post_type( 'renev_tab_build', $args );

			//Off Canvas builder
            $labels = array(
				'name'               => __( 'Off Canvas Builder', 'renev' ),
				'singular_name'      => __( 'Off Canvas Builder', 'renev' ),
				'menu_name'          => __( 'Renev Off Canvas Builder', 'renev' ),
				'name_admin_bar'     => __( 'Off Canvas Builder', 'renev' ),
				'add_new'            => __( 'Add New', 'renev' ),
				'add_new_item'       => __( 'Add New Off Canvas Builder', 'renev' ),
				'new_item'           => __( 'New Off Canvas Builder', 'renev' ),
				'edit_item'          => __( 'Edit Off Canvas Builder', 'renev' ),
				'view_item'          => __( 'View Off Canvas Builder', 'renev' ),
				'all_items'          => __( 'All Off Canvas Builder', 'renev' ),
				'search_items'       => __( 'Search Off Canvas Builder', 'renev' ),
				'parent_item_colon'  => __( 'Parent Off Canvas Builder:', 'renev' ),
				'not_found'          => __( 'No Off Canvas Builder found.', 'renev' ),
				'not_found_in_trash' => __( 'No Off Canvas Builder found in Trash.', 'renev' ),
			);

			$args = array(
				'labels'              => $labels,
				'public'              => true,
				'rewrite'             => false,
				'show_ui'             => true,
				'show_in_menu'        => false,
				'show_in_nav_menus'   => false,
				'exclude_from_search' => true,
				'capability_type'     => 'post',
				'hierarchical'        => false,
				'supports'            => array( 'title', 'elementor' ),
			);
			register_post_type( 'renev_off_build', $args );

		}

		function load_canvas_template( $single_template ) {

			global $post;

			if ( 'renev_footer' == $post->post_type || 'renev_header' == $post->post_type || 'renev_tab_build' == $post->post_type || 'renev_off_build' == $post->post_type  ) {

				$elementor_2_0_canvas = ELEMENTOR_PATH . '/modules/page-templates/templates/canvas.php';

				if ( file_exists( $elementor_2_0_canvas ) ) {
					return $elementor_2_0_canvas;
				} else {
					return ELEMENTOR_PATH . '/includes/page-templates/canvas.php';
				}
			}

			return $single_template;
		}

        public function renev_footer_choose_option(){

			$renev_post_query = new WP_Query( array(
				'post_type'			=> 'renev_footer',
				'posts_per_page'	    => -1,
			) );

			$renev_builder_post_title = array();
			$renev_builder_post_title[''] = __('Select a Footer','Renev');

			while( $renev_post_query->have_posts() ) {
				$renev_post_query->the_post();
				$renev_builder_post_title[ get_the_ID() ] =  get_the_title();
			}
			wp_reset_postdata();

			return $renev_builder_post_title;

		}

		public function renev_header_choose_option(){

			$renev_post_query = new WP_Query( array(
				'post_type'			=> 'renev_header',
				'posts_per_page'	    => -1,
			) );

			$renev_builder_post_title = array();
			$renev_builder_post_title[''] = __('Select a Header','Renev');

			while( $renev_post_query->have_posts() ) {
				$renev_post_query->the_post();
				$renev_builder_post_title[ get_the_ID() ] =  get_the_title();
			}
			wp_reset_postdata();

			return $renev_builder_post_title;

        }

    }

    $builder_execute = new RenevBuilder();