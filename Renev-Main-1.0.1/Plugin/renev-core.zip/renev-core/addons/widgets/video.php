<?php
use \Elementor\Widget_Base;
use \Elementor\Controls_Manager;
use \Elementor\Group_Control_Typography;
use \Elementor\Group_Control_Border;
use \Elementor\Utils;
use \Elementor\Group_Control_Background;
use \Elementor\Repeater;
use \Elementor\Group_Control_Box_Shadow;

/**
 *
 * video Widget .
 *
 */
class Renev_Video_Box extends Widget_Base {

    public function get_name() {
        return 'video_box';
    }

    public function get_title() {
        return __( 'Video Box', 'renev' );
    }

    public function get_icon() {
        return 'eicon-code';
    }

    public function get_categories() {
        return [ 'renev' ];
    }

    protected function register_controls() {
        $this->start_controls_section(
            'content_section',
            [
                'label' 	=> __( 'Content', 'renev' ),
                'tab' 		=> Controls_Manager::TAB_CONTENT,
            ] 
        );
        $this->add_control(
            'video_icon',
            [
                'label'       => __( 'Video Icon', 'renev' ),
                'type'        => Controls_Manager::ICONS,
                'label_block' => true,
            ]
        );
        $this->add_control(
            'video_url',
            [
                'label' => __( 'Video URL', 'renev' ),
                'type' => Controls_Manager::URL,
            ]
        );
        $this->add_control(
            'video_text',
            [
                'label'   => esc_html__( 'Video Text', 'renev' ),
                'type'    => Controls_Manager::TEXT,
                'default' => esc_html__( 'Watch Our Video', 'renev' ),
                'label_block' => true,
            ]
        );
        $this->end_controls_section();

        //Video Box Style
        $this->start_controls_section(
            'video_button_section',
            [
                'label' => __( 'Video Button', 'renev' ),
                'tab'   => Controls_Manager::TAB_STYLE,
            ]
        );
        $this->add_control(
            'video_button_box_bg',
            [
                'label' => __( 'Background', 'renev' ),
                'type' => Controls_Manager::COLOR,
                'selectors' => [
                    '{{WRAPPER}} .play-btn a' => 'background: {{VALUE}}',
                ],
            ]
        );
        $this->add_responsive_control(
            'video_button_box_padding',
            [
                'label' => __( 'Video Padding', 'renev' ),
                'type' => Controls_Manager::DIMENSIONS,
                'size_units' => [ 'px', 'em', '%' ],
                'selectors' => [
                    '{{WRAPPER}} .play-btn a' => 'padding: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
                ],
            ]
        );
        $this->add_control(
            'video_button_box_border_radius',
            [
                'label' => esc_html__( 'Border Radius', 'renev' ),
                'type' => Controls_Manager::DIMENSIONS,
                'size_units' => [ 'px', '%', 'em', 'rem', 'custom' ],
                'selectors' => [
                    '{{WRAPPER}} .play-btn a' => 'border-radius: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
                ],
            ]
        );
        $this->add_responsive_control(
            'video_button_icon_size',
            [
                'label'          => __('Icon Size', 'renev'),
                'type'           => Controls_Manager::SLIDER,
                'size_units'     => ['%', 'px','vw'],
                'range'          => [
                    '%'  => [
                        'min' => 1,
                        'max' => 100,
                    ],
                    'px' => [
                        'min' => 1,
                        'max' => 1000,
                    ],
                    'vw' => [
                        'min' => 1,
                        'max' => 100,
                    ],
                ],
                'selectors'      => [
                    '{{WRAPPER}} .play-btn a span svg' => 'width: {{SIZE}}{{UNIT}};',
                    '{{WRAPPER}} .play-btn a span i' => 'width: {{SIZE}}{{UNIT}};',
                ],
            ]
        );
        $this->add_control(
            'video_button_icon_color',
            [
                'label' => __( 'Icon Color', 'renev' ),
                'type' => Controls_Manager::COLOR,
                'selectors' => [
                    '{{WRAPPER}} .play-btn a span i' => 'color: {{VALUE}}',
                    '{{WRAPPER}} .play-btn a span svg' => 'fill: {{VALUE}}',
                ],
            ]
        );
        // Icon Box width
        $this->add_responsive_control(
            'video_icon_box_width',
            [
                'label' => __( 'Icon Box Width', 'renev' ),
                'type'  => Controls_Manager::SLIDER,
                'range' => [
                    'px' => [
                        'min' => 10,
                        'max' => 200,
                    ],
                ],
                'selectors' => [
                    '{{WRAPPER}} .play-btn span' => 'width: {{SIZE}}{{UNIT}};',
                ],
            ]
        );
        // Icon Box height
        $this->add_responsive_control(
            'video_icon_box_height',
            [
                'label' => __( 'Icon Box Height', 'renev' ),
                'type'  => Controls_Manager::SLIDER,
                'range' => [
                    'px' => [
                        'min' => 10,
                        'max' => 200,
                    ],
                ],
                'selectors' => [
                    '{{WRAPPER}} .play-btn span' => 'height: {{SIZE}}{{UNIT}};',
                ],
            ]
        );
        $this->add_control(
            'video_icon_box_border_radius',
            [
                'label' => esc_html__( 'Icon Border Radius', 'renev' ),
                'type' => Controls_Manager::DIMENSIONS,
                'size_units' => [ 'px', '%', 'em', 'rem', 'custom' ],
                'selectors' => [
                    '{{WRAPPER}} .play-btn span' => 'border-radius: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
                ],
            ]
        );
        $this->add_control(
            'video_icon_box_bg',
            [
                'label' => __( 'Icon Background', 'renev' ),
                'type' => Controls_Manager::COLOR,
                'selectors' => [
                    '{{WRAPPER}} .play-btn span' => 'background: {{VALUE}}',
                ],
            ]
        );
        $this->end_controls_section();

         //Video Text Style 
         $this->start_controls_section(
            'video_text_section',
            [
                'label' => __( 'Video Text', 'renev' ),
                'tab'   => Controls_Manager::TAB_STYLE,
            ]
        );
        $this->add_control(
            'video_text_color',
            [
                'label' => __( 'Video Text Color', 'renev' ),
                'type' => Controls_Manager::COLOR,
                'selectors' => [
                    '{{WRAPPER}} .play-btn a' => 'color: {{VALUE}}',
                ],
            ]
        );
		$this->add_group_control(
			Group_Control_Typography::get_type(),
			[
				'name' => 'video_text_typography',
				'selector' => '{{WRAPPER}} .play-btn a',
			]
		);
        $this->add_responsive_control(
            'video_text_margin',
            [
                'label' => __( 'Video Button Margin', 'renev' ),
                'type' => Controls_Manager::DIMENSIONS,
                'size_units' => [ 'px', 'em', '%' ],
                'selectors' => [
                    '{{WRAPPER}} .video-wrap1 .video-thumb-box1 .video-text' => 'margin: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
                ],
            ]
        );
        $this->end_controls_section();
    }

    protected function render() {
        $settings = $this->get_settings_for_display();
        ?>
        <div class="play-btn">
            <?php if ( !empty($settings['video_url']['url']) ) : ?>
                <a href="<?php echo esc_url($settings['video_url']['url']); ?>" class="popup-youtube">
                    <span>
                        <?php \Elementor\Icons_Manager::render_icon( $settings['video_icon'], [ 'aria-hidden' => 'true' ] ); ?>
                    </span>
                    <?php echo esc_html( $settings['video_text'] ); ?>
                </a>
            <?php endif; ?>
        </div>
        <?php
    }
}

$widgets_manager->register( new \Renev_Video_Box() );
