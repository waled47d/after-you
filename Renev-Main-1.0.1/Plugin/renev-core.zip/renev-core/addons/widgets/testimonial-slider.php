<?php
use \Elementor\Widget_Base;
use \Elementor\Controls_Manager;
use \Elementor\Icons_Manager;
use \Elementor\Group_Control_Typography;
use \Elementor\Group_Control_Border;
use \Elementor\Group_Control_Box_Shadow;
use \Elementor\Repeater;
use \Elementor\Utils;
use \Elementor\Group_Control_Background;


/**
 *
 * Testimonial Widget .
 *
 */
class Renev_Testimonial_Slider extends Widget_Base {

	public function get_name() {
		return 'testimonial_slider';
	}

	public function get_title() {
		return __( 'Testimonial Slider', 'renev' );
	}

	public function get_icon() {
		return 'eicon-code';
    }

	public function get_categories() {
		return [ 'renev' ];
	}

	protected function register_controls() {
        // Content Section
        $this->start_controls_section(
            'content_section',
            [
                'label' => __( 'Content', 'renev' ),
                'tab'   => Controls_Manager::TAB_CONTENT,
            ]
        );
        $this->add_control(
            'testimonial_layout',
            [
                'label' => esc_html__('Select Style', 'renev'),
                'type' => Controls_Manager::SELECT,
                'options' => [
                    'layout-1' => esc_html__('layout 1', 'renev'),
                    'layout-2' => esc_html__('layout 2', 'renev'),
                    'layout-3' => esc_html__('layout 3', 'renev'),
                ],
                'default' => 'layout-1',
            ]
        );
        // Repeater for Testimonial items
        $repeater = new Repeater();

        $repeater->add_control(
            'testimonial_author',
            [
                'label'   => __( ' Testimonial Author', 'renev' ),
                'type'    => Controls_Manager::MEDIA,
                'default' => [
                    
                ],
                'description' => __('Used for layout 1', 'renev'),
            ]
        );
        $repeater->add_control(
            'testimonial_author_img',
            [
                'label'   => __( ' Testimonial Author Img', 'renev' ),
                'type'    => Controls_Manager::MEDIA,
                'default' => [
                    
                ],
            ]
        );
        $repeater->add_control(
            'testimonial_brand_img',
            [
                'label'   => __( 'Testimonial Brand Image', 'renev' ),
                'type'    => Controls_Manager::MEDIA,
                'default' => [
                    
                ],
                'description' => __('Used for layout 1,3', 'renev'),
            ]
        );
        $repeater->add_control(
			'quote_icon',
			[
				'label'       => __( 'Quoto Icon', 'renev' ),
				'type'        => Controls_Manager::ICONS,
				'label_block' => true,
			]
		);
        $repeater->add_control(
            'testimonial_description',
            [
                'label'       => __( 'Description', 'renev' ),
                'type'        => Controls_Manager::TEXTAREA,
                'default'     => __( '“Partnering with Renev was a turning point for our business. From an start, their team demonstrated level professionalism and expertise that’s hard to find. They took time understand not only our immediate needs but also our long-term vision, and they crafted a solution that truly aligned with both. ', 'renev' ),
                'label_block' => true,
             
            ]
        );
        $repeater->add_control(
            'testimonial_author_name',
            [
                'label'       => __( 'Author Name', 'renev' ),
                'type'        => Controls_Manager::TEXT,
                'default'     => __( 'Sheldon Jackson', 'renev' ),
                'label_block' => true,
            ]
        );
        $repeater->add_control(
            'testimonial_card_desig',
            [
                'label'       => __( 'Desigration', 'renev' ),
                'type'        => Controls_Manager::TEXT,
                'default'     => __( 'Owner FeatherDev', 'renev' ),
                'label_block' => true,
            ]
        );
       
        $this->add_control(
            'testimonial_items',
            [
                'label'       => __( 'Testimonial Items', 'renev' ),
                'type'        => Controls_Manager::REPEATER,
                'fields'      => $repeater->get_controls(),
                'default'     => [],
            ]
        );
        $this->end_controls_section();

        // Testimonial Box style
        $this->start_controls_section(
            'testimonial_box_style',
            [
                'label' => __( 'Testimonial Box', 'renev' ),
                'tab'   => Controls_Manager::TAB_STYLE,
            ]
        );
        $this->add_control(
            't_box_bg',
            [
                'label' => __( 'Background Color', 'renev' ),
                'type' => Controls_Manager::COLOR,
                'selectors' => [
                    '{{WRAPPER}} .testimonials-2 .swiper-testimonial-2 .testimonial-boxarea' => 'background-color: {{VALUE}}',
                    '{{WRAPPER}} .testimonial-review-area .testimonial-boxarea' => 'background-color: {{VALUE}}',
                    '{{WRAPPER}} .testimonial-slider-box .testimonial-boxarea' => 'background-color: {{VALUE}}',
                ],
            ]
        );
        $this->add_responsive_control(
            't_box_padding',
            [
                'label' => __( 'Padding', 'renev' ),
                'type' => Controls_Manager::DIMENSIONS,
                'size_units' => [ 'px', 'em', '%' ],
                'selectors' => [
                    '{{WRAPPER}} .testimonials-2 .swiper-testimonial-2 .testimonial-boxarea' => 'padding: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
                    '{{WRAPPER}} .testimonial-review-area .testimonial-boxarea' => 'padding: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
                    '{{WRAPPER}} .testimonial-slider-box .testimonial-boxarea' => 'padding: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
                ],
            ]
        );
        
        $this->add_group_control(
            Group_Control_Box_Shadow::get_type(),
            [
                'name'     => 't_box_shadow',
                'label'    => esc_html__( 'Box Shadow', 'renev' ),
                'selector' => '{{WRAPPER}} .testimonials-2 .swiper-testimonial-2 .testimonial-boxarea',
                'condition' => [
                    'testimonial_layout' => 'layout-1',
                ],
            ]
        );        
        $this->add_responsive_control(
            't_box_radius',
            [
                'label'         => __( 'Box Border Radius', 'renev' ),
                'type'          => Controls_Manager::DIMENSIONS,
                'size_units'    => [ 'px', '%', 'em' ],
                'selectors'     => [
                    '{{WRAPPER}} .testimonials-2 .swiper-testimonial-2 .testimonial-boxarea' => 'border-radius: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
                    '{{WRAPPER}} .testimonial-review-area .testimonial-boxarea' => 'border-radius: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
                    '{{WRAPPER}} .testimonial-slider-box .testimonial-boxarea' => 'border-radius: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
                ],
            ]
        );
        $this->add_group_control(
            \Elementor\Group_Control_Border::get_type(),
            [
                'name' => 't_box_border',
                'label' => __( 'Box Border', 'renev' ),
                'selector' => '{{WRAPPER}} .testimonials-2 .swiper-testimonial-2 .testimonial-boxarea, {{WRAPPER}} .testimonial-slider-box .testimonial-boxarea',
                'condition' => [
                    'testimonial_layout' => ['layout-1', 'layout-3',]
                ],
            ]
        );
        
		$this->end_controls_section();

        
         // Author Quoute  style
         $this->start_controls_section(
            'author_quoute_style',
            [
                'label' => __( ' Quoute Icon', 'renev' ),
                'tab'   => Controls_Manager::TAB_STYLE,
                'condition' => [
                    'testimonial_layout' => 'layout-2',
                ],
            ]
        );
        $this->add_responsive_control(
            'author_quoute_width',
            [
                'label' => esc_html__( 'Image Width', 'renev' ),
                'type' => Controls_Manager::SLIDER,
                'size_units' => [ 'px', '%', 'em', 'rem' ],
                'range' => [
                    'px' => [
                        'min' => 0,
                        'max' => 1000,
                        'step' => 1,
                    ],
                    '%' => [
                        'min' => 0,
                        'max' => 100,
                    ],
                    'em' => [
                        'min' => 0,
                        'max' => 50,
                    ],
                    'rem' => [
                        'min' => 0,
                        'max' => 50,
                    ],
                ],
                'selectors' => [
                    '{{WRAPPER}} .testimonial-review-area .testimonial-boxarea svg' => 'width: {{SIZE}}{{UNIT}};',
                ],
            ]
        );
        $this->add_responsive_control(
            'author_quoute_height',
            [
                'label' => esc_html__( 'Image Height', 'renev' ),
                'type' => Controls_Manager::SLIDER,
                'size_units' => [ 'px', '%', 'em', 'rem' ],
                'range' => [
                    'px' => [
                        'min' => 0,
                        'max' => 1000,
                        'step' => 1,
                    ],
                    '%' => [
                        'min' => 0,
                        'max' => 100,
                    ],
                    'em' => [
                        'min' => 0,
                        'max' => 50,
                    ],
                    'rem' => [
                        'min' => 0,
                        'max' => 50,
                    ],
                ],
                'selectors' => [
                    '{{WRAPPER}} .testimonial-review-area .testimonial-boxarea svg' => 'height: {{SIZE}}{{UNIT}};',
                ],
            ]
        );    
        $this->add_responsive_control(
            'author_quoute_margin',
            [
                'label' => __( 'Margin', 'renev' ),
                'type' => Controls_Manager::DIMENSIONS,
                'size_units' => [ 'px', 'em', '%' ],
                'selectors' => [
                    '{{WRAPPER}} .testimonial-review-area .testimonial-boxarea svg' => 'margin: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
                ],
            ]
        );
        $this->end_controls_section();


        // Rating style
        $this->start_controls_section(
            'rating_style',
            [
                'label' => __( 'Rating', 'renev' ),
                'tab'   => Controls_Manager::TAB_STYLE,
            ]
        );
        $this->add_control(
            'rating_color',
            [
                'label' => __( 'Color', 'renev' ),
                'type' => Controls_Manager::COLOR,
                'selectors' => [
                    '{{WRAPPER}} .testimonials-2 .swiper-testimonial-2 .testimonial-boxarea ul li' => 'color: {{VALUE}}',
                    '{{WRAPPER}} .testimonial-review-area .testimonial-boxarea ul li' => 'color: {{VALUE}}',
                    '{{WRAPPER}} .testimonial-slider-box .testimonial-boxarea ul li' => 'color: {{VALUE}}',
                ],
            ]
        );
        
        $this->add_responsive_control(
			'rating_size',
			[
				'label' => esc_html__( 'Size', 'renev' ),
				'type' => Controls_Manager::SLIDER,
				'size_units' => [ 'px', '%', 'em', 'rem', 'custom' ],
				'range' => [
					'px' => [
						'min' => 0,
						'max' => 1000,
						'step' => 1,
					],
					'%' => [
						'min' => 0,
						'max' => 100,
					],
				],
				'selectors' => [
					'{{WRAPPER}} .testimonials-2 .swiper-testimonial-2 .testimonial-boxarea ul li' => 'font-size: {{SIZE}}{{UNIT}};',
                    '{{WRAPPER}} .testimonial-review-area .testimonial-boxarea ul li' => 'font-size: {{SIZE}}{{UNIT}};',
                    '{{WRAPPER}} .testimonial-slider-box .testimonial-boxarea ul li' => 'font-size: {{SIZE}}{{UNIT}};',
				],
			]
		);
        $this->add_responsive_control(
            'rating_margin',
            [
                'label' => __( 'Margin', 'renev' ),
                'type' => Controls_Manager::DIMENSIONS,
                'size_units' => [ 'px', 'em', '%' ],
                'selectors' => [
                    '{{WRAPPER}} ul.star-rating' => 'margin: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
                    '{{WRAPPER}} .testimonial-review-area .testimonial-boxarea ul' => 'margin: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
                    '{{WRAPPER}} .testimonial-slider-box .testimonial-boxarea ul li' => 'margin: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
                ],
                
            ]
        );
		$this->end_controls_section();

        // Testimonial Description style
         $this->start_controls_section(
            'Testimonial_description_style',
            [
                'label' => __( 'Testimonial Description', 'renev' ),
                'tab'   => Controls_Manager::TAB_STYLE,
            ]
        );
        
        $this->add_control(
            'Testimonial_description_color',
            [
                'label' => __( 'Color', 'renev' ),
                'type' => Controls_Manager::COLOR,
                'selectors' => [
                    '{{WRAPPER}} .testimonials-2 .swiper-testimonial-2 .testimonial-boxarea p' => 'color: {{VALUE}}',
                    '{{WRAPPER}} .testimonial-review-area .testimonial-boxarea p' => 'color: {{VALUE}}',
                    '{{WRAPPER}} .testimonial-slider-box .testimonial-boxarea p' => 'color: {{VALUE}}',
                ],
            ]
        );
        
        $this->add_group_control(
			Group_Control_Typography::get_type(),
			[
				'name' => 'Testimonial_description_typography',
				'selector' => '{{WRAPPER}} .testimonials-2 .swiper-testimonial-2 .testimonial-boxarea p, {{WRAPPER}} .testimonial-review-area .testimonial-boxarea p, {{WRAPPER}} .testimonial-slider-box .testimonial-boxarea p',
			]
		);
        $this->add_responsive_control(
            'Testimonial_description_margin',
            [
                'label' => __( 'Margin', 'renev' ),
                'type' => Controls_Manager::DIMENSIONS,
                'size_units' => [ 'px', 'em', '%' ],
                'selectors' => [
                    '{{WRAPPER}} .testimonials-2 .swiper-testimonial-2 .testimonial-boxarea p' => 'margin: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
                    '{{WRAPPER}} .testimonial-review-area .testimonial-boxarea .man-img-area' => 'margin: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
                    '{{WRAPPER}} .testimonial-slider-box .testimonial-boxarea .names-area' => 'margin: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
                ],
                'condition' => [
                    'testimonial_layout!' => 'layout-1',
                ],
            ]
        );
		$this->end_controls_section();
        
        // Author Name style
        $this->start_controls_section(
            'author_name_style',
            [
                'label' => __( 'Author Name', 'renev' ),
                'tab'   => Controls_Manager::TAB_STYLE,
            ]
        );
        
        $this->add_control(
            'author_name_color',
            [
                'label' => __( 'Color', 'renev' ),
                'type' => Controls_Manager::COLOR,
                'selectors' => [
                    '{{WRAPPER}} .testimonials-2 .swiper-testimonial-2 .testimonial-boxarea .names-area .man-textarea .text a' => 'color: {{VALUE}}',
                    '{{WRAPPER}} .testimonial-review-area .testimonial-boxarea .man-img-area .content-area a' => 'color: {{VALUE}}',
                    '{{WRAPPER}} .testimonial-slider-box .testimonial-boxarea .names-area .man-textarea .text a' => 'color: {{VALUE}}',
                ],
            ]
        );
        
        $this->add_control(
            'author_name_color_hover',
            [
                'label' => __( 'Hover Color', 'renev' ),
                'type' => Controls_Manager::COLOR,
                'selectors' => [
                    '{{WRAPPER}} .testimonials-2 .swiper-testimonial-2 .testimonial-boxarea .names-area .man-textarea .text a:hover' => 'color: {{VALUE}}',
                    '{{WRAPPER}} .testimonial-review-area .testimonial-boxarea .man-img-area .content-area a:hover' => 'color: {{VALUE}}',
                    '{{WRAPPER}} .testimonial-slider-box .testimonial-boxarea .names-area .man-textarea .text a:hover' => 'color: {{VALUE}}',
                ],
            ]
        );
        $this->add_group_control(
			Group_Control_Typography::get_type(),
			[
				'name' => 'author_name_typography',
				'selector' => '{{WRAPPER}} .testimonials-2 .swiper-testimonial-2 .testimonial-boxarea .names-area .man-textarea .text a, {{WRAPPER}} .testimonial-review-area .testimonial-boxarea .man-img-area .content-area a, {{WRAPPER}} .testimonial-slider-box .testimonial-boxarea .names-area .man-textarea .text a',
			]
		);
		$this->add_responsive_control(
            'author_name_margin',
            [
                'label' => __( 'Margin', 'renev' ),
                'type' => Controls_Manager::DIMENSIONS,
                'size_units' => [ 'px', 'em', '%' ],
                'selectors' => [
                    '{{WRAPPER}} .testimonials-2 .swiper-testimonial-2 .testimonial-boxarea .names-area .man-textarea .text a' => 'margin: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
                    '{{WRAPPER}} .testimonial-review-area .testimonial-boxarea .man-img-area .content-area a' => 'margin: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
                    '{{WRAPPER}} .testimonial-slider-box .testimonial-boxarea .names-area .man-textarea .text a' => 'margin: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
                ],
            ]
        );
		$this->end_controls_section();
        
        // Designation style
        $this->start_controls_section(
            'designation_style',
            [
                'label' => __( 'Designation', 'renev' ),
                'tab'   => Controls_Manager::TAB_STYLE,
            ]
        );
        
        $this->add_control(
            'designation_color',
            [
                'label' => __( 'Color', 'renev' ),
                'type' => Controls_Manager::COLOR,
                'selectors' => [
                    '{{WRAPPER}} .testimonials-2 .swiper-testimonial-2 .testimonial-boxarea .names-area .man-textarea .text p' => 'color: {{VALUE}}',
                    '{{WRAPPER}} .testimonial-review-area .testimonial-boxarea .man-img-area .content-area p' => 'color: {{VALUE}}',
                    '{{WRAPPER}} .testimonial-slider-box .testimonial-boxarea .names-area .man-textarea .text p' => 'color: {{VALUE}}',
                ],
            ]
        );
        $this->add_group_control(
			Group_Control_Typography::get_type(),
			[
				'name' => 'designation_typography',
				'selector' => '{{WRAPPER}} .testimonials-2 .swiper-testimonial-2 .testimonial-boxarea .names-area .man-textarea .text p, {{WRAPPER}} .testimonial-review-area .testimonial-boxarea .man-img-area .content-area p, {{WRAPPER}} .testimonial-slider-box .testimonial-boxarea .names-area .man-textarea .text p',
			]
		);
        
		$this->end_controls_section();

         // Author Image  style
         $this->start_controls_section(
            'author_img_style',
            [
                'label' => __( 'Author Img', 'renev' ),
                'tab'   => Controls_Manager::TAB_STYLE,
            ]
        );
        $this->add_responsive_control(
            'author_img_width',
            [
                'label' => esc_html__( 'Image Width', 'renev' ),
                'type' => Controls_Manager::SLIDER,
                'size_units' => [ 'px', '%', 'em', 'rem' ],
                'range' => [
                    'px' => [
                        'min' => 0,
                        'max' => 1000,
                        'step' => 1,
                    ],
                    '%' => [
                        'min' => 0,
                        'max' => 100,
                    ],
                    'em' => [
                        'min' => 0,
                        'max' => 50,
                    ],
                    'rem' => [
                        'min' => 0,
                        'max' => 50,
                    ],
                ],
                'selectors' => [
                    '{{WRAPPER}} .testimonials-2 .swiper-testimonial-2 .testimonial-boxarea .names-area .man-textarea .man img' => 'width: {{SIZE}}{{UNIT}};',
                    '{{WRAPPER}} .testimonial-review-area .testimonial-boxarea .man-img-area .img1 img' => 'width: {{SIZE}}{{UNIT}};',
                    '{{WRAPPER}} .testimonial-slider-box .testimonial-boxarea .names-area .man-textarea .man img' => 'width: {{SIZE}}{{UNIT}};',
                ],
            ]
        );
        $this->add_responsive_control(
            'author_img_height',
            [
                'label' => esc_html__( 'Image Height', 'renev' ),
                'type' => Controls_Manager::SLIDER,
                'size_units' => [ 'px', '%', 'em', 'rem' ],
                'range' => [
                    'px' => [
                        'min' => 0,
                        'max' => 1000,
                        'step' => 1,
                    ],
                    '%' => [
                        'min' => 0,
                        'max' => 100,
                    ],
                    'em' => [
                        'min' => 0,
                        'max' => 50,
                    ],
                    'rem' => [
                        'min' => 0,
                        'max' => 50,
                    ],
                ],
                'selectors' => [
                    '{{WRAPPER}} .testimonials-2 .swiper-testimonial-2 .testimonial-boxarea .names-area .man-textarea .man img' => 'height: {{SIZE}}{{UNIT}};',
                    '{{WRAPPER}} .testimonial-review-area .testimonial-boxarea .man-img-area .img1 img' => 'height: {{SIZE}}{{UNIT}};',
                    '{{WRAPPER}} .testimonial-slider-box .testimonial-boxarea .names-area .man-textarea .man img' => 'height: {{SIZE}}{{UNIT}};',
                ],
            ]
        );    
        $this->add_responsive_control(
            'author_img_radius',
            [
                'label'         => __( 'Border Radius', 'renev' ),
                'type'          => Controls_Manager::DIMENSIONS,
                'size_units'    => [ 'px', '%', 'em' ],
                'selectors'     => [
                    '{{WRAPPER}} .testimonials-2 .swiper-testimonial-2 .testimonial-boxarea .names-area .man-textarea .man img' => 'border-radius: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
                    '{{WRAPPER}} .testimonial-review-area .testimonial-boxarea .man-img-area .img1 img' => 'border-radius: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
                    '{{WRAPPER}} .testimonial-slider-box .testimonial-boxarea .names-area .man-textarea .man img' => 'border-radius: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
                ],
            ]
        );
        $this->add_responsive_control(
            'author_img_padding',
            [
                'label' => __( 'Padding', 'renev' ),
                'type' => Controls_Manager::DIMENSIONS,
                'size_units' => [ 'px', 'em', '%' ],
                'selectors' => [
                    '{{WRAPPER}} .testimonials-2 .swiper-testimonial-2 .testimonial-boxarea .names-area .man-textarea .text' => 'padding: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
                    '{{WRAPPER}} .testimonial-review-area .testimonial-boxarea .man-img-area .content-area' => 'padding: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
                ],
                'condition' => [
                    'testimonial_layout!' => 'layout-3',
                ],
            ]
        );
        $this->add_responsive_control(
            'author_img_margin',
            [
                'label' => __( 'Margin', 'renev' ),
                'type' => Controls_Manager::DIMENSIONS,
                'size_units' => [ 'px', 'em', '%' ],
                'selectors' => [
                    '{{WRAPPER}} .testimonials-2 .swiper-testimonial-2 .testimonial-boxarea .names-area' => 'margin: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
                ],
                'condition' => [
                    'testimonial_layout' => 'layout-1',
                ],
            ]
        );
        $this->end_controls_section();

        // Author Image Slider  style
        $this->start_controls_section(
            'slider_img_style',
            [
                'label' => __( 'Slider Img', 'renev' ),
                'tab'   => Controls_Manager::TAB_STYLE,
                'condition' => [
                    'testimonial_layout' => 'layout-1',
                ],
            ]
        );
        $this->add_group_control(
            Group_Control_Background::get_type(),
            [
                'name' => 'text_slider_background_befor',
                'label' => __( 'Background before', 'renev' ),
                'types' => [ 'classic', 'gradient', 'video' ],
                'selector' => '{{WRAPPER}} .map-testimonial .swiper-slide div::before',
            ]
        );
        $this->add_responsive_control(
            'slider_img_width',
            [
                'label' => esc_html__( 'Image Width', 'renev' ),
                'type' => Controls_Manager::SLIDER,
                'size_units' => [ 'px', '%', 'em', 'rem' ],
                'range' => [
                    'px' => [
                        'min' => 0,
                        'max' => 1000,
                        'step' => 1,
                    ],
                    '%' => [
                        'min' => 0,
                        'max' => 100,
                    ],
                    'em' => [
                        'min' => 0,
                        'max' => 50,
                    ],
                    'rem' => [
                        'min' => 0,
                        'max' => 50,
                    ],
                ],
                'selectors' => [
                    '{{WRAPPER}} .map-testimonial .swiper-slide div img' => 'width: {{SIZE}}{{UNIT}};',
                ],
            ]
        );
        $this->add_responsive_control(
            'slider_img_width_befor',
            [
                'label' => esc_html__( 'Image Width Befor', 'renev' ),
                'type' => Controls_Manager::SLIDER,
                'size_units' => [ 'px', '%', 'em', 'rem' ],
                'range' => [
                    'px' => [
                        'min' => 0,
                        'max' => 1000,
                        'step' => 1,
                    ],
                    '%' => [
                        'min' => 0,
                        'max' => 100,
                    ],
                    'em' => [
                        'min' => 0,
                        'max' => 50,
                    ],
                    'rem' => [
                        'min' => 0,
                        'max' => 50,
                    ],
                ],
                'selectors' => [
                    '{{WRAPPER}} .map-testimonial .swiper-slide div::before' => 'width: {{SIZE}}{{UNIT}};',
                ],
            ]
        );
        $this->add_responsive_control(
            'slider_img_height',
            [
                'label' => esc_html__( 'Image Height', 'renev' ),
                'type' => Controls_Manager::SLIDER,
                'size_units' => [ 'px', '%', 'em', 'rem' ],
                'range' => [
                    'px' => [
                        'min' => 0,
                        'max' => 1000,
                        'step' => 1,
                    ],
                    '%' => [
                        'min' => 0,
                        'max' => 100,
                    ],
                    'em' => [
                        'min' => 0,
                        'max' => 50,
                    ],
                    'rem' => [
                        'min' => 0,
                        'max' => 50,
                    ],
                ],
                'selectors' => [
                    '{{WRAPPER}} .map-testimonial .swiper-slide div img' => 'height: {{SIZE}}{{UNIT}};',
                ],
            ]
        );    
        $this->add_responsive_control(
            'slider_img_height_before',
            [
                'label' => esc_html__( 'Image Height Before', 'renev' ),
                'type' => Controls_Manager::SLIDER,
                'size_units' => [ 'px', '%', 'em', 'rem' ],
                'range' => [
                    'px' => [
                        'min' => 0,
                        'max' => 1000,
                        'step' => 1,
                    ],
                    '%' => [
                        'min' => 0,
                        'max' => 100,
                    ],
                    'em' => [
                        'min' => 0,
                        'max' => 50,
                    ],
                    'rem' => [
                        'min' => 0,
                        'max' => 50,
                    ],
                ],
                'selectors' => [
                    '{{WRAPPER}} .map-testimonial .swiper-slide div::before' => 'height: {{SIZE}}{{UNIT}};',
                ],
            ]
        );    
        $this->add_responsive_control(
            'slider_img_radius',
            [
                'label'         => __( 'Border Radius', 'renev' ),
                'type'          => Controls_Manager::DIMENSIONS,
                'size_units'    => [ 'px', '%', 'em' ],
                'selectors'     => [
                    '{{WRAPPER}} .map-testimonial .swiper-slide div img' => 'border-radius: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
                ],
            ]
        );
        $this->end_controls_section();

        // PAGINATION  style
        $this->start_controls_section(
            'pagination_buttons_style',
            [
                'label' => __( 'Pagination Buttons', 'renev' ),
                'tab'   => Controls_Manager::TAB_STYLE,
            ]
        );
        $this->add_control(
            'pagination_buttons_bg',
            [
                'label' => __( 'Background Color', 'renev' ),
                'type' => Controls_Manager::COLOR,
                'selectors' => [
                    '{{WRAPPER}} .pagination-buttons button' => 'background: {{VALUE}} !important',
                    '{{WRAPPER}} .testimonial-slider-box .owl-nav button' => 'background: {{VALUE}} !important',
                    '{{WRAPPER}} .testimonial-review-area .owl-nav button' => 'background: {{VALUE}} !important',
                ],
            ]
        );
        $this->add_control(
            'pagination_buttons_bg_hover',
            [
                'label' => __( 'Background Hover Color', 'renev' ),
                'type' => Controls_Manager::COLOR,
                'selectors' => [
                    '{{WRAPPER}} .pagination-buttons button:hover' => 'background: {{VALUE}} !important',
                    '{{WRAPPER}} .testimonial-slider-box .owl-nav button:hover' => 'background: {{VALUE}} !important',
                    '{{WRAPPER}} .testimonial-review-area .owl-nav button:hover' => 'background: {{VALUE}} !important',
                ],
            ]
        );
        $this->add_control(
            'pagination_buttons_arrow',
            [
                'label' => __( 'Arrow Color', 'renev' ),
                'type' => Controls_Manager::COLOR,
                'selectors' => [
                    '{{WRAPPER}} .pagination-buttons button' => 'color: {{VALUE}} !important',
                    '{{WRAPPER}} .testimonial-slider-box .owl-nav button' => 'color: {{VALUE}} !important',
                    '{{WRAPPER}} .testimonial-review-area .owl-nav button' => 'color: {{VALUE}} !important',
                ],
            ]
        );
        $this->add_control(
            'pagination_buttons_arrow_hover',
            [
                'label' => __( 'Arrow Color Hover', 'renev' ),
                'type' => Controls_Manager::COLOR,
                'selectors' => [
                    '{{WRAPPER}} .pagination-buttons button:hover' => 'color: {{VALUE}} !important',
                    '{{WRAPPER}} .testimonial-slider-box .owl-nav button:hover' => 'color: {{VALUE}} !important',
                    '{{WRAPPER}} .testimonial-review-area .owl-nav button:hover' => 'color: {{VALUE}} !important',
                ],
            ]
        );
        $this->add_responsive_control(
            'pagination_buttons_margin',
            [
                'label' => __( 'Arrow Margin', 'renev' ),
                'type' => Controls_Manager::DIMENSIONS,
                'size_units' => [ 'px', 'em', '%' ],
                'selectors' => [
                    '{{WRAPPER}} .testimonials-2 .left .swiper-button-next' => 'margin: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
                    '{{WRAPPER}} .testimonials-2 .left .swiper-button-prev' => 'margin: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
                    
                    '{{WRAPPER}} .testimonial-review-area .owl-nav button' => 'margin: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',

                    '{{WRAPPER}} .testimonial-slider-box .owl-nav button' => 'margin: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
                ],
            ]
        );
        $this->add_responsive_control(
            'pagination_buttons_width',
            [
                'label' => esc_html__( 'Arrow Width', 'renev' ),
                'type' => Controls_Manager::SLIDER,
                'size_units' => [ 'px', '%', 'em', 'rem' ],
                'range' => [
                    'px' => [
                        'min' => 0,
                        'max' => 1000,
                        'step' => 1,
                    ],
                    '%' => [
                        'min' => 0,
                        'max' => 100,
                    ],
                    'em' => [
                        'min' => 0,
                        'max' => 50,
                    ],
                    'rem' => [
                        'min' => 0,
                        'max' => 50,
                    ],
                ],
                'selectors' => [
                    '{{WRAPPER}} .testimonials-2 .left .swiper-button-next' => 'width: {{SIZE}}{{UNIT}};',
                    '{{WRAPPER}} .testimonials-2 .left .swiper-button-prev' => 'width: {{SIZE}}{{UNIT}};',

                    '{{WRAPPER}} .testimonial-review-area .owl-nav button' => 'width: {{SIZE}}{{UNIT}};',

                    '{{WRAPPER}} .testimonial-slider-box .owl-nav button' => 'width: {{SIZE}}{{UNIT}};',
                ],
            ]
        );
        $this->add_responsive_control(
            'pagination_buttons_height',
            [
                'label' => esc_html__( 'Arrow Height', 'renev' ),
                'type' => Controls_Manager::SLIDER,
                'size_units' => [ 'px', '%', 'em', 'rem' ],
                'range' => [
                    'px' => [
                        'min' => 0,
                        'max' => 1000,
                        'step' => 1,
                    ],
                    '%' => [
                        'min' => 0,
                        'max' => 100,
                    ],
                    'em' => [
                        'min' => 0,
                        'max' => 50,
                    ],
                    'rem' => [
                        'min' => 0,
                        'max' => 50,
                    ],
                ],
                'selectors' => [
                    '{{WRAPPER}} .testimonials-2 .left .swiper-button-next' => 'height: {{SIZE}}{{UNIT}};',
                    '{{WRAPPER}} .testimonials-2 .left .swiper-button-prev' => 'height: {{SIZE}}{{UNIT}};',

                    '{{WRAPPER}} .testimonial-review-area .owl-nav button' => 'height: {{SIZE}}{{UNIT}};',

                    '{{WRAPPER}} .testimonial-slider-box .owl-nav button' => 'height: {{SIZE}}{{UNIT}};',
                ],
            ]
        );       
        $this->add_group_control(
            Group_Control_Border::get_type(),
            [
                'name' => 'pagination_buttons_border',
                'label' => __( 'Arrow Border', 'renev' ),
                'selector' => '{{WRAPPER}} .testimonials-2 .left .swiper-button-next, {{WRAPPER}} .testimonials-2 .left .swiper-button-prev, {{WRAPPER}} .testimonial-review-area .owl-nav button, {{WRAPPER}} .testimonial-slider-box .owl-nav button',
            ]
        );
        $this->add_responsive_control(
            'pagination_buttons_radius',
            [
                'label'         => __( 'Border Radius', 'renev' ),
                'type'          => Controls_Manager::DIMENSIONS,
                'size_units'    => [ 'px', '%', 'em' ],
                'selectors'     => [
                    '{{WRAPPER}} .testimonials-2 .left .swiper-button-next' => 'border-radius: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
                    '{{WRAPPER}} .testimonials-2 .left .swiper-button-prev' => 'border-radius: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
                    
                    '{{WRAPPER}} .testimonial-review-area .owl-nav button' => 'border-radius: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
                     
                    '{{WRAPPER}} .testimonial-slider-box .owl-nav button' => 'border-radius: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
                ],
            ]
        );
        $this->end_controls_section();

    }

    // Render
	protected function render() {
        $settings = $this->get_settings_for_display();
        $testimonial_items = $settings['testimonial_items'];
        $layout = $settings['testimonial_layout'];

        ?>
            <?php
                if ( $layout) {
                    include('testimonial/'.$layout.'.php');
                }
            ?>
        <?php
    }
}
$widgets_manager->register( new \Renev_Testimonial_Slider() );