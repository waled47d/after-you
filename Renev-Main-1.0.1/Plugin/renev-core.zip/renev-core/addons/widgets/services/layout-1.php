
<?php foreach( $service_lists as $item ) : 
    $args = new \WP_Query(array(
        'post_type' => 'renev_service',
        'post_status' => 'publish',
        'post__in' => [$item['select_post']]
    )); 
    ?>
     <?php while ($args->have_posts()) : $args->the_post(); ?>
     <div class="services1">
        <div class="service-branding-boxesarea">
            <div class="service-brand-head">
                <h2>
                    <a href="<?php the_permalink(); ?>">
                        <?php the_title(); ?>
                    </a>
                </h2>
                    <ul class="service-list">
                        <li>
                            <a href="#">
                                <?php echo esc_html($item['serviceslist_text']); ?>
                            </a>
                        </li>
                        <li>
                            <a href="#">
                                <?php echo esc_html($item['serviceslist2_text']); ?>
                            </a>
                        </li>
                    </ul>
                    <ul class="service-list">
                        <li>
                            <a href="#"> <?php echo esc_html($item['serviceslist3_text']); ?></a>
                        </li>
                        <li>
                            <a href="#"> <?php echo esc_html($item['serviceslist4_text']); ?></a>
                        </li>
                    </ul>
                </div>
                <div class="hidden-img">
                    <img src="<?php echo esc_url($item['hiden_image']['url']); ?>" alt="">
                </div>
                <div class="arrow">
                <a href="<?php the_permalink(); ?>">
                    <i class="fa-solid fa-arrow-right"></i>
                </a>
            </div>
        </div>
     </div>
        

    <?php endwhile; wp_reset_postdata(); ?>
<?php endforeach; ?>