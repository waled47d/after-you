

<div class="btn-area1"> 
    <a href="<?php echo esc_url($settings['btn_link']['url']); ?>" class="vl-btn1" 
        <?php echo !empty($settings['btn_link']['is_external']) ? 'target="_blank"' : ''; ?>
        <?php echo !empty($settings['btn_link']['nofollow']) ? 'rel="nofollow"' : ''; ?> style="overflow: hidden;">
        <?php echo esc_html($settings['btn_text']); ?>
    </a>
</div>