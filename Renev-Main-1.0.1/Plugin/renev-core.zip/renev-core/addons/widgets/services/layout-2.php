<div class="row">
    <div class="col-lg-5">
        <div class="image-container">
            <?php
            $image_index = 1;
            foreach( $service_lists as $item ) :
                $args = new WP_Query(array(
                    'post_type' => 'renev_service',
                    'post_status' => 'publish',
                    'post__in' => [$item['select_post']]
                ));
                while ( $args->have_posts() ) : $args->the_post(); ?>
                   <div class="image <?php echo $image_index === 1 ? 'active' : ''; ?>" id="image<?php echo $image_index; ?>">
                        <img src="<?php echo esc_url(get_the_post_thumbnail_url()); ?>" alt="<?php the_title_attribute(); ?>" class="service-img5">
                        <img src="<?php echo esc_url($item['hiden_image']['url']); ?>" alt="" class="shape">
                    </div>

                <?php
                $image_index++;
                endwhile; wp_reset_postdata();
            endforeach;
            ?>
        </div>
    </div>

    <div class="col-lg-7">
        <div class="list-container">
            <ul>
                <?php
                $list_index = 1;
                foreach( $service_lists as $item ) :
                    $args = new WP_Query(array(
                        'post_type' => 'renev_service',
                        'post_status' => 'publish',
                        'post__in' => [$item['select_post']]
                    ));
                    while ( $args->have_posts() ) : $args->the_post(); ?>
                        <li data-image="image<?php echo $list_index; ?>">
                            <div class="side-heading">
                                <div class="heading-area">
                                    <a href="<?php the_permalink(); ?>">
                                        <?php the_title(); ?>
                                    </a>
                                    <?php the_excerpt(); ?>
                                </div>
                                <div class="arrow">
                                    <a href="<?php the_permalink(); ?>">
                                        <?php \Elementor\Icons_Manager::render_icon( $item['renev_arrow_icon'], [ 'aria-hidden' => 'true' ] ); ?>
                                    </a>
                                </div>
                            </div>
                        </li>
                    <?php
                    $list_index++;
                    endwhile; wp_reset_postdata();
                endforeach;
                ?>
            </ul>
        </div>
    </div>
</div>
