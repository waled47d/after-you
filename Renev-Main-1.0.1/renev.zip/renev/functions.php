<?php
/**
 * @Packge     : Renev
 * @Version    : 1.0
 * @Author     : Mthemeus
 * @Author URI : https://www.mthemeus.com/
 *
 */

// Block direct access
if ( ! defined( 'ABSPATH' ) ) {
    exit;
}

/**
 * Include File
 *
 */


define( 'RENEV_THEME_DIR', get_template_directory() );
define( 'RENEV_THEME_URI', get_template_directory_uri() );
define( 'RENEV_THEME_CSS_DIR', RENEV_THEME_URI . '/assets/css/' );
define( 'RENEV_THEME_JS_DIR', RENEV_THEME_URI . '/assets/js/' );
define( 'RENEV_THEME_INC', RENEV_THEME_DIR . '/inc/' );

// Constants
require_once get_parent_theme_file_path() . '/inc/renev-constants.php';

//theme setup
require_once RENEV_DIR_PATH_INC . 'theme-setup.php';

//essential scripts
require_once RENEV_DIR_PATH_INC . 'essential-scripts.php';

//template helper
require_once RENEV_DIR_PATH_INC . 'template-helper.php';


// plugin activation
require_once RENEV_DIR_PATH_INC . 'Renev-framework/plugins-activation/renev-active-plugins.php';

// meta options
require_once RENEV_DIR_PATH_INC . 'Renev-framework/renev-meta/renev-config.php';

// page breadcrumbs
require_once RENEV_DIR_PATH_INC . 'renev-breadcrumbs.php';

// sidebar register
require_once RENEV_DIR_PATH_INC . 'renev-widgets-reg.php';


//essential functions
require_once RENEV_DIR_PATH_INC . 'renev-functions.php';



// helper function
require_once RENEV_DIR_PATH_INC . 'wp-html-helper.php';

// Demo Data
require_once RENEV_DEMO_DIR_PATH . 'demo-import.php';

// renev options
function renev_setup_ab() { 
    require_once RENEV_DIR_PATH_INC . 'Renev-framework/renev-options/renev-options.php';
}
add_action( 'after_setup_theme', 'renev_setup_ab', 20 );


// wp-pagination
require_once RENEV_DIR_PATH_INC . 'wp_bootstrap_pagination.php';

// hooks
require_once RENEV_DIR_PATH_HOOKS . 'hooks.php';

// hooks funtion
require_once RENEV_DIR_PATH_HOOKS . 'hooks-functions.php';


// Remove span class and add icon in blog category,blog sidebar
add_filter( 'wp_list_categories', function( $output ) {
    // Remove span around count
    $output = str_replace( '<span>', '', $output );
    $output = str_replace( '</span>', '', $output );

    // Add the icon at the end inside the <a>
    $output = preg_replace_callback( '#(<a[^>]*>.*?</a>)#', function( $matches ) {
        return str_replace('</a>', '<i class="fa-solid fa-angle-right"></i></a>', $matches[0]);
    }, $output );

    return $output;
});


