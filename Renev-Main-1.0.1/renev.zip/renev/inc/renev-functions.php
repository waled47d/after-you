<?php

/**
 * @Packge     : Renev
 * @Version    : 1.0
 * @Author     : Mthemeus
 * @Author URI : https://www.mthemeus.com/
 *
 */


// Block direct access
if( ! defined( 'ABSPATH' ) ){
    exit;
}

 // theme option callback
function renev_opt( $id = null, $url = null ){
    global $renev_opt;

    if( $id && $url ){

        if( isset( $renev_opt[$id][$url] ) && $renev_opt[$id][$url] ){
            return $renev_opt[$id][$url];
        }
    }else{
        if( isset( $renev_opt[$id] )  && $renev_opt[$id] ){
            return $renev_opt[$id];
        }
    }
}


/**
 * Get categories.
 */
function renev_get_category() {

    $categories = get_the_category( get_the_ID() );
    $x = 0;
    foreach ( $categories as $category ) {

        if ( $x == 2 ) {
            break;
        }
        $x++;
        print '<a class="news-tag" href="' . get_category_link( $category->term_id ) . '">' . $category->cat_name . '</a>';

    }
}


// theme logo
function renev_theme_logo() {
    // escaping allow html
    $allowhtml = array(
        'a'    => array(
            'href' => array()
        ),
        'span' => array(),
        'i'    => array(
            'class' => array()
        )
    );
    $siteUrl = home_url('/');
    if( has_custom_logo() ) {
        $custom_logo_id = get_theme_mod( 'custom_logo' );
        $siteLogo = '';
        $siteLogo .= '<a href="'.esc_url( $siteUrl ).'">';
        $siteLogo .= renev_img_tag( array(
            "url"   => esc_url( wp_get_attachment_image_url( $custom_logo_id, 'full') )
        ) );
        $siteLogo .= '</a>';

        return $siteLogo;
    } elseif( !renev_opt('renev_text_title') && renev_opt('renev_site_logo', 'url' )  ){

        $siteLogo = '<img src="'.esc_url( renev_opt('renev_site_logo', 'url' ) ).'" alt="'.esc_attr__( 'logo', 'renev' ).'" />';
        return '<a class="logo" href="'.esc_url( $siteUrl ).'">'.$siteLogo.'</a>';


    }elseif( renev_opt('renev_text_title') ){
        return '<h2><a class="logo" href="'.esc_url( $siteUrl ).'">'.wp_kses( renev_opt('renev_text_title'), $allowhtml ).'</a></h2>';
    }else{
        return '<h2><a class="logo" href="'.esc_url( $siteUrl ).'">'.esc_html( get_bloginfo('name') ).'</a></h2>';
    }
}

// Renev Coming Soon Logo
function renev_coming_soon_logo() {
    // escaping allow html
    $allowhtml = array(
        'a'    => array(
            'href' => array()
        ),
        'span' => array(),
        'i'    => array(
            'class' => array()
        )
    );
    $siteUrl = home_url('/');
    // site logo
    if( renev_opt( 'renev_coming_logo', 'url' )  ){

        $siteLogo = '<img src="'.esc_url( renev_opt('renev_coming_logo', 'url' ) ).'" alt="'.esc_attr__( 'logo', 'renev' ).'" />';

        return '<a class="logo" href="'.esc_url( $siteUrl ).'">'.$siteLogo.'</a>';

    }elseif( renev_opt('renev_coming_site_title') ){
        return '<h2><a class="text-logo" href="'.esc_url( $siteUrl ).'">'.wp_kses( renev_opt('renev_coming_site_title'), $allowhtml ).'</a></h2>';
    }else{
        return '<h2><a class="text-logo" href="'.esc_url( $siteUrl ).'">'.esc_html( get_bloginfo('name') ).'</a></h2>';
    }
}

// custom meta id callback
function renev_meta( $id = '' ){
    $value = get_post_meta( get_the_ID(), '_renev_'.$id, true );
    return $value;
}


// Blog Date Permalink
function renev_blog_date_permalink() {
    $year  = get_the_time('Y');
    $month_link = get_the_time('m');
    $day   = get_the_time('d');
    $link = get_day_link( $year, $month_link, $day);
    return $link;
}

//audio format iframe match
function renev_iframe_match() {
    $audio_content = renev_embedded_media( array('audio', 'iframe') );
    $iframe_match = preg_match("/\iframe\b/i",$audio_content, $match);
    return $iframe_match;
}


//Post embedded media
function renev_embedded_media( $type = array() ){
    $content = do_shortcode( apply_filters( 'the_content', get_the_content() ) );
    $embed   = get_media_embedded_in_content( $content, $type );


    if( in_array( 'audio' , $type) ){
        if( count( $embed ) > 0 ){
            $output = str_replace( '?visual=true', '?visual=false', $embed[0] );
        }else{
           $output = '';
        }

    }else{
        if( count( $embed ) > 0 ){
            $output = $embed[0];
        }else{
           $output = '';
        }
    }
    return $output;
}


// WP post link pages
function renev_link_pages(){
    wp_link_pages( array(
        'before'      => '<div class="page-links"><span class="page-links-title">' . esc_html__( 'Pages:', 'renev' ) . '</span>',
        'after'       => '</div>',
        'link_before' => '<span>',
        'link_after'  => '</span>',
        'pagelink'    => '<span class="screen-reader-text">' . esc_html__( 'Page', 'renev' ) . ' </span>%',
        'separator'   => '<span class="screen-reader-text">, </span>',
    ) );
}


// Data Background image attr
function renev_data_bg_attr( $imgUrl = '' ){
    return 'data-bg-img="'.esc_url( $imgUrl ).'"';
}

// image alt tag
function renev_image_alt( $url = '' ){
    if( $url != '' ){
        // attachment id by url
        $attachmentid = attachment_url_to_postid( esc_url( $url ) );
       // attachment alt tag
        $image_alt = get_post_meta( esc_html( $attachmentid ) , '_wp_attachment_image_alt', true );
        if( $image_alt ){
            return $image_alt ;
        }else{
            $filename = pathinfo( esc_url( $url ) );
            $alt = str_replace( '-', ' ', $filename['filename'] );
            return $alt;
        }
    }else{
       return;
    }
}


// Flat Content wysiwyg output with meta key and post id

function renev_get_textareahtml_output( $content ) {
    global $wp_embed;

    $content = $wp_embed->autoembed( $content );
    $content = $wp_embed->run_shortcode( $content );
    $content = wpautop( $content );
    $content = do_shortcode( $content );

    return $content;
}

/**
 * Add a pingback url auto-discovery header for single posts, pages, or attachments.
 */

function renev_pingback_header() {
    if ( is_singular() && pings_open() ) {
        echo '<link rel="pingback" href="', esc_url( get_bloginfo( 'pingback_url' ) ), '">';
    }
}
add_action( 'wp_head', 'renev_pingback_header' );


// Excerpt More
function renev_excerpt_more( $more ) {
    return '...';
}

add_filter( 'excerpt_more', 'renev_excerpt_more' );


// renev comment template callback
function renev_comment_callback( $comment, $args, $depth ) {
        $add_below = 'comment';
    ?>
        <li>
            <div class="comments-boxarea">
                <div class="comments-boxes">
                    <div class="comments-auhtor-box">

                        
                        <!-- Author Image -->
                        <?php if( get_avatar( $comment, 80 )  ) : ?>
                            <div class="img3">
                                <?php
                                    if ( $args['avatar_size'] != 0 ) {
                                        echo get_avatar( $comment, 80 );
                                    }
                                ?>
                            </div>
                        <?php endif; ?>


                        <div class="content">
                            <!-- Post Date -->
                            <a href="<?php echo get_day_link(get_the_date('Y'), get_the_date('m'), get_the_date('d')); ?>" class="date">
                                <svg xmlns="http://www.w3.org/2000/svg" width="20" height="20" viewBox="0 0 20 20" fill="none"><g clip-path="url(#clip0_91_5623)"><path d="M5.673 0C5.85865 0 6.0367 0.0737498 6.16797 0.205025C6.29925 0.336301 6.373 0.514348 6.373 0.7V2.009H13.89V0.709C13.89 0.523348 13.9637 0.345301 14.095 0.214025C14.2263 0.0827498 14.4043 0.009 14.59 0.009C14.7757 0.009 14.9537 0.0827498 15.085 0.214025C15.2162 0.345301 15.29 0.523348 15.29 0.709V2.009H18C18.5303 2.009 19.0388 2.21958 19.4139 2.59443C19.7889 2.96929 19.9997 3.47774 20 4.008V18.001C19.9997 18.5313 19.7889 19.0397 19.4139 19.4146C19.0388 19.7894 18.5303 20 18 20H2C1.46974 20 0.961184 19.7894 0.58614 19.4146C0.211096 19.0397 0.00026513 18.5313 0 18.001L0 4.008C0.00026513 3.47774 0.211096 2.96929 0.58614 2.59443C0.961184 2.21958 1.46974 2.009 2 2.009H4.973V0.699C4.97327 0.513522 5.04713 0.335731 5.17838 0.204672C5.30963 0.0736123 5.48752 -1.89263e-07 5.673 0ZM1.4 7.742V18.001C1.4 18.0798 1.41552 18.1578 1.44567 18.2306C1.47583 18.3034 1.52002 18.3695 1.57574 18.4253C1.63145 18.481 1.69759 18.5252 1.77039 18.5553C1.84319 18.5855 1.92121 18.601 2 18.601H18C18.0788 18.601 18.1568 18.5855 18.2296 18.5553C18.3024 18.5252 18.3685 18.481 18.4243 18.4253C18.48 18.3695 18.5242 18.3034 18.5543 18.2306C18.5845 18.1578 18.6 18.0798 18.6 18.001V7.756L1.4 7.742ZM6.667 14.619V16.285H5V14.619H6.667ZM10.833 14.619V16.285H9.167V14.619H10.833ZM15 14.619V16.285H13.333V14.619H15ZM6.667 10.642V12.308H5V10.642H6.667ZM10.833 10.642V12.308H9.167V10.642H10.833ZM15 10.642V12.308H13.333V10.642H15ZM4.973 3.408H2C1.92121 3.408 1.84319 3.42352 1.77039 3.45367C1.69759 3.48382 1.63145 3.52802 1.57574 3.58374C1.52002 3.63945 1.47583 3.70559 1.44567 3.77839C1.41552 3.85119 1.4 3.92921 1.4 4.008V6.343L18.6 6.357V4.008C18.6 3.92921 18.5845 3.85119 18.5543 3.77839C18.5242 3.70559 18.48 3.63945 18.4243 3.58374C18.3685 3.52802 18.3024 3.48382 18.2296 3.45367C18.1568 3.42352 18.0788 3.408 18 3.408H15.29V4.337C15.29 4.52265 15.2162 4.7007 15.085 4.83197C14.9537 4.96325 14.7757 5.037 14.59 5.037C14.4043 5.037 14.2263 4.96325 14.095 4.83197C13.9637 4.7007 13.89 4.52265 13.89 4.337V3.408H6.373V4.328C6.373 4.51365 6.29925 4.6917 6.16797 4.82297C6.0367 4.95425 5.85865 5.028 5.673 5.028C5.48735 5.028 5.3093 4.95425 5.17803 4.82297C5.04675 4.6917 4.973 4.51365 4.973 4.328V3.408Z" fill="white"></path></g><defs><clipPath id="clip0_91_5623"><rect width="20" height="20" fill="white"></rect></clipPath></defs></svg>
                                <?php echo esc_html( get_comment_date('j F Y') ); ?>
                            </a>      
                            <!-- Author Name -->
                            <?php
                                $author_url = get_comment_author_url();
                                $author_name = get_comment_author();
                                echo '<a href="' . esc_url( $author_url ) . '" class="name">' . esc_html( ucwords( $author_name ) ) . '</a>';
                            ?>
                        </div> 
                    </div> 

     

                        <?php
                            echo comment_reply_link(
                                array_merge(
                                    $args,
                                    array(
                                        'add_below'  => $add_below,
                                        'depth'      => $depth, // বর্তমান কমেন্ট depth
                                        'max_depth'  => 5,
                                        'reply_text' => '<div class="reply">
                                                               <i class="fas fa-reply"></i>
                                                                Reply
                                                         </div>',
                                    )
                                )
                            );
                        ?>


                </div> 
                
                <div class="space16"></div>
                     <?php comment_text(); ?>

                    <span class="comment-edit-link"><?php edit_comment_link( '<span class="fas fa-pencil"></span>'.esc_html__( 'Edit', 'renev' ), '  ', '' ); ?></span>
                        <?php if ( $comment->comment_approved == '0' ) : ?>
                        <p class="comment-awaiting-moderation"><?php esc_html_e( 'Your comment is awaiting moderation.', 'renev' ); ?></p>
                    <?php endif; ?>
            </div>
        </li>
        <!-- Comment Content -->
    <?php
}

//body class
add_filter( 'body_class', 'renev_body_class' );
function renev_body_class( $classes ) {
    if ( class_exists('ReduxFramework') ) {
        $renev_blog_single_sidebar = renev_opt('renev_blog_single_sidebar');
        if ( ($renev_blog_single_sidebar != '2' && $renev_blog_single_sidebar != '3') || !is_active_sidebar('renev-blog-sidebar') ) {
            $classes[] = 'no-sidebar body-bg1';
        }
    } else {
        if ( !is_active_sidebar('renev-blog-sidebar') ) {
            $classes[] = 'no-sidebar body-bg1';
        } else {
            $classes[] = 'body-bg1';
        }
    }
    return $classes;
}


function renev_footer_global_option(){

    // Renev Footer Bottom Enable Disable
    if( class_exists( 'ReduxFramework' ) ){
        $renev_footer_bottom_active = renev_opt( 'renev_disable_footer_bottom' );
    }else{
        $renev_footer_bottom_active = '1';
    }

    $allowhtml = array(
        'p'         => array(
            'class'     => array()
        ),
        'span'      => array(
            'class'     => array(),
        ),
        'a'         => array(
            'href'      => array(),
            'title'     => array()
        ),
        'br'        => array(),
        'em'        => array(),
        'strong'    => array(),
        'b'         => array(),
    );

    if( $renev_footer_bottom_active == '1' ){
        echo '<!-- Footer -->';
        echo '<footer class="footer-main">';

            if( $renev_footer_bottom_active == '1' ){
                $allowhtml = array(
                    'p'         => array(
                        'class'     => array()
                    ),
                    'span'      => array(),
                    'a'         => array(
                        'href'      => array(),
                        'title'     => array(),
                        'class'     => array(),
                    ),
                    'br'        => array(),
                    'em'        => array(),
                    'strong'    => array(),
                    'b'         => array(),
                );
                echo '<div class="copyright-wrap">';
                    echo '<div class="container">';
                        echo '<div class="row align-items-center">';
                            if( ! empty( renev_opt( 'renev_copyright_text' ) ) ){
                                echo '<p class="copyright-text dafd">'.wp_kses( renev_opt( 'renev_copyright_text' ), $allowhtml ).'</p>';
                            }
                        echo '</div>';
                    echo '</div>';
                echo '</div>';
            }
        echo '</footer>';
        echo '<!-- End Footer -->';
    }
}

function renev_social_icon(){
    $renev_social_icon = renev_opt( 'renev_social_links' );
    if( ! empty( $renev_social_icon ) && isset( $renev_social_icon ) ){
        echo '<div class="author-links">';
        foreach( $renev_social_icon as $social_icon ){
            if( ! empty( $social_icon['title'] ) ){
                echo '<a href="'.esc_url( $social_icon['url'] ).'"><i class="'.esc_attr( $social_icon['title'] ).'"></i>'.esc_html( $social_icon['description'] ).'</a>';
            }
        }
        echo '</div>';
    }
}


// global header
function renev_global_header_option() {

    echo '<header class="homepage1-menu prebuilt-header">';
        echo '<div id="vl-header-sticky" class="vl-header-area vl-transparent-header">';
            echo '<div class="container headerfix">';
                echo '<div class="row align-items-center row-bg1">';

                    echo '<div class="col-auto">';
                        echo '<div class="vl-logo">';
                                echo renev_theme_logo();
                        echo '</div>';
                    echo '</div>';

                    echo '<div class="col-auto d-none d-lg-block">';
                        echo '<div class="vl-main-menu text-center">';
                            echo '<nav class="vl-mobile-menu-active">';
                                if( has_nav_menu( 'primary-menu' ) ){
                                    wp_nav_menu( array(
                                        "theme_location"    => 'primary-menu',
                                        "container"         => '',
                                        "menu_class"        => '',
                                    ) );
                                }
                            echo '</nav>';
                        echo '</div>';
                    echo '</div>';

                    echo '<div class="col-auto d-block d-lg-none">';
                        echo '<div class="vl-header-action-item">';
                            echo '<button type="button" class="vl-offcanvas-toggle">';
                                echo '<i class="fa-solid fa-bars-staggered"></i>';
                            echo '</button>';
                        echo '</div>';
                    echo '</div>';

                echo '</div>';
            echo '</div>';
        echo '</div>';
    echo '</header>';


    // td-offcanvus-area-start
    echo '<div class="homepage1-menu">';
        echo '<div class="vl-offcanvas">';
            echo '<div class="vl-offcanvas-wrapper">';
                echo '<div class="vl-offcanvas-header d-flex justify-content-between align-items-center mb-90">';
                    echo '<div class="vl-offcanvas-logo">';
                        echo renev_theme_logo();
                    echo '</div>';
                    echo '<div class="vl-offcanvas-close"><button class="vl-offcanvas-close-toggle"><i class="fa-solid fa-xmark"></i></button></div>';
                echo '</div>';
                echo '<div class="vl-offcanvas-menu d-lg-none mb-40"><nav></nav></div>';
            echo '</div>';
        echo '</div>';
        echo '<div class="vl-offcanvas-overlay"></div>';
    echo '</div>';
    // td-offcanvus-area-end
}



//Fire the wp_body_open action.
if ( ! function_exists( 'wp_body_open' ) ) {
	function wp_body_open() {
		do_action( 'wp_body_open' );
	}
}

//Remove Tag-Clouds inline style
add_filter( 'wp_generate_tag_cloud', 'renev_remove_tagcloud_inline_style',10,1 );
function renev_remove_tagcloud_inline_style( $input ){
   return preg_replace('/ style=("|\')(.*?)("|\')/','',$input );
}

// password protected form
add_filter('the_password_form','renev_password_form',10,1);
function renev_password_form( $output ) {
    $output = '<form action="' . esc_url( home_url( 'wp-login.php?action=postpass', 'login_post' ) ) . '" class="post-password-form" method="post"><div class="theme-input-group">
        <input name="post_password" type="password" class="theme-input-style" placeholder="'.esc_attr__( 'Enter Password','renev' ).'">
        <button type="submit" class="submit-btn btn-fill">'.esc_html__( 'Enter','renev' ).'</button></div></form>';
    return $output;
}

function renev_setPostViews( $postID ) {
    $count_key  = 'post_views_count';
    $count      = get_post_meta( $postID, $count_key, true );
    if( $count == '' ){
        $count = 0;
        delete_post_meta( $postID, $count_key );
        add_post_meta( $postID, $count_key, '0' );
    }else{
        $count++;
        update_post_meta( $postID, $count_key, $count );
    }
}

function renev_getPostViews( $postID ){
    $count_key  = 'post_views_count';
    $count      = get_post_meta( $postID, $count_key, true );
    if( $count == '' ){
        delete_post_meta( $postID, $count_key );
        add_post_meta( $postID, $count_key, '0' );
        return __( '0', 'renev' );
    }
    return $count;
}


/* This code filters the Categories widget to include the post count inside the link */
function renev_cat_add_count_span($output) {
    // Modify the category list output to include count in a <span> element
    $output = preg_replace('/<\/a>\s*\(([0-9]+)\)/', ' <span>($1)</span></a>', $output);
    return $output;
}
add_filter('wp_list_categories', 'renev_cat_add_count_span');


/* This code filters the Archive widget to include the post count inside the link */
add_filter( 'get_archives_link', 'renev_archive_remove_count' );
function renev_archive_remove_count( $links ) {
    $links = preg_replace('/<\/a>&nbsp;\([0-9]+\)/', '</a>', $links);
    return $links;
}

// Blog Category
if( ! function_exists( 'renev_blog_category' ) ){
    function renev_blog_category(){
        if( class_exists( 'ReduxFramework' ) ){
            $renev_display_post_category =  renev_opt('renev_display_post_category');
        }else{
            $renev_display_post_category = '1';
        }


        if( $renev_display_post_category ){
            $renev_post_categories = get_the_category();
            if( is_array( $renev_post_categories ) && ! empty( $renev_post_categories ) ){
                echo '<div class="blog-category ">';
                    echo ' <a href="'.esc_url( get_term_link( $renev_post_categories[0]->term_id ) ).'">'.esc_html( $renev_post_categories[0]->name ).'</a> ';
                echo '</div>';
            }
        }
    }
}

// Add Extra Class On Comment Reply Button
function renev_custom_comment_reply_link( $content ) {
    $extra_classes = 'replay-btn';
    return preg_replace( '/comment-reply-link/', 'comment-reply-link ' . $extra_classes, $content);
}

add_filter('comment_reply_link', 'renev_custom_comment_reply_link', 99);

// Add Extra Class On Edit Comment Link
function renev_custom_edit_comment_link( $content ) {
    $extra_classes = 'replay-btn';
    return preg_replace( '/comment-edit-link/', 'comment-edit-link ' . $extra_classes, $content);
}

add_filter('edit_comment_link', 'renev_custom_edit_comment_link', 99);


function renev_post_classes( $classes, $class, $post_id ) {
    if ( get_post_type() === 'post' ) {
        if( ! is_single() ){
            if( renev_opt( 'renev_blog_style' ) == '3' ){
                $classes[] = "fav-blog blog-grid grid-wide";
            }else{
                $classes[] = "fav-blog blog-single";
            }
        }else{
            $classes[] = "fav-blog blog-single";
        }
    }elseif( get_post_type() === 'product' ){
        // Return Class
    }elseif( get_post_type() === 'page' ){
        $classes[] = "page--item";
    }

    return $classes;
}
add_filter( 'post_class', 'renev_post_classes', 10, 3 );

