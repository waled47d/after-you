<?php
use \Elementor\Widget_Base;
use \Elementor\Controls_Manager;
use \Elementor\Icons_Manager;
use \Elementor\Group_Control_Typography;
use \Elementor\Group_Control_Border;
use \Elementor\Group_Control_Box_Shadow;
use \Elementor\Repeater;
use \Elementor\Utils;
use \Elementor\Group_Control_Background;

/**
 *
 * Project Widget .
 *
 */
class Renev_Project extends Widget_Base {

	public function get_name() {
		return 'renev_project';
	}

	public function get_title() {
		return __( 'Renev Project', 'renev' );
	}

	public function get_icon() {
		return 'eicon-code';
    }

	public function get_categories() {
		return [ 'renev' ];
	}

	protected function register_controls() {

        // Project
        $this->start_controls_section(
            'project_section',
            [
                'label' => __('Project', 'renev'),
                'tab'   => Controls_Manager::TAB_CONTENT,
            ]
        );
        $this->add_control(
            'project_layout',
            [
                'label' => esc_html__('Select Layout', 'renev'),
                'type' => Controls_Manager::SELECT,
                'options' => [
                    'layout-1' => esc_html__('Layout 1', 'renev'),
                    'layout-2' => esc_html__('Layout 2', 'renev'),
                    'layout-3' => esc_html__('Layout 3', 'renev'),
                    'layout-4' => esc_html__('Layout 4', 'renev'),
                ],
                'default' => 'layout-1',
            ]
        );
        $this->add_control(
            'post_per_page',
            [
                'label'       => __('Numbar Of Posts', 'renev'),
                'type'        => Controls_Manager::NUMBER,
                'default'     => '',
                'description' => 'user emty value show all posts',
            ]
        );
        $this->add_control(
            'post_by',
            [
                'label' => __('Post By:', 'renev'),
                'type' => Controls_Manager::SELECT,
                'default' => 'latest',
                'label_block' => true,
                'options' => array(
                    'latest'   =>   __('Latest Post', 'renev'),
                    'selected' =>   __('Selected posts', 'renev'),
                ),
            ]
        );
        $options = $this->get_all_projects();
        unset($options['none']); 
        $this->add_control(
            'post__in',
            [
                'label' => __('Post In', 'renev'),
                'type' => Controls_Manager::SELECT2,
                'options' => $options,
                'multiple' => true,
                'label_block' => true,
                'condition'   => [
                    'post_by' => 'selected',
                ]
            ]
        );
        $this->add_control(
            'project_category',
            [
                'label' => __('Filter by Category', 'renev'),
                'type' => Controls_Manager::SELECT2,
                'options' => $this->get_project_categories(),
                'multiple' => true,
                'label_block' => true,
                'description' => __('Select a category to filter projects.', 'renev'),
            ]
        );        
        $this->add_control(
            'order',
            [
                'label' => __('Order', 'renev'),
                'type' => Controls_Manager::SELECT,
                'options' => [
                    'asc' => 'Ascending',
                    'desc' => 'Descending',
                ],
                'default' => 'desc',
                'label_block' => true,

            ]
        );
        $this->add_control(
            'show_pagination',
            [
                'label' => __( 'Show Pagination', 'renev' ),
                'type' => \Elementor\Controls_Manager::SWITCHER,
                'label_on' => __( 'Show', 'renev' ),
                'label_off' => __( 'Hide', 'renev' ),
                'return_value' => 'yes',
                'default' => 'yes',
                'condition' => [
                    'project_layout' => 'layout-4',
                ]
            ]
        );
        $this->add_control(
            'show_category',
            [
                'label' => __( 'Show Category', 'renev' ),
                'type' => \Elementor\Controls_Manager::SWITCHER,
                'label_on' => __( 'Show', 'renev' ),
                'label_off' => __( 'Hide', 'renev' ),
                'return_value' => 'yes',
                'default' => 'yes',
                'condition' => [
                    'project_layout' => 'layout-4',
                ]
            ]
        );
        $this->add_control(
			'sub_title',
			[
				'label' => esc_html__( 'Sub Title', 'renev' ),
				'type' => Controls_Manager::TEXT,
				'default' => esc_html__( 'Showcasing Our Impact', 'renev' ),
				'label_block' => true,
                'condition' => [
                    'project_layout' => 'layout-1',
                ]
			]
		);
        $this->add_control(
			'title_content',
			[
				'label' => esc_html__( 'Content Title', 'renev' ),
				'type' => Controls_Manager::TEXTAREA,
				'default' => esc_html__( 'Our Portfolio showcase', 'renev' ),
				'label_block' => true,
                'condition' => [
                    'project_layout' => 'layout-1',
                ]
			]
		);
        $this->add_control(
            'heading_image',
            [
                'label' => __( 'Icon', 'renev' ),
                'type' => Controls_Manager::MEDIA,
                'default' => [
                    'url' => Utils::get_placeholder_image_src(),
                ],
                'condition' => [
                    'project_layout' => 'layout-1',
                ]
            ]
        );
        $this->add_control(
			'project_arrow_icon',
			[
				'label'       => __( 'Arrow Icon', 'renev' ),
				'type'        => Controls_Manager::ICONS,
				'label_block' => true,
                'condition' => [
                    'project_layout' => 'layout-2',
                ]
			]
		);
        $this->add_control(
            'btn_area',
            [
                'label' => __( 'button Text', 'renev' ),
                'type' => Controls_Manager::TEXT,
                'default' => __( 'our experienced team', 'renev' ),
                'label_block' => true,
                'condition' => [
                    'project_layout' => 'layout-3',
                ]
            ]
        ); 
        $this->add_control(
            'top_column',
            [
                'label' => esc_html__( 'Top Row Column Count', 'renev' ),
                'type' => \Elementor\Controls_Manager::NUMBER,
                'default' => 3,
                'min' => 1,
                'max' => 6,
                'condition' => [
                    'project_layout' => 'layout-3',
                ]
            ]
        );
        
        $this->add_control(
            'bottom_column',
            [
                'label' => esc_html__( 'Bottom Row Column Count', 'renev' ),
                'type' => \Elementor\Controls_Manager::NUMBER,
                'default' => 2,
                'min' => 1,
                'max' => 6,
                'condition' => [
                    'project_layout' => 'layout-3',
                ]
            ]
        );
        
        $this->end_controls_section();

        // Project Section Style
        $this->start_controls_section(
            'project_section_style',
            [
                'label' => __( 'Project Section', 'renev' ),
                'tab'   => Controls_Manager::TAB_STYLE,
                'condition' => [
                    'project_layout' => 'layout-1',
                ]
            ]
        );
        $this->add_control(
            'project_section_background',
            [
                'label' => __( 'Background', 'renev' ),
                'type' => Controls_Manager::COLOR,
                'selectors' => [
                    '{{WRAPPER}} .portfolio1-section-area.sp6' => 'background: {{VALUE}}',
                ],
            ]
        );
        $this->add_responsive_control(
            'project_section_padding',
            [
                'label' => __( 'Content Padding', 'renev' ),
                'type' => Controls_Manager::DIMENSIONS,
                'size_units' => [ 'px', 'em', '%' ],
                'selectors' => [
                    '{{WRAPPER}} .portfolio1-section-area.sp6' => 'padding: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
                ],
            ]
        );
        $this->add_responsive_control(
            'project_section_height',
            [
                'label'          => __('Section Height', 'renev'),
                'type'           => Controls_Manager::SLIDER,
                'size_units'     => ['%', 'px','vw'],
                'range'          => [
                    '%'  => [
                        'min' => 1,
                        'max' => 100,
                    ],
                    'px' => [
                        'min' => 1,
                        'max' => 1000,
                    ],
                    'vw' => [
                        'min' => 1,
                        'max' => 100,
                    ],
                ],
                'selectors' => [
                    '{{WRAPPER}} .portfolio1-section-area' => 'height: {{SIZE}}{{UNIT}};',
                    
                ],
            ]
        );
        $this->end_controls_section();

        // Sub Title in here 
        $this->start_controls_section(
            'project_sub_title',
            [
                'label' => __( 'Sub Title', 'renev' ),
                'tab'   => Controls_Manager::TAB_STYLE,
                'condition' => [
                    'project_layout' => 'layout-1',
                ]
            ]
        );
        $this->add_control(
            'project_subtitle_color',
            [
                'label' => __( 'Sub Title Color', 'renev' ),
                'type' => Controls_Manager::COLOR,
                'selectors' => [
                    '{{WRAPPER}} .heading1 h5' => 'color: {{VALUE}}',
                ],
            ]
        );
        $this->add_group_control(
            Group_Control_Typography::get_type(),
            [
                'name' => 'project_subtitl_typography',
                'selector' => '{{WRAPPER}} .heading1 h5',
            ]
        );
        $this->add_responsive_control(
            'project_subtitl_margin',
            [
                'label' => __( 'Sub Title Margin', 'renev' ),
                'type' => Controls_Manager::DIMENSIONS,
                'size_units' => [ 'px', 'em', '%' ],
                'selectors' => [
                    '{{WRAPPER}} .heading1 h5' => 'margin: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
                ],
            ]
        );
        $this->end_controls_section();

        // Content Title
        $this->start_controls_section(
            'project_content_title',
            [
                'label' => __( 'Project Content', 'renev' ),
                'tab'   => Controls_Manager::TAB_STYLE,
                'condition' => [
                    'project_layout' => 'layout-1',
                ]
            ]
        );
        $this->add_control(
            'project_content_title_color',
            [
                'label' => __( 'Content Color', 'renev' ),
                'type' => Controls_Manager::COLOR,
                'selectors' => [
                    '{{WRAPPER}} .heading1 h2' => 'color: {{VALUE}}',
                ],
            ]
        );
        $this->add_group_control(
            Group_Control_Typography::get_type(),
            [
                'name' => 'project_content_title_typography',
                'selector' => '{{WRAPPER}} .heading1 h2',
            ]
        );
        $this->add_responsive_control(
            'project_content_title_margin',
            [
                'label' => __( 'Content Margin', 'renev' ),
                'type' => Controls_Manager::DIMENSIONS,
                'size_units' => [ 'px', 'em', '%' ],
                'selectors' => [
                    '{{WRAPPER}} .heading1 h2' => 'margin: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
                ],
            ]
        );
        $this->end_controls_section();

         // Arrow Style
         $this->start_controls_section(
            'arrow_style',
            [
                'label' => __( 'Arrow Section', 'renev' ),
                'tab'   => Controls_Manager::TAB_STYLE,
                'condition' => [
                    'project_layout' => 'layout-1',
                ]
            ]
        );
        $this->add_responsive_control(
            'arrow-button_width',
            [
                'label'          => __('width', 'renev'),
                'type'           => Controls_Manager::SLIDER,
                'size_units'     => ['%', 'px','vw'],
                'range'          => [
                    '%'  => [
                        'min' => 1,
                        'max' => 100,
                    ],
                    'px' => [
                        'min' => 1,
                        'max' => 1000,
                    ],
                    'vw' => [
                        'min' => 1,
                        'max' => 100,
                    ],
                ],
                    'selectors' => [
                        '{{WRAPPER}} .portfolio1-section-area .portfolio-slider-area .owl-nav button' => 'width: {{SIZE}}{{UNIT}}; height: {{SIZE}}{{UNIT}};',
                        
                    ],
            ]
        );
        $this->add_responsive_control(
            'rrow-button_height',
            [
                'label'          => __('height', 'renev'),
                'type'           => Controls_Manager::SLIDER,
                'size_units'     => ['%', 'px','vw'],
                'range'          => [
                    '%'  => [
                        'min' => 1,
                        'max' => 100,
                    ],
                    'px' => [
                        'min' => 1,
                        'max' => 1000,
                    ],
                    'vw' => [
                        'min' => 1,
                        'max' => 100,
                    ],
                ],
                    'selectors' => [
                        '{{WRAPPER}} .portfolio1-section-area .portfolio-slider-area .owl-nav button' => 'height: {{SIZE}}{{UNIT}}; height: {{SIZE}}{{UNIT}};',
                        
                    ],
            ]
        );
        $this->add_responsive_control(
            'arrow-button_margin',
            [
                'label' => __( 'margin', 'renev' ),
                'type' => Controls_Manager::DIMENSIONS,
                'size_units' => [ 'px', 'em', '%' ],
                'selectors' => [
                    '{{WRAPPER}} .portfolio-slider-area .owl-nav button.owl-prev' => 'margin: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
                ],
            ]
        );
        $this->add_control(
            'arrow-button_color',
            [
                'label' => __( 'Arrow Icon Color', 'renev' ),
                'type' => Controls_Manager::COLOR,
                'selectors' => [
                    '{{WRAPPER}} .portfolio1-section-area .portfolio-slider-area .owl-nav button' => 'color: {{VALUE}}',
                    
                ],
            ]
        );
        $this->add_control(
            'arrow-button_hover_color',
            [
                'label' => __( 'Arrow Icon Hover Color', 'renev' ),
                'type' => Controls_Manager::COLOR,
                'selectors' => [
                    '{{WRAPPER}} .portfolio1-section-area .portfolio-slider-area .owl-nav button:hover' => 'color: {{VALUE}}',
                    
                ],
            ]
        );
        $this->add_control(
            'arrow-button_bg',
            [
                'label' => __( 'Arrow Button Bg', 'renev' ),
                'type' => Controls_Manager::COLOR,
                'selectors' => [
                    '{{WRAPPER}} .portfolio1-section-area .portfolio-slider-area .owl-nav button' => 'background: {{VALUE}}',
                    
                ],
            ]
        );
        $this->add_group_control(
            Group_Control_Background::get_type(),
            [
                'name' => 'arrow-button_hover_bg',
                'label' => __( 'Arrow Button Bg Hover', 'renev' ),
                'types' => [ 'classic', 'gradient', 'video' ],
                'selector' => '{{WRAPPER}} .portfolio1-section-area .portfolio-slider-area .owl-nav button:hover',
            ]
        );
        $this->add_control(
            'arrow-button_border_radius',
            [
                'label' => esc_html__( 'Button Border Radius', 'renev' ),
                'type' => Controls_Manager::DIMENSIONS,
                'size_units' => [ 'px', '%', 'em', 'rem', 'custom' ],
                'selectors' => [
                    '{{WRAPPER}} .portfolio1-section-area .portfolio-slider-area .owl-nav button' => 'border-radius: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
                ],
            ]
        );
        $this->end_controls_section();

         // Project Post Thumbnail Style
         $this->start_controls_section(
            'project_style',
            [
                'label' => __( 'Project Thumbnail', 'renev' ),
                'tab'   => Controls_Manager::TAB_STYLE,
            ]
        );
        $this->add_control(
            'project_img_border_radius',
            [
                'label' => esc_html__( 'Img Border Radius', 'renev' ),
                'type' => Controls_Manager::DIMENSIONS,
                'size_units' => [ 'px', '%', 'em', 'rem', 'custom' ],
                'selectors' => [
                    '{{WRAPPER}} .portfolio1-section-area .portfolio-slider-area .portfolio-boxarea .img1 img' => 'border-radius: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
                    '{{WRAPPER}} .portfolio-slider2-boxarea .portfolio-boxarea .img1' => 'border-radius: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
                    '{{WRAPPER}} .project-inner-section-area .tab-content .tab-pane .all-project-area .portfolio-boxarea .img1 img' => 'border-radius: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
                ],
            ]
        );
        $this->add_control(
            'project_img_animation',
            [
                'label' => __( 'Image Animation', 'renev' ),
                'type' => Controls_Manager::COLOR,
                'selectors' => [
                    '{{WRAPPER}} .portfolio1-section-area .portfolio-slider-area .portfolio-boxarea .img1::after' => 'background: {{VALUE}}',
                ],
                'condition' => [
                    'project_layout' => 'layout-1',
                ]
            ]
        );
        $this->add_responsive_control(
            'project_img_height',
            [
                'label'          => __('Image Height', 'renev'),
                'type'           => Controls_Manager::SLIDER,
                'size_units'     => ['px','%', 'vh'],
                'range'          => [
                    'px' => [
                        'min' => 1,
                        'max' => 1000,
                    ],
					'%'  => [
                        'min' => 1,
                        'max' => 100,
                    ],
                    'vh' => [
                        'min' => 1,
                        'max' => 100,
                    ],
                ],
                'selectors'      => [
                    '{{WRAPPER}} .portfolio1-section-area .portfolio-slider-area .portfolio-boxarea .img1 img' => 'height: {{SIZE}}{{UNIT}}',
                    '{{WRAPPER}} .portfolio-slider2-boxarea .portfolio-boxarea .img1 img' => 'height: {{SIZE}}{{UNIT}}',
                    '{{WRAPPER}} .project-inner-section-area .tab-content .tab-pane .all-project-area .portfolio-boxarea .img1 img' => 'height: {{SIZE}}{{UNIT}}',
                ],
               
            ]
        );
        $this->add_responsive_control(
            'project_img_margin',
            [
                'label' => __( ' Margin', 'renev' ),
                'type' => Controls_Manager::DIMENSIONS,
                'size_units' => [ 'px', 'em', '%' ],
                'selectors' => [
                    '{{WRAPPER}} .portfolio-header.heading1' => 'margin: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
                    '{{WRAPPER}} .portfolio-slider2-boxarea .portfolio-boxarea .content-area' => 'margin: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
                    '{{WRAPPER}} .project-inner-section-area .tab-content .tab-pane .all-project-area .portfolio-boxarea' => 'margin: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
                ],
            ]
        );
        $this->end_controls_section();

        // Project Post Box Style
        $this->start_controls_section(
            'project_box-style',
            [
                'label' => __( 'Project Box', 'renev' ),
                'tab'   => Controls_Manager::TAB_STYLE,
                'condition' => [
                    'project_layout' => 'layout-1',
                ]
            ]
        );

        $this->add_responsive_control(
            'project_box_padding',
            [
                'label' => __( 'Padding', 'renev' ),
                'type' => Controls_Manager::DIMENSIONS,
                'size_units' => [ 'px', 'em', '%' ],
                'selectors' => [
                    '{{WRAPPER}} .portfolio1-section-area .portfolio-slider-area .portfolio-boxarea .arrow-content' => 'padding: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
                ],
            ]
        );
        $this->add_responsive_control(
            'project_box_margin',
            [
                'label' => __( ' Arrow Margin', 'renev' ),
                'type' => Controls_Manager::DIMENSIONS,
                'size_units' => [ 'px', 'em', '%' ],
                'selectors' => [
                    '{{WRAPPER}} .portfolio1-section-area .portfolio-slider-area .portfolio-boxarea .arrow-content .arrow' => 'margin: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
                ],
            ]
        );
        $this->add_control(
            'project_box_background',
            [
                'label' => __( 'Background', 'renev' ),
                'type' => Controls_Manager::COLOR,
                'selectors' => [
                    '{{WRAPPER}} .portfolio1-section-area .portfolio-slider-area .portfolio-boxarea .arrow-content' => 'background: {{VALUE}}',
                ],
            ]
        );
        $this->add_control(
            'project_box_radius',
            [
                'label' => esc_html__( 'Border Radius', 'renev' ),
                'type' => Controls_Manager::DIMENSIONS,
                'size_units' => [ 'px', '%', 'em', 'rem', 'custom' ],
                'selectors' => [
                    '{{WRAPPER}} .portfolio1-section-area .portfolio-slider-area .portfolio-boxarea .arrow-content' => 'border-radius: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
                ],
            ]
        );
        $this->end_controls_section();

         // Project Post Box Style
         $this->start_controls_section(
            'project_box_style',
            [
                'label' => __( 'Project arrow Box', 'renev' ),
                'tab'   => Controls_Manager::TAB_STYLE,
            ]
        );
        $this->add_control(
            'project_arrow_box_background',
            [
                'label' => __( 'Background', 'renev' ),
                'type' => Controls_Manager::COLOR,
                'selectors' => [
                    '{{WRAPPER}} .portfolio1-section-area .portfolio-slider-area .portfolio-boxarea .arrow-content .arrow a' => 'background-color: {{VALUE}}',
                    '{{WRAPPER}} .portfolio-slider2-boxarea .portfolio-boxarea .content-area .arrow a' => 'background-color: {{VALUE}}',
                    '{{WRAPPER}} .project-inner-section-area .tab-content .tab-pane .all-project-area .portfolio-boxarea .arrow-content .arrow a span' => 'background-color: {{VALUE}}',
                ],
            ]
        );
        $this->add_control(
            'project_box_border_radius',
            [
                'label' => esc_html__( 'Border Radius', 'renev' ),
                'type' => Controls_Manager::DIMENSIONS,
                'size_units' => [ 'px', '%', 'em', 'rem', 'custom' ],
                'selectors' => [
                    '{{WRAPPER}} .portfolio1-section-area .portfolio-slider-area .portfolio-boxarea .arrow-content .arrow a' => 'border-radius: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
                    '{{WRAPPER}} .portfolio-slider2-boxarea .portfolio-boxarea .content-area .arrow a' => 'border-radius: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
                    '{{WRAPPER}} .project-inner-section-area .tab-content .tab-pane .all-project-area .portfolio-boxarea .arrow-content .arrow a span' => 'border-radius: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
                ],
            ]
        );
        $this->add_responsive_control(
            'project_box_height',
            [
                'label'          => __('Box Height', 'renev'),
                'type'           => Controls_Manager::SLIDER,
                'size_units'     => ['px','%', 'vh'],
                'range'          => [
                    'px' => [
                        'min' => 1,
                        'max' => 1000,
                    ],
					'%'  => [
                        'min' => 1,
                        'max' => 100,
                    ],
                    'vh' => [
                        'min' => 1,
                        'max' => 100,
                    ],
                ],
                'selectors'      => [
                    '{{WRAPPER}} .portfolio1-section-area .portfolio-slider-area .portfolio-boxarea .arrow-content .arrow a' => 'height: {{SIZE}}{{UNIT}}',
                    '{{WRAPPER}} .portfolio-slider2-boxarea .portfolio-boxarea .content-area .arrow a' => 'height: {{SIZE}}{{UNIT}}',
                    '{{WRAPPER}} .project-inner-section-area .tab-content .tab-pane .all-project-area .portfolio-boxarea .arrow-content .arrow a span' => 'height: {{SIZE}}{{UNIT}}',
                ],
               
            ]
        );
        $this->add_responsive_control(
            'project_box_width',
            [
                'label'          => __('Box Width:', 'renev'),
                'type'           => Controls_Manager::SLIDER,
                'size_units'     => ['px','%', 'vh'],
                'range'          => [
                    'px' => [
                        'min' => 1,
                        'max' => 1000,
                    ],
					'%'  => [
                        'min' => 1,
                        'max' => 100,
                    ],
                    'vh' => [
                        'min' => 1,
                        'max' => 100,
                    ],
                ],
                'selectors'      => [
                    '{{WRAPPER}} .portfolio1-section-area .portfolio-slider-area .portfolio-boxarea .arrow-content .arrow a' => 'width: {{SIZE}}{{UNIT}}',
                    '{{WRAPPER}} .portfolio-slider2-boxarea .portfolio-boxarea .content-area .arrow a' => 'width: {{SIZE}}{{UNIT}}',
                    '{{WRAPPER}} .project-inner-section-area .tab-content .tab-pane .all-project-area .portfolio-boxarea .arrow-content .arrow a span' => 'width: {{SIZE}}{{UNIT}}',
                ],
               
            ]
        );
        $this->end_controls_section();

        // Project Post Icon Style
        $this->start_controls_section(
            'project_icon_style',
            [
                'label' => __( 'Project arrow Icon', 'renev' ),
                'tab'   => Controls_Manager::TAB_STYLE,
            ]
        );
        $this->add_group_control(
            Group_Control_Background::get_type(),
            [
                'name' => 'project_icon_background',
                'label' => __( 'Background', 'renev' ),
                'types' => [ 'classic', 'gradient', 'video' ],
                'selector' => '{{WRAPPER}} .portfolio1-section-area .portfolio-slider-area .portfolio-boxarea .arrow-content .arrow a span',
                'condition' => [
                    'project_layout!' => ['layout-2', 'layout-4']
                ]
            ]
        );
        $this->add_control(
            'project_icon_color',
            [
                'label' => __( 'color', 'renev' ),
                'type' => Controls_Manager::COLOR,
                'selectors' => [
                    '{{WRAPPER}} .portfolio1-section-area .portfolio-slider-area .portfolio-boxarea .arrow-content .arrow a span' => 'color: {{VALUE}}',
                    '{{WRAPPER}} .portfolio-slider2-boxarea .portfolio-boxarea .content-area .arrow a i' => 'color: {{VALUE}}',
                    '{{WRAPPER}} .portfolio-slider2-boxarea .portfolio-boxarea .content-area .arrow a svg path' => 'stroke: {{VALUE}}',
                    '{{WRAPPER}} .project-inner-section-area .tab-content .tab-pane .all-project-area .portfolio-boxarea .arrow-content .arrow a span' => 'stroke: {{VALUE}}',
                ],
            ]
        );

        $this->add_control(
            'project_icon_hover_color',
            [
                'label' => __( 'Hover color', 'renev' ),
                'type' => Controls_Manager::COLOR,
                'selectors' => [
                    '{{WRAPPER}} .portfolio-slider2-boxarea .portfolio-boxarea:hover .content-area .arrow a i' => 'color: {{VALUE}}',
                    '{{WRAPPER}} .portfolio-slider2-boxarea .portfolio-boxarea:hover .content-area .arrow a svg path' => 'stroke: {{VALUE}}',
                ],
                'condition' => [
                    'project_layout' => ['layout-2', 'layout-4']
                ]
            ]
        );
        $this->add_control(
            'project_icon_border_radius',
            [
                'label' => esc_html__( 'Icon Border Radius', 'renev' ),
                'type' => Controls_Manager::DIMENSIONS,
                'size_units' => [ 'px', '%', 'em', 'rem', 'custom' ],
                'selectors' => [
                    '{{WRAPPER}} .portfolio1-section-area .portfolio-slider-area .portfolio-boxarea .arrow-content .arrow a span' => 'border-radius: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
                ],
                'condition' => [
                    'project_layout!' => ['layout-2', 'layout-4']
                ]
            ]
        );
        $this->add_responsive_control(
            'project_icon_height',
            [
                'label'          => __('Icon Height', 'renev'),
                'type'           => Controls_Manager::SLIDER,
                'size_units'     => ['px','%', 'vh'],
                'range'          => [
                    'px' => [
                        'min' => 1,
                        'max' => 1000,
                    ],
                    '%'  => [
                        'min' => 1,
                        'max' => 100,
                    ],
                    'vh' => [
                        'min' => 1,
                        'max' => 100,
                    ],
                ],
                'selectors'      => [
                    '{{WRAPPER}} .portfolio1-section-area .portfolio-slider-area .portfolio-boxarea .arrow-content .arrow a span' => 'height: {{SIZE}}{{UNIT}}',
                    '{{WRAPPER}} .portfolio-slider2-boxarea .portfolio-boxarea .content-area .arrow a svg' => 'height: {{SIZE}}{{UNIT}}',
                    '{{WRAPPER}} .portfolio-slider2-boxarea .portfolio-boxarea .content-area .arrow a i' => 'height: {{SIZE}}{{UNIT}}',
                ], 
                'condition' => [
                    'project_layout!' => 'layout-4',
                ]
            ]
        );
        $this->add_responsive_control(
            'project_icon_width',
            [
                'label'          => __('Icon Width:', 'renev'),
                'type'           => Controls_Manager::SLIDER,
                'size_units'     => ['px','%', 'vh'],
                'range'          => [
                    'px' => [
                        'min' => 1,
                        'max' => 1000,
                    ],
                    '%'  => [
                        'min' => 1,
                        'max' => 100,
                    ],
                    'vh' => [
                        'min' => 1,
                        'max' => 100,
                    ],
                ],
                'selectors'      => [
                    '{{WRAPPER}} .portfolio1-section-area .portfolio-slider-area .portfolio-boxarea .arrow-content .arrow a span' => 'width: {{SIZE}}{{UNIT}}',
                    '{{WRAPPER}} .portfolio-slider2-boxarea .portfolio-boxarea .content-area .arrow a svg' => 'width: {{SIZE}}{{UNIT}}',
                    '{{WRAPPER}} .portfolio-slider2-boxarea .portfolio-boxarea .content-area .arrow a i' => 'width: {{SIZE}}{{UNIT}}',
                    '{{WRAPPER}} .project-inner-section-area .tab-content .tab-pane .all-project-area .portfolio-boxarea .arrow-content .arrow a span' => 'font-size: {{SIZE}}{{UNIT}}',
                ],
                
            ]
        );
        $this->end_controls_section();

        // Project Excerpt Style
        $this->start_controls_section(
            'project_excerpt_style',
            [
                'label' => __( 'Project Excerpt', 'renev' ),
                'tab'   => Controls_Manager::TAB_STYLE,
            ]
        );
        $this->add_control(
            'project_excerpt_color',
            [
                'label' => __( 'Excerpt Color', 'renev' ),
                'type' => Controls_Manager::COLOR,
                'selectors' => [
                    '{{WRAPPER}} .portfolio1-section-area .portfolio-slider-area .portfolio-boxarea .arrow-content .content-area p' => 'color: {{VALUE}}',
                    '{{WRAPPER}} .portfolio-slider2-boxarea .portfolio-boxarea .content-area .content p' => 'color: {{VALUE}}',
                    '{{WRAPPER}} .project-inner-section-area .tab-content .tab-pane .all-project-area .portfolio-boxarea .arrow-content .content-area p' => 'color: {{VALUE}}',
                ],
            ]
        );
        $this->add_group_control(
            Group_Control_Typography::get_type(),
            [
                'name' => 'project_excerpt_typography',
                'selector' => '{{WRAPPER}} .portfolio1-section-area .portfolio-slider-area .portfolio-boxarea .arrow-content .content-area p, {{WRAPPER}} .portfolio-slider2-boxarea .portfolio-boxarea .content-area .content p, {{WRAPPER}} .project-inner-section-area .tab-content .tab-pane .all-project-area .portfolio-boxarea .arrow-content .content-area p',
            ]
        );
         $this->add_responsive_control(
            'project_excerpt_margin',
            [
                'label' => __( ' Margin', 'renev' ),
                'type' => Controls_Manager::DIMENSIONS,
                'size_units' => [ 'px', 'em', '%' ],
                'selectors' => [
                    '{{WRAPPER}} .portfolio1-section-area .portfolio-slider-area .portfolio-boxarea .arrow-content .content-area p' => 'margin: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
                    '{{WRAPPER}} .portfolio-slider2-boxarea .portfolio-boxarea .content-area .content p' => 'margin: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
                    '{{WRAPPER}} .project-inner-section-area .tab-content .tab-pane .all-project-area .portfolio-boxarea .arrow-content .content-area p' => 'margin: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
                ],
            ]
        );
        $this->end_controls_section();

        // Project Title 
        $this->start_controls_section(
            'project_title_style',
            [
                'label' => __( 'Project Title', 'renev' ),
                'tab'   => Controls_Manager::TAB_STYLE,
            ]
        );
        $this->add_control(
            'project_title_color',
            [
                'label' => __( 'Title Color', 'renev' ),
                'type' => Controls_Manager::COLOR,
                'selectors' => [
                    '{{WRAPPER}} .portfolio1-section-area .portfolio-slider-area .portfolio-boxarea .arrow-content .content-area a' => 'color: {{VALUE}}',
                    '{{WRAPPER}} .portfolio-slider2-boxarea .portfolio-boxarea .content-area .content a' => 'color: {{VALUE}}',
                    '{{WRAPPER}} .project-inner-section-area .tab-content .tab-pane .all-project-area .portfolio-boxarea .arrow-content .content-area a' => 'color: {{VALUE}}',
                ],
            ]
        );
        
        $this->add_control(
            'project_title_hover_color',
            [
                'label' => __( 'Title Hover Color', 'renev' ),
                'type' => Controls_Manager::COLOR,
                'selectors' => [
                    '{{WRAPPER}} .portfolio1-section-area .portfolio-slider-area .portfolio-boxarea .arrow-content .content-area a:hover' => 'color: {{VALUE}}',
                    '{{WRAPPER}} .portfolio-slider2-boxarea .portfolio-boxarea .content-area .content a:hover' => 'color: {{VALUE}}',
                    '{{WRAPPER}} .project-inner-section-area .tab-content .tab-pane .all-project-area .portfolio-boxarea .arrow-content .content-area a:hover' => 'color: {{VALUE}}',
                ],
            ]
        );
        $this->add_group_control(
            Group_Control_Typography::get_type(),
            [
                'name' => 'project_title_typography',
                'selector' => '{{WRAPPER}} .portfolio1-section-area .portfolio-slider-area .portfolio-boxarea .arrow-content .content-area a, {{WRAPPER}} .portfolio-slider2-boxarea .portfolio-boxarea .content-area .content a, {{WRAPPER}} .project-inner-section-area .tab-content .tab-pane .all-project-area .portfolio-boxarea .arrow-content .content-area a',
            ]
        );
        $this->end_controls_section();

        // Pagination style
        $this->start_controls_section(
            'pagination_style',
            [
                'label' => __( 'Pagination', 'renev' ),
                'tab'   => Controls_Manager::TAB_STYLE,
                'condition' => [
                    'project_layout' => 'layout-4',
                ]
            ]
        );
        $this->add_control(
            'pagination_color',
            [
                'label' => __( 'Color', 'renev' ),
                'type' => Controls_Manager::COLOR,
                'selectors' => [
                    '{{WRAPPER}} .pagination-area ul li a, .pagination-area ul li span' => 'color: {{VALUE}}',
                ],
            ]
        );     
        $this->add_control(
            'pagination_hover_color',
            [
                'label' => __( 'Hover Color', 'renev' ),
                'type' => Controls_Manager::COLOR,
                'selectors' => [
                    '{{WRAPPER}} .pagination-area ul li a.active, .pagination-area ul li span.active, .pagination-area ul li a.focus, .pagination-area ul li span.focus, .page-link:focus, .pagination-area ul li a:hover, .pagination-area ul li span:hover' => 'color: {{VALUE}}',
                ],
            ]
        );     
        $this->add_control(
            'pagination_bg_color',
            [
                'label' => __( 'Background Color', 'renev' ),
                'type' => Controls_Manager::COLOR,
                'selectors' => [
                    '{{WRAPPER}} .pagination-area ul li a, .pagination-area ul li span' => 'background-color: {{VALUE}}',
                ],
            ]
        ); 
        $this->add_control(
            'pagination_bg_hover_color',
            [
                'label' => __( 'Background Hover Color', 'renev' ),
                'type' => Controls_Manager::COLOR,
                'selectors' => [
                    '{{WRAPPER}} .pagination-area ul li a.active, .pagination-area ul li span.active, .pagination-area ul li a.focus, .pagination-area ul li span.focus, .page-link:focus, .pagination-area ul li a:hover, .pagination-area ul li span:hover' => 'background-color: {{VALUE}}',
                ],
            ]
        ); 
        $this->add_group_control(
            Group_Control_Typography::get_type(),
            [
                'name' => 'pagination_typography',
                'selector' => '{{WRAPPER}} .pagination-area ul li a, .pagination-area ul li span',
            ]
        ); 
        $this->add_responsive_control(
            'pagination_margin',
            [
                'label' => __( 'Margin', 'renev' ),
                'type' => Controls_Manager::DIMENSIONS,
                'size_units' => [ 'px', 'em', '%' ],
                'selectors' => [
                    '{{WRAPPER}} .pagination-area ul li a, .pagination-area ul li span' => 'margin: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
                ],
            ]
        );
        $this->add_responsive_control(
            'pagination_size',
            [
                'label'          => __('Size', 'renev'),
                'type'           => Controls_Manager::SLIDER,
                'size_units'     => ['%', 'px','vw'],
                'range'          => [
                    '%'  => [
                        'min' => 1,
                        'max' => 100,
                    ],
                    'px' => [
                        'min' => 1,
                        'max' => 1000,
                    ],
                    'vw' => [
                        'min' => 1,
                        'max' => 100,
                    ],
                ],
                'selectors' => [
                    '{{WRAPPER}} .pagination-area ul li a, .pagination-area ul li span' => 'width: {{SIZE}}{{UNIT}}; height: {{SIZE}}{{UNIT}};',
                    
                ],
            ]
        );
        $this->add_group_control(
            Group_Control_Border::get_type(),
            [
                'name' => 'pagination_border',
                'selector' => '{{WRAPPER}} .pagination-area ul li a, .pagination-area ul li span',
            ]
        );
        $this->add_control(
            'pagination_border_radius',
            [
                'label' => esc_html__( 'Border Radius', 'renev' ),
                'type' => Controls_Manager::DIMENSIONS,
                'size_units' => [ 'px', '%', 'em', 'rem', 'custom' ],
                'selectors' => [
                    '{{WRAPPER}} .pagination-area ul li a, .pagination-area ul li span' => 'border-radius: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
                ],
            ]
        );
        $this->end_controls_section();

    }

    // Get All Projects
    public function get_all_projects()
    {

        $wp_query = get_posts([
            'post_type' => 'renev_project',
            'orderby' => 'date',
            'posts_per_page' => -1,
        ]);

        $options = ['none' => 'None'];
        foreach ($wp_query as $projects) {
            $options[$projects->ID] = $projects->post_name;
        }

        return $options;
    }

    private function get_project_categories() {
        $categories = get_terms([
            'taxonomy'   => 'project_category',
            'hide_empty' => true,
        ]);
    
        $options = ['' => __('All Categories', 'renev')];
        if (!empty($categories) && !is_wp_error($categories)) {
            foreach ($categories as $category) {
                $options[$category->slug] = $category->name;
            }
        }
        return $options;
    }

    // Render
	protected function render() {
        $settings = $this->get_settings_for_display();
        $layout = $settings['project_layout'];
        $number_of_post = !empty($settings['post_per_page']) ? $settings['post_per_page'] : 5;
        $top_col_count = !empty($settings['top_column']) ? $settings['top_column'] : 3;
        $bottom_col_count = !empty($settings['bottom_column']) ? $settings['bottom_column'] : 2;

        ?>
            <?php
                if ( $layout) {
                    include('project/'.$layout.'.php');
                }
            ?>
            
        <?php
    
    }
    

}
$widgets_manager->register( new \Renev_Project() );