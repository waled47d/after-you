<?php
/**
 * Happyden Team Widget.
 *
 *
 * @since 1.0.0
 */
namespace Elementor;
use Elementor\Controls_Manager;
use Elementor\Group_Control_Border;
use Elementor\Group_Control_Box_Shadow;
use Elementor\Group_Control_Typography;
use Elementor\Widget_Base;
use Elementor\Group_Control_Background;
use Elementor\Group_Control_Css_Filter;
use Elementor\Icons_Manager;
use Elementor\Utils;
use Elementor\Repeater;
use Elementor\URL;
use \Elementor\Control_Media;

if (!defined('ABSPATH')) {
    exit;
}
// If this file is called directly, abort.
class RenevTab extends Widget_Base {
    public function get_name() {
        return 'renev-tab';
    }
    public function get_title() {
        return __('Tab', 'renev');
    }
    public function get_icon() {
        return ('eicon-person');
    }
    public function get_categories() {
        return ['renev-addons'];
    }
    public function get_keywords() {
        return ['tab', 'tab form', 'form'];
    }

    protected function register_controls() {

        $this->start_controls_section('general_section',
            [
                'label' => __('General', 'renev'),
                'tab'   => Controls_Manager::TAB_CONTENT,
            ]
        );
        $this->add_control(
            'tab_layout',
            [
                'label' => esc_html__('Select Style', 'renev'),
                'type' => Controls_Manager::SELECT,
                'options' => [
                    'layout-1' => esc_html__('layout 1', 'renev'),
                    'layout-2' => esc_html__('layout 2', 'renev'),
                ],
                'default' => 'layout-1',
            ]
        );
        $repeater = new Repeater();

        $repeater->add_control(
            'box_title',
            [
                'label' => esc_html__('Tab Title', 'renev'),
                'type' => Controls_Manager::TEXT,
                'default' => esc_html__('Tab Title', 'renev'),
            ]
        );
        $repeater->add_control(
            'tab_image',
            [
                'label' => esc_html__('Tab Image', 'renev'),
                'type' => Controls_Manager::MEDIA,
            ]
        );
        $repeater->add_control(
            'renev_tab_builder',
            [
                'label' => __('Select Template', 'renev'),
                'type' => Controls_Manager::SELECT,
                'options' => $this->renev_tab_builder(),
            ]
        );
        $this->add_control(
            'tab_item',
            [
                'label' => __('Tabs', 'renev'),
                'type' => Controls_Manager::REPEATER,
                'fields' => $repeater->get_controls(),
                'default' => [],
                'title_field' => '{{{ box_title }}}',
            ]
        );
        
        $this->end_controls_section();

        //Tab Style
        $this->start_controls_section(
            'tab_item_style',
            [
                'label' => __( 'Tab Box', 'renev' ),
                'tab'   => Controls_Manager::TAB_STYLE,
            ]
        );
        $this->add_control(
            'tab_item_background',
            [
                'label' => __( 'Box Background', 'renev' ),
                'type' => Controls_Manager::COLOR,
                'selectors' => [
                    '{{WRAPPER}} .service-tabs-area .nav li button' => 'background: {{VALUE}}',
                    '{{WRAPPER}} .faq-widget-area ul' => 'background: {{VALUE}}',
                ],
            ]
        );
        $this->add_responsive_control(
            'tab_item_margin',
            [
                'label' => __( 'Margin', 'renev' ),
                'type' => Controls_Manager::DIMENSIONS,
                'size_units' => [ 'px', 'em', '%' ],
                'selectors' => [
                    '{{WRAPPER}} .faq-widget-area ul' => 'margin: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
                ],
            ]
        );
        $this->add_group_control(
            Group_Control_Background::get_type(),
            [
                'name' => 'tab_item_active_background',
                'label' => __( 'Active Background', 'renev' ),
                'types' => [ 'classic', 'gradient', 'video' ],
                'selector' => '{{WRAPPER}} .service-tabs-area .nav li button.active',
                'condition' => [
                    'tab_layout!' => 'layout-2',
                ],
            ]
        );
        $this->add_control(
            'tab_box_border_radius',
            [
                'label' => esc_html__( 'Border Radius', 'renev' ),
                'type' => Controls_Manager::DIMENSIONS,
                'size_units' => [ 'px', '%', 'em', 'rem', 'custom' ],
                'selectors' => [
                    '{{WRAPPER}} .service-tabs-area .nav li button' => 'border-radius: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
                    '{{WRAPPER}} .faq-widget-area ul' => 'border-radius: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
                ],
            ]
        );
        $this->add_control(
            'tab_item_gap',
            [
                'label'      => __( 'Gap', 'renev' ),
                'type'       => Controls_Manager::SLIDER,
                'size_units' => [ 'px', 'em', '%' ],
                'range'      => [
                    'px' => [
                        'min' => 0,
                        'max' => 1000,
                    ],
                ],
                'selectors'  => [
                    '{{WRAPPER}} .service-tabs-area .nav' => 'gap: {{SIZE}}{{UNIT}};',
                ],
                'condition' => [
                    'tab_layout!' => 'layout-2',
                ],
            ]
        );
        $this->add_responsive_control(
            'tab_item_padding',
            [
                'label' => __( 'Tab Padding', 'renev' ),
                'type' => Controls_Manager::DIMENSIONS,
                'size_units' => [ 'px', 'em', '%' ],
                'selectors' => [
                    '{{WRAPPER}} .service-tabs-area .nav li button .text' => 'padding: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
                    '{{WRAPPER}} .faq-widget-area ul' => 'padding: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
                ],
            ]
        );
        $this->end_controls_section();

        //Tab Button Style
        $this->start_controls_section(
            'tab_item_button_style',
            [
                'label' => __( 'Tab Button', 'renev' ),
                'tab'   => Controls_Manager::TAB_STYLE,
                'condition' => [
                    'tab_layout' => 'layout-2',
                ],
            ]
        );
        $this->add_control(
            'tab_item_button_background',
            [
                'label' => __( 'Background', 'renev' ),
                'type' => Controls_Manager::COLOR,
                'selectors' => [
                    '{{WRAPPER}} .accordione .faq-widget-area ul li button' => 'background: {{VALUE}} !important',
                ],
            ]
        );
        $this->add_control(
            'tab_item_button_active_background',
            [
                'label' => __( 'Active Background', 'renev' ),
                'type' => Controls_Manager::COLOR,
                'selectors' => [
                    '{{WRAPPER}} .accordione .faq-widget-area ul li button.active' => 'background: {{VALUE}} !important',
                ],
            ]
        );
        $this->add_control(
            'tab_item_button_border_radius',
            [
                'label' => esc_html__( 'Border Radius', 'renev' ),
                'type' => Controls_Manager::DIMENSIONS,
                'size_units' => [ 'px', '%', 'em', 'rem', 'custom' ],
                'selectors' => [
                    '{{WRAPPER}} .accordione .faq-widget-area ul li button' => 'border-radius: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}}; !important',
                ],
            ]
        );
        $this->add_responsive_control(
            'tab_item_button_margin',
            [
                'label' => __( 'Margin', 'renev' ),
                'type' => Controls_Manager::DIMENSIONS,
                'size_units' => [ 'px', 'em', '%' ],
                'selectors' => [
                    '{{WRAPPER}} .accordione .faq-widget-area ul li button' => 'margin: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
                ],
            ]
        );
        $this->add_responsive_control(
            'tab_item_button_padding',
            [
                'label' => __( 'Padding', 'renev' ),
                'type' => Controls_Manager::DIMENSIONS,
                'size_units' => [ 'px', 'em', '%' ],
                'selectors' => [
                    '{{WRAPPER}} .accordione .faq-widget-area ul li button' => 'padding: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
                ],
            ]
        );
        $this->end_controls_section();

        //Tab Title Style
        $this->start_controls_section(
            'tab_title_style',
            [
                'label' => __( 'Tab Title', 'renev' ),
                'tab'   => Controls_Manager::TAB_STYLE,
            ]
        );
        $this->add_group_control(
            Group_Control_Typography::get_type(),
            [
                'name' => 'tab_title_typography',
                'selector' => '{{WRAPPER}} .service-tabs-area .nav li button .text, {{WRAPPER}} .accordione .faq-widget-area ul li button',
            ]
        );  
        $this->add_control(
            'tab_title_color',
            [
                'label' => __( 'Color', 'renev' ),
                'type' => Controls_Manager::COLOR,
                'selectors' => [
                    '{{WRAPPER}} .service-tabs-area .nav li button .text' => 'color: {{VALUE}}',
                    '{{WRAPPER}} .accordione .faq-widget-area ul li button' => 'color: {{VALUE}} !important',
                ],
            ]
        );
        $this->add_control(
            'tab_title_active_color',
            [
                'label' => __( 'Color Active', 'renev' ),
                'type' => Controls_Manager::COLOR,
                'selectors' => [
                    '{{WRAPPER}} .accordione .faq-widget-area ul li button.active' => 'color: {{VALUE}} !important',
                ],
                'condition' => [
                    'tab_layout' => 'layout-2',
                ],
            ]
        );
        $this->end_controls_section();

        //Tab Icon Style
        $this->start_controls_section(
            'tab_icon_style',
            [
                'label' => __( 'Tab Icon', 'renev' ),
                'tab'   => Controls_Manager::TAB_STYLE,
                'condition' => [
                    'tab_layout!' => 'layout-2',
                ],
            ]
        );
        $this->add_group_control(
            Group_Control_Background::get_type(),
            [
                'name' => 'tab_icon_background',
                'label' => __( 'Background', 'renev' ),
                'types' => [ 'classic', 'gradient', 'video' ],
                'selector' => '{{WRAPPER}} .service-tabs-area .nav li button .icons',
            ]
        );
        $this->add_responsive_control(
			'tab_icon_width',
			[
				'label' => esc_html__( 'Icon Width', 'renev' ),
				'type' => Controls_Manager::SLIDER,
				'size_units' => [ 'px', '%', 'em', 'rem', 'custom' ],
				'range' => [
					'px' => [
						'min' => 0,
						'max' => 1000,
						'step' => 1,
					],
					'%' => [
						'min' => 0,
						'max' => 100,
					],
				],
				'selectors' => [
					'{{WRAPPER}} .service-tabs-area .nav li button .icons' => 'width: {{SIZE}}{{UNIT}};',
				],
			]
		);
        $this->add_responsive_control(
			'tab_icon_height',
			[
				'label' => esc_html__( 'Icon Height', 'renev' ),
				'type' => Controls_Manager::SLIDER,
				'size_units' => [ 'px', '%', 'em', 'rem', 'custom' ],
				'range' => [
					'px' => [
						'min' => 0,
						'max' => 1000,
						'step' => 1,
					],
					'%' => [
						'min' => 0,
						'max' => 100,
					],
				],
				'selectors' => [
					'{{WRAPPER}} .service-tabs-area .nav li button .icons' => 'height: {{SIZE}}{{UNIT}};',
				],
			]
		);
        $this->add_responsive_control(
            'tab_icon_radius',
            [
                'label'         => __( 'Border Radius', 'renev' ),
                'type'          => Controls_Manager::DIMENSIONS,
                'size_units'    => [ 'px', '%', 'em' ],
                'selectors'     => [
                    '{{WRAPPER}} .service-tabs-area .nav li button .icons' => 'border-radius: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
                ],
            ]
        );
        $this->add_responsive_control(
            'tab_icon_margin',
            [
                'label' => __( 'Icon Margin', 'renev' ),
                'type' => Controls_Manager::DIMENSIONS,
                'size_units' => [ 'px', 'em', '%' ],
                'selectors' => [
                    '{{WRAPPER}} .service-tabs-area .nav li button .icons' => 'margin: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
                ],
            ]
        );
        $this->end_controls_section();
    }

    public function renev_tab_builder(){

        $renev_post_query = new \WP_Query( array(
            'post_type'				=> 'renev_tab_build',
            'posts_per_page'	    => -1,
        ) );

        $renev_tab_builder_title_title = array();
        $renev_tab_builder_title_title[''] = __( 'Select a Title','renev');

        while( $renev_post_query->have_posts() ) {
            $renev_post_query->the_post();
            $renev_tab_builder_title_title[ get_the_ID() ] =  get_the_title();
        }
        wp_reset_postdata();
        return $renev_tab_builder_title_title;
    }

    protected function render() {
        $settings = $this->get_settings_for_display();
        $layout = $settings['tab_layout'];
        
        ?>
            <?php
                if ( $layout) {
                    include('tab/'.$layout.'.php');
                }
            ?>
        <?php
    }
}
$widgets_manager->register(new \Elementor\RenevTab());

