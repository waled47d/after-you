<div class="row">
    <div class="col-lg-10 m-auto">
        <div class="service-tabs-area">
            <!-- Tab Buttons -->
            <ul class="nav nav-pills" id="pills-tab" role="tablist">
                <?php 
                $index = 1;
                foreach( $settings['tab_item'] as $tab_item ) : 
                    $tab_id = 'tab-' . $index;
                    $collapse_id = 'tab-content-' . $index;
                    $is_active = ($index === 1) ? 'active' : '';
                    $aria_selected = ($index === 1) ? 'true' : 'false';
                ?>
                <li class="nav-item" role="presentation">
                    <button 
                        class="nav-link <?php echo esc_attr($is_active); ?>" 
                        id="<?php echo esc_attr($tab_id); ?>" 
                        data-bs-toggle="pill" 
                        data-bs-target="#<?php echo esc_attr($collapse_id); ?>" 
                        type="button" 
                        role="tab" 
                        aria-controls="<?php echo esc_attr($collapse_id); ?>" 
                        aria-selected="<?php echo esc_attr($aria_selected); ?>">
                        <span class="icons">
                            <img src="<?php echo esc_url($tab_item['tab_image']['url']); ?>" alt="">
                        </span>
                        <span class="text">
                            <?php echo esc_html( $tab_item['box_title'] ); ?>
                        </span>
                    </button>
                </li>
                <?php 
                $index++; 
                endforeach; 
                ?>
            </ul>

            <!-- Tab Content -->
            <div class="tab-content" id="pills-tabContent">
                <?php 
                $index = 1;
                foreach( $settings['tab_item'] as $tab_item ) : 
                    $collapse_id = 'tab-content-' . $index;
                    $tab_id = 'tab-' . $index;
                    $is_active = ($index === 1) ? 'show active' : '';
                ?>
                <div 
                    class="tab-pane fade <?php echo esc_attr($is_active); ?>" 
                    id="<?php echo esc_attr($collapse_id); ?>" 
                    role="tabpanel" 
                    aria-labelledby="<?php echo esc_attr($tab_id); ?>" 
                    tabindex="0">
                    <?php 
                        $elementor = \Elementor\Plugin::instance();
                        echo $elementor->frontend->get_builder_content_for_display($tab_item['renev_tab_builder']); 
                    ?>
                </div>
                <?php 
                $index++; 
                endforeach; 
                ?>
            </div>
        </div>
    </div>
</div>