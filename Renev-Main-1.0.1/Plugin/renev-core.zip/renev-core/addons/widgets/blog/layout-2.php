<div class="row">
    <?php if ($the_query->have_posts()) {
        while ($the_query->have_posts()) {
            $the_query->the_post();
            $excerpt = (isset($settings['excerpt_limit']['size']) && $settings['excerpt_limit']['size']) 
                        ? wp_trim_words(get_the_excerpt(), $settings['excerpt_limit']['size'], '') 
                        : get_the_excerpt();
        ?>
        <div class="col-lg-6 col-md-6">
            <div class="blog-2">
                <div class="vl-blog-1-item">
                    <?php if( $settings['show_image'] == 'yes' ): ?>
                        <?php if( has_post_thumbnail() ): ?>
                            <div class="vl-blog-1-thumb image-anime">
                                <?php the_post_thumbnail('full');?>
                            </div>
                        <?php endif; ?>
                    <?php endif; ?>
                    <div class="vl-blog-1-content">
                        <?php if( $settings['show_date'] == 'yes' ): ?>
                                <div class="vl-blog-meta">
                                <?php
                                    $date_day = get_the_time('j'); // Day of the month (e.g., 20)
                                    $date_month = get_the_time('F'); // Full month name (e.g., December)
                                    $date_year = get_the_time('Y'); // Year (e.g., 2024)
                                ?>
                                    <ul>
                                        <li>
                                            <a href="<?php the_permalink(); ?>">
                                                <img src="<?php echo esc_url( $settings['meta_img']['url'] ); ?>" alt="">
                                                <?php echo esc_html(strtoupper($date_day)); ?>
                                                <?php echo esc_html(strtoupper($date_month)); ?>
                                                <?php echo esc_html(strtoupper($date_year)); ?>
                                            </a>
                                        </li>
                                    </ul>
                                </div>
                            <?php endif; ?>
                        <h4 class="vl-blog-1-title">
                            <a href="<?php the_permalink(); ?>">
                                <?php the_title(); ?>
                            </a>
                        </h4>
                        <?php the_excerpt(); ?>
                        <div class="vl-blog-1-icon">
                            <a href="<?php the_permalink(); ?>">
                                <?php echo esc_html( $settings['btn_text'] ); ?>
                                <i class="fa-solid fa-arrow-right"></i>
                            </a>
                        </div>
                    </div>
                </div>
            </div>
           
        </div>
     <?php
        }
        // Restore original Post Data.
        wp_reset_postdata();
        }
    ?>
 </div>