
<div class="hero-bottom-images">
    <img src="<?php echo esc_url( $settings['shape-img']['url'] ); ?>" alt="" class="elements3">
    <div class="img1 image-anime reveal">
    <?php if ( !empty( $settings['image_one']['url']) ) : ?>
        <div class="img1 image-anime reveal">
            <img src="<?php echo esc_url( $settings['image_one']['url'] ); ?>" alt="">
        </div>
    <?php endif; ?>
    </div>
    <div class="started-btn">
        <img class="keyframe5" src="<?php echo esc_url( $settings['circle-img']['url'] ); ?>" alt="">
        <a href="<?php echo esc_url( $settings['btn_link']['url'] ); ?>" 
            <?php echo !empty( $settings['btn_link']['is_external'] ) ? 'target="_blank"' : ''; ?> 
            <?php echo !empty( $settings['btn_link']['nofollow'] ) ? 'rel="nofollow"' : ''; ?>>
            <span>
                <i class="fa-solid fa-arrow-right"></i>
            </span>
        </a>
        <div class="space10"></div>
        <a href="<?php echo esc_url( $settings['btn_link']['url'] ); ?>" 
            <?php echo !empty( $settings['btn_link']['is_external'] ) ? 'target="_blank"' : ''; ?> 
            <?php echo !empty( $settings['btn_link']['nofollow'] ) ? 'rel="nofollow"' : ''; ?>>
            <?php echo esc_html( $settings['btn_text'] ); ?>
        </a>
    </div>
</div>