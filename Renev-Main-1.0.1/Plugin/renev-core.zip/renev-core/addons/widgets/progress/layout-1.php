
    <div class="about1-section-area">
        <div class="about-header padding0">
            <div class="bg-progress">
                <?php foreach ( $settings['skills'] as $skill ) : ?>
                    <div class="progress-bar">
                        <label>
                            <?php echo esc_html( $skill['skill_name'] ); ?>
                            <span>
                                <?php echo esc_html( $skill['skill_value']['size'] ); ?>%
                            </span>
                        </label>
                        <div class="progress">
                            <div class="progress-inner" style="width: <?php echo esc_attr( $skill['skill_value']['size'] ); ?>%;"></div>
                        </div>
                    </div>
                <?php endforeach; ?>
            </div>
        </div>
    </div>
        