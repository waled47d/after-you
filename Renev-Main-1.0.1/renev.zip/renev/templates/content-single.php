<?php
/**
 * @Packge     : Renev
 * @Version    : 1.0
 * @Author     : Mthemeus
 * @Author URI : https://www.mthemeus.com/
 *
 */

    // Block direct access
    if( ! defined( 'ABSPATH' ) ){
        exit();
    }

    renev_setPostViews( get_the_ID() );

    ?>
    <div <?php post_class(); ?> >
    <?php
        if( class_exists('ReduxFramework') ) {
            $renev_post_details_title_position = renev_opt('renev_post_details_title_position');
        } else {
            $renev_post_details_title_position = 'header';
        }

        $allowhtml = array(
            'p'         => array(
                'class'     => array()
            ),
            'span'      => array(),
            'a'         => array(
                'href'      => array(),
                'title'     => array(),
                'class'     => array(),
            ),
            'br'        => array(),
            'em'        => array(),
            'strong'    => array(),
            'b'         => array(),
        );

            // Blog Post Thumbnail
            do_action( 'renev_blog_post_details_thumb' );

            // Blog details Meta
            do_action( 'renev_blog_details_post_meta' );
                echo '<div class="space24">';
                echo '</div>';

            // Blog details title
            if( $renev_post_details_title_position = 'header' ) {
                echo '<h2>'.wp_kses( get_the_title(), $allowhtml ).'</h2>';
            }

            echo '<div class="space20">';
            echo '</div>';

            // Blog Content
            the_content();
            // Link Pages
            renev_link_pages();

            $renev_post_tag = get_the_tags();

            if( class_exists('ReduxFramework') ) {
                $renev_post_details_share_options = renev_opt('renev_post_details_share_options');
            } else {
                $renev_post_details_share_options = false;
            }

            if( ! empty( $renev_post_tag ) || ( function_exists( 'renev_social_sharing_buttons' ) && $renev_post_details_share_options ) ){
                echo '<!-- Share Links Area -->';
                echo '<div class="tags-social">';
                    echo '<div class="tags">';
                        if ($renev_post_tag !== false && is_array($renev_post_tag)) {
                            $tag_text = (count($renev_post_tag) > 1) ? __('Tags:', 'renev') : __('Tag:', 'renev');
                        } else {
                            $tag_text = __('No Tags', 'renev');
                        }
                        echo '<ul>';
                            echo '<li>' . esc_html($tag_text) . '</li>';
                            
                            if ($renev_post_tag !== false && is_array($renev_post_tag)) {
                                foreach ($renev_post_tag as $tags) {
                                    echo '<li><a href="' . esc_url(get_tag_link($tags->term_id)) . '">' . esc_html($tags->name) . '</a></li>';
                                }
                            }
                        echo '</ul>';
                    echo '</div>'; 
                    
                    do_action('renev_blog_details_share_options');
                echo '</div>'; 
            }
            
            do_action( 'renev_blog_details_comments' );




        
    echo '</div>';

    /**
    *
    * Hook for Blog Details Post Navigation Options
    *
    * Hook renev_blog_details_post_navigation
    *
    * @Hooked renev_blog_details_post_navigation_cb 10
    *
    */
    // do_action( 'renev_blog_details_post_navigation' );

    /**
    *
    * Hook for Blog Details Author Bio
    *
    * Hook renev_blog_details_author_bio
    *
    * @Hooked renev_blog_details_author_bio_cb 10
    *
    */
    do_action( 'renev_blog_details_author_bio' );

    
