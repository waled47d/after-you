<div class="hero2-section-area">
    <img src="<?php echo esc_url( $settings['hero_bg_img']['url'] ); ?>" alt="" class="hero-bg3">
    <div class="container">
        <div class="row">
            <div class="col-xxl-3 col-xl-3 col-lg-3">
                <div class="top-heading">
                    <h3>
                        <?php echo renev_kses( $settings['section_heading'] ); ?>
                    </h3>
                    <div class="arrow">
                        <a href="<?php echo esc_url($settings['arrow_link']['url']); ?>">
                            <img src="<?php echo esc_url( $settings['circle_icon_img2']['url'] ); ?>" alt="" class="keyframe5">
                            <img src="<?php echo esc_url( $settings['circle_icon_img3']['url'] ); ?>" alt="" class="arrow1">
                        </a>
                    </div>
                </div>
            </div>
            <div class="col-xxl-7 col-xl-6 col-lg-6">
                <div class="main-images-area">
                    <div class="img1 keyframe6">
                        <img src="<?php echo esc_url( $settings['circle_icon_img1']['url'] ); ?>" alt="">
                    </div>
                </div>
            </div>
            <div class="col-xxl-2 col-xl-3 col-lg-3">
                <div class="peragraph-area">
                 <p>
                    <?php echo renev_kses( $settings['section_subtitle'] ); ?>
                </p>
                <div class="space24"></div>
                    <div class="btn-area1">
                        <a href="<?php echo esc_url($settings['hero_btn_link']['url']); ?>" class="vl-btn2">
                            <?php echo esc_html( $settings[ 'hero_button_text' ]  ); ?>
                        </a>
                    </div>
                </div>
            </div>
        </div>
    </div>
    <div class="marquee-wrap">
        <div class="marquee-text">
            <div class="main-heading">
                <?php foreach ( $slider_lists as $item ): ?>
                    <h1>
                        <?php echo esc_html( $item['slider_text'] ); ?>
                    </h1>
                <?php endforeach; ?>
            </div>
        </div>
    </div>
</div>