<section class="testimonials-2">
    <div class="container">
        <div class="row">
            <div class="col-lg-7 col-md-12 left _relative m-auto">
                <div class="swiper swiper-testimonial-2">
                    <div class="swiper-wrapper">
                        <?php foreach ( $testimonial_items as $item ): ?>
                        <div class="swiper-slide">
                            <div class="testimonial-boxarea">
                                <?php \Elementor\Icons_Manager::render_icon( $item['quote_icon'], [ 'aria-hidden' => 'true' ] ); ?>

                                <ul class="star-rating">
                                    <li><i class="fa-solid fa-star"></i></li>
                                    <li><i class="fa-solid fa-star"></i></li>
                                    <li><i class="fa-solid fa-star"></i></li>
                                    <li><i class="fa-solid fa-star"></i></li>
                                    <li><i class="fa-solid fa-star"></i></li>
                                </ul>
                                <p>
                                   <?php echo esc_html( $item['testimonial_description'] ); ?>
                                </p>
                            <div class="names-area">
                                <div class="man-textarea">
                                    <div class="man">
                                        <img src="<?php echo esc_url( $item['testimonial_author']['url'] ); ?>" alt="">
                                    </div>
                                    <div class="text">
                                        <a>
                                            <?php echo esc_html( $item['testimonial_author_name'] ); ?>
                                        </a>
                                        <p>
                                            <?php echo esc_html( $item['testimonial_card_desig'] ); ?>
                                        </p>
                                    </div>
                                </div>
                                <img src="<?php echo esc_url( $item['testimonial_brand_img']['url'] ); ?>" alt="" class="elements20">
                            </div>
                        </div>
                        </div>
                    <?php endforeach; ?>
                </div>
            </div>
            <div class="pagination-buttons">
                <div class="swiper-button-next">
                    <button><i class="fa-solid fa-angle-left"></i></button>
                </div>
                <div class="swiper-button-prev">
                    <button><i class="fa-solid fa-angle-right"></i></button>
                </div>
            </div>
        </div>
        <!-- Thumbnail Slider -->
        <div class="map-testimonial">
            <div class="swiper swiper-thumb2">
                <div class="swiper-wrapper list-img">
                    <?php foreach ( $testimonial_items as $item ): ?>
                        <div class="swiper-slide">
                            <div>
                                <img src="<?php echo esc_url( $item['testimonial_author_img']['url'] ); ?>" alt="">
                            </div>
                        </div>
                    <?php endforeach; ?>
                </div>
            </div>
        </div>
    </div>
</section>
