<?php
/**
 * @Packge     : Renev
 * @Version    : 1.0
 * @Author     : Mthemeus
 * @Author URI : https://www.mthemeus.com/
 *
 */

// Block direct access
if ( !defined( 'ABSPATH' ) ) {
    exit;
}

/**
 *
 * Define constant
 *
 */

// Base URI
if ( ! defined( 'RENEV_DIR_URI' ) ) {
    define('RENEV_DIR_URI', get_parent_theme_file_uri().'/' );
}

// Assist URI
if ( ! defined( 'RENEV_DIR_ASSIST_URI' ) ) {
    define( 'RENEV_DIR_ASSIST_URI', get_theme_file_uri('/assets/') );
}


// Css File URI
if ( ! defined( 'RENEV_DIR_CSS_URI' ) ) {
    define( 'RENEV_DIR_CSS_URI', get_theme_file_uri('/assets/css/') );
}

// Skin Css File
if ( ! defined( 'RENEV_DIR_SKIN_CSS_URI' ) ) {
    define( 'RENEV_DIR_SKIN_CSS_URI', get_theme_file_uri('/assets/css/skins/') );
}


// Js File URI
if (!defined('RENEV_DIR_JS_URI')) {
    define('RENEV_DIR_JS_URI', get_theme_file_uri('/assets/js/'));
}


// External PLugin File URI
if (!defined('RENEV_DIR_PLUGIN_URI')) {
    define('RENEV_DIR_PLUGIN_URI', get_theme_file_uri( '/assets/plugins/'));
}

// Base Directory
if (!defined('RENEV_DIR_PATH')) {
    define('RENEV_DIR_PATH', get_parent_theme_file_path() . '/');
}

//Inc Folder Directory
if (!defined('RENEV_DIR_PATH_INC')) {
    define('RENEV_DIR_PATH_INC', RENEV_DIR_PATH . 'inc/');
}

//RENEV framework Folder Directory
if (!defined('RENEV_DIR_PATH_FRAM')) {
    define('RENEV_DIR_PATH_FRAM', RENEV_DIR_PATH_INC . 'renev-framework/');
}

//Classes Folder Directory
if (!defined('RENEV_DIR_PATH_CLASSES')) {
    define('RENEV_DIR_PATH_CLASSES', RENEV_DIR_PATH_INC . 'classes/');
}

//Hooks Folder Directory
if (!defined('RENEV_DIR_PATH_HOOKS')) {
    define('RENEV_DIR_PATH_HOOKS', RENEV_DIR_PATH_INC . 'hooks/');
}

//Demo Data Folder Directory Path
if( !defined( 'RENEV_DEMO_DIR_PATH' ) ){
    define( 'RENEV_DEMO_DIR_PATH', RENEV_DIR_PATH_INC.'demo-data/' );
}
    
//Demo Data Folder Directory URI
if( !defined( 'RENEV_DEMO_DIR_URI' ) ){
    define( 'RENEV_DEMO_DIR_URI', RENEV_DIR_URI.'inc/demo-data/' );
}