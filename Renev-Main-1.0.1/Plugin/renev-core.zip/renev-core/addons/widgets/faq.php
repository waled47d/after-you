
<?php
use \Elementor\Widget_Base;
use \Elementor\Controls_Manager;
use \Elementor\Group_Control_Typography;
use \Elementor\Group_Control_Border;
use \Elementor\Utils;
use \Elementor\Group_Control_Background;
use \Elementor\Repeater;
use \Elementor\Group_Control_Box_Shadow;
/**
 *
 * Faq Widget .
 *
 */
class Renev_Accordion extends Widget_Base {

	public function get_name() {
		return 'renev_accordion';
	}

	public function get_title() {
		return __( 'Renev Accordion', 'renev' );
	}

	public function get_icon() {
		return 'eicon-code';
    }

	public function get_categories() {
		return [ 'renev' ];
	}

	protected function register_controls() {

		$this->start_controls_section(
			'faq_section',
			[
				'label' 	=> __( 'Accordion', 'renev' ),
				'tab' 		=> Controls_Manager::TAB_CONTENT,
			] 
        );

		$repeater = new Repeater();

        $repeater->add_control(
			'faq_title',
			[
				'label'   => esc_html__( 'Title', 'renev' ),
				'type'    => Controls_Manager::TEXT,
				'default' => esc_html__( ' What should i included my personal details?', 'renev' ),
                'label_block' => true,
			]
		);
        $repeater->add_control(
			'faq_text',
			[
				'label'   => esc_html__( 'Text', 'renev' ),
				'type'    => Controls_Manager::TEXTAREA,
				'default' => esc_html__( 'Partrient sed nascetur facilisis suscipit ridiculus magna lobortis imperdiet vivamus est aliquam euismod nector quam convallis ornare justo service visionary sources unleash online', 'renev' ),
                'label_block' => true,
			]
		);
        $this->add_control(
			'faq_item',
			[
				'label' => __( 'Item', 'renev' ),
				'type' 		=> Controls_Manager::REPEATER,
				'fields' 	=> $repeater->get_controls(),
			]
		);
		$this->end_controls_section();

        //Accourdion Iteam Box Style
		$this->start_controls_section(
			'accordion_box_section',
			[
				'label' => __( 'Accordion Box', 'renev' ),
				'tab' => Controls_Manager::TAB_STYLE,
			]
		);
        $this->add_control(
			'faq_item_margin',
			[
				'label' => __( 'Item Margin', 'renev' ),
				'type' => Controls_Manager::DIMENSIONS,
				'selectors' => [
					'{{WRAPPER}} .accordion .accordion-item' => 'margin: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
				],
			]
		);
        // 1. Accordion Item Background (Outer)
        $this->add_control(
            'faq_item_container_background',
            [
                'label' => __( 'Item Background', 'renev' ),
                'type' => \Elementor\Controls_Manager::COLOR,
                'selectors' => [
                    '{{WRAPPER}} .accordion .accordion-item' => 'background-color: {{VALUE}} !important;',
                ],
            ]
        );
        
        // Accordion Item Border Radius
        $this->add_control(
            'faq_item_container_radius',
            [
                'label' => __( 'Item Border Radius', 'renev' ),
                'type' => \Elementor\Controls_Manager::SLIDER,
                'range' => [
                    'px' => [
                        'min' => 0,
                        'max' => 50,
                    ],
                ],
                'selectors' => [
                    '{{WRAPPER}} .accordion .accordion-item' => 'border-radius: {{SIZE}}px;',
                ],
            ]
        );
        $this->add_control(
            'faq_button_bg_color',
            [
                'label' => __( 'Button Background', 'renev' ),
                'type' => \Elementor\Controls_Manager::COLOR,
                'selectors' => [
                    '{{WRAPPER}} .accordion .accordion-item button' => 'background-color: {{VALUE}} !important;',
                ],
            ]
        );
        $this->add_control(
            'faq_button_text_color',
            [
                'label' => __( 'Button Text Color', 'renev' ),
                'type' => \Elementor\Controls_Manager::COLOR,
                'selectors' => [
                    '{{WRAPPER}} .accordion .accordion-item button' => 'color: {{VALUE}} !important;',
                ],
            ]
        );
        $this->add_responsive_control(
            'faq_button_padding',
            [
                'label' => __( 'Button Padding', 'renev' ),
                'type' => \Elementor\Controls_Manager::DIMENSIONS,
                'size_units' => [ 'px', '%' ],
                'selectors' => [
                    '{{WRAPPER}} .accordion .accordion-item button' => 'padding: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}} !important;',
                ],
            ]
        );
        $this->add_group_control(
            \Elementor\Group_Control_Typography::get_type(),
            [
                'name' => 'faq_button_typography',
                'selector' => '{{WRAPPER}} .accordion .accordion-item button',
            ]
        );
        $this->add_control(
            'faq_button_radius',
            [
                'label' => __( 'Button Border Radius', 'renev' ),
                'type' => \Elementor\Controls_Manager::SLIDER,
                'range' => [
                    'px' => [
                        'min' => 0,
                        'max' => 50,
                    ],
                ],
                'selectors' => [
                    '{{WRAPPER}} .accordion .accordion-item button' => 'border-radius: {{SIZE}}px;',
                ],
            ]
        );
        $this->add_control(
            'faq_button_active_bg',
            [
                'label' => __( 'Active Button Background', 'renev' ),
                'type' => \Elementor\Controls_Manager::COLOR,
                'selectors' => [
                    '{{WRAPPER}} .accordion .accordion-item button.accordion-button:not(.collapsed)' => 'background-color: {{VALUE}} !important;',
                ],
            ]
        );
        
        // Active Button Text Color
        $this->add_control(
            'faq_button_active_text_color',
            [
                'label' => __( 'Active Button Text Color', 'renev' ),
                'type' => \Elementor\Controls_Manager::COLOR,
                'selectors' => [
                    '{{WRAPPER}} .accordion .accordion-item button.accordion-button:not(.collapsed)' => 'color: {{VALUE}} !important;',
                ],
            ]
        );
        $this->end_controls_section();

        //Accourdion Circle Arrow Style
		$this->start_controls_section(
			'faq_icon_circle_section',
			[
				'label' => __( 'Accordion Circle Arrow', 'renev' ),
				'tab' => Controls_Manager::TAB_STYLE,
			]
		);
        $this->add_control(
            'faq_icon_circle_color',
            [
                'label' => __( 'Icon Circle Background', 'renev' ),
                'type' => \Elementor\Controls_Manager::COLOR,
                'selectors' => [
                    '{{WRAPPER}} .accordion .accordion-item button::before' => 'background-color: {{VALUE}} !important;',
                ],
            ]
        );
        $this->add_control(
            'faq_icon_circle_active',
            [
                'label' => __( 'Active Icon Circle Background', 'renev' ),
                'type' => \Elementor\Controls_Manager::COLOR,
                'selectors' => [
                    '{{WRAPPER}} .accordion .accordion-item button.accordion-button:not(.collapsed)::before' => 'background-color: {{VALUE}} !important;',
                ],
            ]
        );
        $this->end_controls_section();

        //Accourdion Body Style
        $this->start_controls_section(
			'faq_body_section',
			[
				'label' => __( 'Accordion Body Text', 'renev' ),
				'tab' => Controls_Manager::TAB_STYLE,
			]
		);
        $this->add_control(
            'faq_body_text_color',
            [
                'label' => __( 'Answer Text Color', 'renev' ),
                'type' => \Elementor\Controls_Manager::COLOR,
                'selectors' => [
                    '{{WRAPPER}} .accordion .accordion-item .accordion-body p' => 'color: {{VALUE}} !important;',
                ],
            ]
        );
        $this->add_group_control(
            \Elementor\Group_Control_Typography::get_type(),
            [
                'name' => 'faq_body_typography',
                'selector' => '{{WRAPPER}} .accordion .accordion-item .accordion-body p',
            ]
        );
        $this->add_responsive_control(
            'faq_body_padding',
            [
                'label' => __( 'Answer Padding', 'renev' ),
                'type' => \Elementor\Controls_Manager::DIMENSIONS,
                'size_units' => [ 'px', '%' ],
                'selectors' => [
                    '{{WRAPPER}} .accordion .accordion-item .accordion-body p' => 'padding: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}} !important;',
                ],
            ]
        );
        $this->end_controls_section();        


	}

    protected function render() {
        $settings = $this->get_settings_for_display();

        ?>
            <div class="faq-section-area">
                <div class="row">
                    <div class="col-lg-12">
                        <div class="accordian-area">
                            <div class="accordion" id="accordionExample">
                                <?php 
                                $index = 1;
                                foreach ( $settings['faq_item'] as $faq_item ) :
                                    $collapse_id = 'collapse-' . $index;
                                    $heading_id = 'heading-' . $index;
                                    $is_first = ($index === 1);
                                ?>
                                <div class="accordion-item">
                                    <h2 class="accordion-header" id="<?php echo esc_attr( $heading_id ); ?>">
                                        <button 
                                            class="accordion-button <?php echo $is_first ? '' : 'collapsed'; ?>" 
                                            type="button" 
                                            data-bs-toggle="collapse" 
                                            data-bs-target="#<?php echo esc_attr( $collapse_id ); ?>" 
                                            aria-expanded="<?php echo $is_first ? 'true' : 'false'; ?>" 
                                            aria-controls="<?php echo esc_attr( $collapse_id ); ?>"
                                        >
                                            <?php echo esc_html( $faq_item['faq_title'] ); ?>
                                        </button>
                                    </h2>
                                    <div 
                                        id="<?php echo esc_attr( $collapse_id ); ?>" 
                                        class="accordion-collapse collapse <?php echo $is_first ? 'show' : ''; ?>" 
                                        aria-labelledby="<?php echo esc_attr( $heading_id ); ?>" 
                                        data-bs-parent="#accordionExample"
                                    >
                                        <div class="accordion-body">
                                            <p><?php echo esc_html( $faq_item['faq_text'] ); ?></p>
                                        </div>
                                    </div>
                                </div>
                                <?php 
                                    $index++;
                                endforeach;
                                ?>
                            </div>
                        </div>
                    </div>
                </div>
            </div>

        <?php
    }
}
$widgets_manager->register( new \Renev_Accordion() );

       
