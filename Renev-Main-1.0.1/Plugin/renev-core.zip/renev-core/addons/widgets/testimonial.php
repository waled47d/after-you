<?php
use \Elementor\Widget_Base;
use \Elementor\Controls_Manager;
use \Elementor\Icons_Manager;
use \Elementor\Group_Control_Typography;
use \Elementor\Group_Control_Border;
use \Elementor\Group_Control_Box_Shadow;
use \Elementor\Repeater;
use \Elementor\Utils;
use \Elementor\Group_Control_Background;


/**
 *
 * Testimonial Widget .
 *
 */
class Renev_Testimonial extends Widget_Base {

	public function get_name() {
		return 'testimonial';
	}

	public function get_title() {
		return __( 'Testimonial', 'renev' );
	}

	public function get_icon() {
		return 'eicon-code';
    }

	public function get_categories() {
		return [ 'renev' ];
	}

	protected function register_controls() {
        // Content Section
        $this->start_controls_section(
            'testimonial_content_section',
            [
                'label' => __( 'Content', 'renev' ),
                'tab'   => Controls_Manager::TAB_CONTENT,
            ]
        );
       
        // Repeater for Testimonial items
        $repeater = new Repeater();

        $repeater->add_control(
            'testimonial_author_img',
            [
                'label'   => __( ' Testimonial Author Img', 'renev' ),
                'type'    => Controls_Manager::MEDIA,
                'default' => [
                    
                ],
            ]
        );
        $repeater->add_control(
            'testimonial_brand_img',
            [
                'label'   => __( 'Testimonial Brand Image', 'renev' ),
                'type'    => Controls_Manager::MEDIA,
                'default' => [
                    
                ],
                'description' => __('Used for layout 1,3', 'renev'),
            ]
        );
        $repeater->add_control(
            'testimonial_description',
            [
                'label'       => __( 'Description', 'renev' ),
                'type'        => Controls_Manager::TEXTAREA,
                'default'     => __( '“Partnering with Renev was a turning point for our business. From an start, their team demonstrated level professionalism and expertise that’s hard to find. They took time understand not only our immediate needs but also our long-term vision, and they crafted a solution that truly aligned with both. ', 'renev' ),
                'label_block' => true,
             
            ]
        );
        $repeater->add_control(
            'testimonial_author_name',
            [
                'label'       => __( 'Author Name', 'renev' ),
                'type'        => Controls_Manager::TEXT,
                'default'     => __( 'Sheldon Jackson', 'renev' ),
                'label_block' => true,
            ]
        );
        $repeater->add_control(
            'testimonial_card_desig',
            [
                'label'       => __( 'Desigration', 'renev' ),
                'type'        => Controls_Manager::TEXT,
                'default'     => __( 'Owner FeatherDev', 'renev' ),
                'label_block' => true,
            ]
        );
        $this->add_control(
            'testimonial_items',
            [
                'label'       => __( 'Testimonial Items', 'renev' ),
                'type'        => Controls_Manager::REPEATER,
                'fields'      => $repeater->get_controls(),
                'default'     => [],
            ]
        );
        $this->end_controls_section();

        // Testimonial Box style
        $this->start_controls_section(
            'testimonial_box_style',
            [
                'label' => __( 'Testimonial Box', 'renev' ),
                'tab'   => Controls_Manager::TAB_STYLE,
            ]
        );
        $this->add_control(
            't_box_bg',
            [
                'label' => __( 'Background Color', 'renev' ),
                'type' => Controls_Manager::COLOR,
                'selectors' => [
                    '{{WRAPPER}} .testimonial-inner-section-area .testimonial-boxarea' => 'background-color: {{VALUE}}',
                ],
            ]
        );
        $this->add_responsive_control(
            't_box_padding',
            [
                'label' => __( 'Padding', 'renev' ),
                'type' => Controls_Manager::DIMENSIONS,
                'size_units' => [ 'px', 'em', '%' ],
                'selectors' => [
                    '{{WRAPPER}} .testimonial-inner-section-area .testimonial-boxarea' => 'padding: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
                ],
            ]
        );
        $this->add_responsive_control(
            't_box_margin',
            [
                'label' => __( 'Margin', 'renev' ),
                'type' => Controls_Manager::DIMENSIONS,
                'size_units' => [ 'px', 'em', '%' ],
                'selectors' => [
                    '{{WRAPPER}} .testimonial-inner-section-area .testimonial-boxarea' => 'margin: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
                ],
            ]
        );        
        $this->add_responsive_control(
            't_box_radius',
            [
                'label'         => __( 'Box Border Radius', 'renev' ),
                'type'          => Controls_Manager::DIMENSIONS,
                'size_units'    => [ 'px', '%', 'em' ],
                'selectors'     => [
                    '{{WRAPPER}} .testimonial-inner-section-area .testimonial-boxarea' => 'border-radius: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
                ],
            ]
        );
        $this->add_group_control(
            \Elementor\Group_Control_Border::get_type(),
            [
                'name' => 't_box_border',
                'label' => __( 'Box Border', 'renev' ),
                'selector' => '{{WRAPPER}} .testimonial-inner-section-area .testimonial-boxarea',
            ]
        );
		$this->end_controls_section();

        // Rating style
        $this->start_controls_section(
            'rating_style',
            [
                'label' => __( 'Rating', 'renev' ),
                'tab'   => Controls_Manager::TAB_STYLE,
            ]
        );
        $this->add_control(
            'rating_color',
            [
                'label' => __( 'Color', 'renev' ),
                'type' => Controls_Manager::COLOR,
                'selectors' => [
                    '{{WRAPPER}} .testimonial-inner-section-area .testimonial-boxarea ul li' => 'color: {{VALUE}}',
                ],
            ]
        );

        $this->add_responsive_control(
            'rating_size',
            [
                'label' => esc_html__( 'Size', 'renev' ),
                'type' => Controls_Manager::SLIDER,
                'size_units' => [ 'px', '%', 'em', 'rem', 'custom' ],
                'range' => [
                    'px' => [
                        'min' => 0,
                        'max' => 1000,
                        'step' => 1,
                    ],
                    '%' => [
                        'min' => 0,
                        'max' => 100,
                    ],
                ],
                'selectors' => [
                    '{{WRAPPER}} .testimonial-inner-section-area .testimonial-boxarea ul li' => 'font-size: {{SIZE}}{{UNIT}};',
                ],
            ]
        );
        $this->add_responsive_control(
            'rating_margin',
            [
                'label' => __( 'Margin', 'renev' ),
                'type' => Controls_Manager::DIMENSIONS,
                'size_units' => [ 'px', 'em', '%' ],
                'selectors' => [
                    '{{WRAPPER}} .testimonial-inner-section-area .testimonial-boxarea ul' => 'margin: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
                ],
            ]
        );
        $this->end_controls_section();

        // Testimonial Description style
        $this->start_controls_section(
            'Testimonial_description_style',
            [
                'label' => __( 'Testimonial Description', 'renev' ),
                'tab'   => Controls_Manager::TAB_STYLE,
            ]
        );
        $this->add_control(
            'Testimonial_description_color',
            [
                'label' => __( 'Color', 'renev' ),
                'type' => Controls_Manager::COLOR,
                'selectors' => [
                    '{{WRAPPER}} .testimonial-inner-section-area .testimonial-boxarea p' => 'color: {{VALUE}}',
                ],
            ]
        );
        $this->add_group_control(
            Group_Control_Typography::get_type(),
            [
                'name' => 'Testimonial_description_typography',
                'selector' => '{{WRAPPER}} .testimonial-inner-section-area .testimonial-boxarea p',
            ]
        );
        $this->add_responsive_control(
            'Testimonial_description_margin',
            [
                'label' => __( 'Margin', 'renev' ),
                'type' => Controls_Manager::DIMENSIONS,
                'size_units' => [ 'px', 'em', '%' ],
                'selectors' => [
                    '{{WRAPPER}} .testimonial-inner-section-area .testimonial-boxarea .names-area' => 'margin: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
                ],
            ]
        );
        $this->end_controls_section();

        // Author Name style
        $this->start_controls_section(
            'author_name_style',
            [
                'label' => __( 'Author Name', 'renev' ),
                'tab'   => Controls_Manager::TAB_STYLE,
            ]
        );

        $this->add_control(
            'author_name_color',
            [
                'label' => __( 'Color', 'renev' ),
                'type' => Controls_Manager::COLOR,
                'selectors' => [
                    '{{WRAPPER}} .testimonial-inner-section-area .testimonial-boxarea .names-area .man-textarea .text a' => 'color: {{VALUE}}',
                ],
            ]
        );
        $this->add_control(
            'author_name_color_hover',
            [
                'label' => __( 'Hover Color', 'renev' ),
                'type' => Controls_Manager::COLOR,
                'selectors' => [
                    '{{WRAPPER}} .testimonial-inner-section-area .testimonial-boxarea .names-area .man-textarea .text a:hover' => 'color: {{VALUE}}',
                ],
            ]
        );
        $this->add_group_control(
            Group_Control_Typography::get_type(),
            [
                'name' => 'author_name_typography',
                'selector' => '{{WRAPPER}} .testimonial-inner-section-area .testimonial-boxarea .names-area .man-textarea .text a',
            ]
        );
        $this->add_responsive_control(
            'author_name_margin',
            [
                'label' => __( 'Margin', 'renev' ),
                'type' => Controls_Manager::DIMENSIONS,
                'size_units' => [ 'px', 'em', '%' ],
                'selectors' => [
                    '{{WRAPPER}} .testimonial-inner-section-area .testimonial-boxarea .names-area .man-textarea .text a' => 'margin: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
                ],
            ]
        );
        $this->end_controls_section();

        // Designation style
        $this->start_controls_section(
            'designation_style',
            [
                'label' => __( 'Designation', 'renev' ),
                'tab'   => Controls_Manager::TAB_STYLE,
            ]
        );

        $this->add_control(
            'designation_color',
            [
                'label' => __( 'Color', 'renev' ),
                'type' => Controls_Manager::COLOR,
                'selectors' => [
                    '{{WRAPPER}} .testimonial-inner-section-area .testimonial-boxarea .names-area .man-textarea .text p' => 'color: {{VALUE}}',
                ],
            ]
        );
        $this->add_group_control(
            Group_Control_Typography::get_type(),
            [
                'name' => 'designation_typography',
                'selector' => '{{WRAPPER}} .testimonial-inner-section-area .testimonial-boxarea .names-area .man-textarea .text p',
            ]
        );

        $this->end_controls_section();

        // Author Image  style
        $this->start_controls_section(
            'author_img_style',
            [
                'label' => __( 'Author Img', 'renev' ),
                'tab'   => Controls_Manager::TAB_STYLE,
            ]
        );
        $this->add_responsive_control(
            'author_img_width',
            [
                'label' => esc_html__( 'Image Width', 'renev' ),
                'type' => Controls_Manager::SLIDER,
                'size_units' => [ 'px', '%', 'em', 'rem' ],
                'range' => [
                    'px' => [
                        'min' => 0,
                        'max' => 1000,
                        'step' => 1,
                    ],
                    '%' => [
                        'min' => 0,
                        'max' => 100,
                    ],
                    'em' => [
                        'min' => 0,
                        'max' => 50,
                    ],
                    'rem' => [
                        'min' => 0,
                        'max' => 50,
                    ],
                ],
                'selectors' => [
                    '{{WRAPPER}} .testimonial-inner-section-area .testimonial-boxarea .names-area .man-textarea .man img' => 'width: {{SIZE}}{{UNIT}};',
                ],
            ]
        );
        $this->add_responsive_control(
            'author_img_height',
            [
                'label' => esc_html__( 'Image Height', 'renev' ),
                'type' => Controls_Manager::SLIDER,
                'size_units' => [ 'px', '%', 'em', 'rem' ],
                'range' => [
                    'px' => [
                        'min' => 0,
                        'max' => 1000,
                        'step' => 1,
                    ],
                    '%' => [
                        'min' => 0,
                        'max' => 100,
                    ],
                    'em' => [
                        'min' => 0,
                        'max' => 50,
                    ],
                    'rem' => [
                        'min' => 0,
                        'max' => 50,
                    ],
                ],
                'selectors' => [
                    '{{WRAPPER}} .testimonial-inner-section-area .testimonial-boxarea .names-area .man-textarea .man img' => 'height: {{SIZE}}{{UNIT}};',
                ],
            ]
        );    
        $this->add_responsive_control(
            'author_img_radius',
            [
                'label'         => __( 'Border Radius', 'renev' ),
                'type'          => Controls_Manager::DIMENSIONS,
                'size_units'    => [ 'px', '%', 'em' ],
                'selectors'     => [
                    '{{WRAPPER}} .testimonial-inner-section-area .testimonial-boxarea .names-area .man-textarea .man img' => 'border-radius: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
                ],
            ]
        );
        $this->add_responsive_control(
            'author_img_padding',
            [
                'label' => __( 'Padding', 'renev' ),
                'type' => Controls_Manager::DIMENSIONS,
                'size_units' => [ 'px', 'em', '%' ],
                'selectors' => [
                    '{{WRAPPER}} .testimonial-inner-section-area .testimonial-boxarea .names-area .man-textarea .text' => 'padding: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
                ],
            ]
        );
        $this->end_controls_section();
        
        // Author Brand  style
        $this->start_controls_section(
            'author_brand_style',
            [
                'label' => __( 'Brand Img', 'renev' ),
                'tab'   => Controls_Manager::TAB_STYLE,
            ]
        );
        $this->add_responsive_control(
            'author_brand_width',
            [
                'label' => esc_html__( 'Image Width', 'renev' ),
                'type' => Controls_Manager::SLIDER,
                'size_units' => [ 'px', '%', 'em', 'rem' ],
                'range' => [
                    'px' => [
                        'min' => 0,
                        'max' => 1000,
                        'step' => 1,
                    ],
                    '%' => [
                        'min' => 0,
                        'max' => 100,
                    ],
                    'em' => [
                        'min' => 0,
                        'max' => 50,
                    ],
                    'rem' => [
                        'min' => 0,
                        'max' => 50,
                    ],
                ],
                'selectors' => [
                    '{{WRAPPER}} .testimonial-inner-section-area .testimonial-boxarea .names-area .elements20' => 'width: {{SIZE}}{{UNIT}};',
                ],
            ]
        );
        $this->add_responsive_control(
            'author_brand_height',
            [
                'label' => esc_html__( 'brand Height', 'renev' ),
                'type' => Controls_Manager::SLIDER,
                'size_units' => [ 'px', '%', 'em', 'rem' ],
                'range' => [
                    'px' => [
                        'min' => 0,
                        'max' => 1000,
                        'step' => 1,
                    ],
                    '%' => [
                        'min' => 0,
                        'max' => 100,
                    ],
                    'em' => [
                        'min' => 0,
                        'max' => 50,
                    ],
                    'rem' => [
                        'min' => 0,
                        'max' => 50,
                    ],
                ],
                'selectors' => [
                    '{{WRAPPER}} .testimonial-inner-section-area .testimonial-boxarea .names-area .elements20' => 'height: {{SIZE}}{{UNIT}};',
                ],
            ]
        );    
        $this->end_controls_section();
    }

    // Render
	protected function render() {
        $settings = $this->get_settings_for_display();
        $testimonial_items = $settings['testimonial_items'];

        ?>
            <div class="testimonial-inner-section-area">
                <div class="container">
                    <div class="row">
                        <?php foreach ( $testimonial_items as $item ): ?>
                            <div class="col-lg-6">
                                <div class="testimonial-boxarea">
                                    <ul>
                                        <li><i class="fa-solid fa-star"></i></li>
                                        <li><i class="fa-solid fa-star"></i></li>
                                        <li><i class="fa-solid fa-star"></i></li>
                                        <li><i class="fa-solid fa-star"></i></li>
                                        <li><i class="fa-solid fa-star"></i></li>
                                    </ul>
                                    <p>
                                       <?php echo esc_html( $item['testimonial_description'] ); ?>
                                    </p>
                                    <div class="names-area">
                                    <div class="man-textarea">
                                        <div class="man">
                                             <img src="<?php echo esc_url( $item['testimonial_author_img']['url'] ); ?>" alt="">
                                        </div>
                                        <div class="text">
                                        <a>
                                            <?php echo esc_html( $item['testimonial_author_name'] ); ?>
                                        </a>
                                        <p><?php echo esc_html( $item['testimonial_card_desig'] ); ?></p>
                                        </div>
                                    </div>
                                        <img src="<?php echo esc_url( $item['testimonial_brand_img']['url'] ); ?>" alt="" class="elements20">
                                    </div>
                                </div>
                            </div>
                        <?php endforeach; ?>
                    </div>
                </div>
            </div>
        <?php
    }
}
$widgets_manager->register( new \Renev_Testimonial() );