<?php
use \Elementor\Widget_Base;
use \Elementor\Controls_Manager;
use \Elementor\Group_Control_Typography;
use \Elementor\Group_Control_Text_Shadow;
use \Elementor\Group_Control_Border;
use \Elementor\Group_Control_Box_Shadow;
use \Elementor\Repeater;
use \Elementor\Utils;
/**
 *
 * Header Menu Widget .
 *
 */
class Renev_Header_Menu extends Widget_Base {

	public function get_name() {
		return 'renev_header_menu';
	}

	public function get_title() {
		return __( 'Renev Header Menu', 'renev' );
	}

	public function get_icon() {
		return 'eicon-code';
    }

	public function get_categories() {
		return [ 'renev' ];
	}

    private function get_available_menus() {

        $menus = wp_get_nav_menus();

        $options = [];

        foreach ( $menus as $menu ) {

            $options[$menu->slug] = $menu->name;

        }
        return $options;

    }

	protected function register_controls() {

        // Menu
        $this->start_controls_section(
            'menu_section',
            [
                'label' => __('Menu', 'renev'),
                'tab'   => Controls_Manager::TAB_CONTENT,
            ]
        );
        $this->add_control(
            'need_header_menu',
            [
                'label'        => __( 'Need Header Menu?', 'tekup-hp' ),
                'type'         => Controls_Manager::SWITCHER,
                'label_on'     => __( 'Yes', 'tekup-hp' ),
                'label_off'    => __( 'No', 'tekup-hp' ),
                'return_value' => 'yes',
                'default'      => 'yes',
            ]
        );
        $this->add_control(
            'use_main_menu',
            [
                'label'        => __( 'Use Main Menu', 'renev' ),
                'type'         => Controls_Manager::SWITCHER,
                'label_on'     => __( 'Yes', 'renev' ),
                'label_off'    => __( 'No', 'renev' ),
                'return_value' => 'yes',
                'default'      => 'yes',
            ]
        );
        $menus = $this->get_available_menus();

        if ( !empty( $menus ) ) {
            $this->add_control(
                'primary_menu',
                [
                    'label'        => __( 'Menu', 'header-footer-elementor' ),
                    'type'         => Controls_Manager::SELECT,
                    'options'      => $menus,
                    'default'      => array_keys( $menus )[0],
                    'save_default' => true,
                    'separator'    => 'after',
                    'description'  => sprintf( __( 'Go to the <a href="%s" target="_blank">Menus screen</a> to manage your menus.', 'header-footer-elementor' ), admin_url( 'nav-menus.php' ) ),
                    'condition'    => [
                        'use_main_menu!' => 'yes',
                    ],
                ]
            );
        } else {
            $this->add_control(
                'menu',
                [
                    'type'            => Controls_Manager::RAW_HTML,
                    'raw'             => sprintf( __( '<strong>There are no menus in your site.</strong><br>Go to the <a href="%s" target="_blank">Menus screen</a> to create one.', 'header-footer-elementor' ), admin_url( 'nav-menus.php?action=edit&menu=0' ) ),
                    'separator'       => 'after',
                    'content_classes' => 'elementor-panel-alert elementor-panel-alert-info',
                ]
            );
        }
        $this->end_controls_section();

        // Mobile Menu
        $this->start_controls_section(
            'mobile_menu_section',
            [
                'label' => __('Mobile Menu', 'renev'),
                'tab'   => Controls_Manager::TAB_CONTENT,
            ]
        );
        $this->add_control(
            'mobile_menu_logo',
            [
                'label' => esc_html__( 'Mobile Logo', 'renev' ),
                'type' =>  Controls_Manager::MEDIA,
                'default' => [
                    'url' =>  Utils::get_placeholder_image_src(),
                ],
            ]
        );
        $this->add_control(
            'contact_title',
            [
                'label' => esc_html__('Contact Title', 'renev'),
                'type' => Controls_Manager::TEXT,
                'default' => esc_html__('Contact Us', 'renev'),
                'label_block' => true,
            ]
        );
        $mobile_menu_repeater = new Repeater();

        $mobile_menu_repeater->add_control(
            'mobile_menu_contact',
            [
                'label'   => esc_html__( 'Contact Item', 'renev' ),
                'type'    => Controls_Manager::TEXT,
                'default' => esc_html__( '(+57 9954 6476', 'renev' ),
                'label_block' => true,
            ]
        );
        $mobile_menu_repeater->add_control(
			'mobile_menu_contact_icon',
			[
				'label'       => __( 'Upload Icon', 'renev' ),
				'type'        => Controls_Manager::ICONS,
				'label_block' => true,
			]
		);
        $mobile_menu_repeater->add_control(
            'mobile_menu_link',
            [
                'label' => __( 'Contact URL', 'renev' ),
                'type' => Controls_Manager::URL,

            ]
        );
        $this->add_control(
            'mobile_menu_list',
            [
                'label' => __( 'Mobile menu', 'renev' ),
                'type' 		=> Controls_Manager::REPEATER,
                'fields' 	=> $mobile_menu_repeater->get_controls(),
            ]
         );
        $this->end_controls_section();

        // Mobile Social Icons
        $this->start_controls_section(
            'mobile_menu_social_section',
            [
                'label' => __('Mobile Menu Social', 'renev'),
                'tab'   => Controls_Manager::TAB_CONTENT,
            ]
        );
        $this->add_control(
            'contact_info',
            [
                'label' => esc_html__('Contact Info', 'renev'),
                'type' => Controls_Manager::TEXT,
                'default' => esc_html__('Follow Us', 'renev'),
                'label_block' => true,
            ]
        );
        $mobile_menu_social_repeater = new Repeater();

        $mobile_menu_social_repeater->add_control(
			'mobile_menu_social_icon',
			[
				'label'       => __( 'Upload Icon', 'renev' ),
				'type'        => Controls_Manager::ICONS,
				'label_block' => true,
			]
		);
        $mobile_menu_social_repeater->add_control(
            'mobile_menu_icon_url',
            [
                'label' => esc_html__( 'Icon Url', 'renev' ),
                'type' => Controls_Manager::URL,
                'default' => [
                    'url' => '#',
                ],
                'label_block' => true,
            ]
        ); 
        $this->add_control(
        'mobile_menu_social_list',
        [
            'label' => __( 'Social Icon', 'renev' ),
            'type' 		=> Controls_Manager::REPEATER,
            'fields' 	=> $mobile_menu_social_repeater->get_controls(),
        ]
        );
        $this->end_controls_section();

        // Header Menu style
        $this->start_controls_section(
            'header_menu_style',
            [
                'label' => __( 'Header Menu', 'renev' ),
                'tab'   => Controls_Manager::TAB_STYLE,
            ]
        );
        $this->add_control(
            'header_menu_color',
            [
                'label' => __( 'Color', 'renev' ),
                'type' => Controls_Manager::COLOR,
                'selectors' => [
                    '{{WRAPPER}} .homepage1-menu .vl-main-menu ul > li > a' => 'color: {{VALUE}}',
                ],
            ]
        );
        $this->add_control(
            'header_menu_hover_color',
            [
                'label' => __( 'Hover Color', 'renev' ),
                'type' => Controls_Manager::COLOR,
                'selectors' => [
                    '{{WRAPPER}} .homepage1-menu .vl-main-menu ul > li:hover a' => 'color: {{VALUE}}',
                ],
            ]
        );
        $this->add_group_control(
            Group_Control_Typography::get_type(),
            [
                'name' => 'eader_menu_typography',
                'selector' => '{{WRAPPER}} .homepage1-menu .vl-main-menu ul > li > a',
            ]
        );  
        $this->add_responsive_control(
            'header_menu_padding',
            [
                'label' => __( 'Padding', 'renev' ),
                'type' => Controls_Manager::DIMENSIONS,
                'size_units' => [ 'px', 'em', '%' ],
                'selectors' => [
                    '{{WRAPPER}} .homepage1-menu .vl-main-menu ul > li > a' => 'padding: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
                ],
            ]
        );
        $this->add_responsive_control(
            'header_menu_border_height',
            [
                'label' => esc_html__( 'Border Height', 'renev' ),
                'type' => Controls_Manager::SLIDER,
                'size_units' => [ 'px', '%', 'em', 'rem' ],
                'range' => [
                    'px' => [
                        'min' => 0,
                        'max' => 1000,
                        'step' => 1,
                    ],
                    '%' => [
                        'min' => 0,
                        'max' => 100,
                    ],
                    'em' => [
                        'min' => 0,
                        'max' => 50,
                    ],
                    'rem' => [
                        'min' => 0,
                        'max' => 50,
                    ],
                ],
                'selectors' => [
                    '{{WRAPPER}} .homepage1-menu .vl-main-menu ul > li .sub-menu::after' => 'height: {{SIZE}}{{UNIT}};',
                ],
            ]
        );    
        $this->add_group_control(
            \Elementor\Group_Control_Background::get_type(),
            [
                'name' => 'header_menu_border-bg',
                'label' => esc_html__('Border BG', 'renev'),
                'types' => ['classic', 'gradient'],
                'selector' => '{{WRAPPER}} .homepage1-menu .vl-main-menu ul > li .sub-menu::after',
            ]
        );
        $this->end_controls_section();

        // Header Sub Menu style
        $this->start_controls_section(
            'header_submenu_style',
            [
                'label' => __( 'Header Sub Menu', 'renev' ),
                'tab'   => Controls_Manager::TAB_STYLE,
            ]
        );
        $this->add_control(
            'header_submenu_color',
            [
                'label' => __( 'Color', 'renev' ),
                'type' => Controls_Manager::COLOR,
                'selectors' => [
                    '{{WRAPPER}} .homepage1-menu .vl-main-menu ul > li .sub-menu li a' => 'color: {{VALUE}}',
                ],
            ]
        );
        $this->add_control(
            'header_submenu_hover_color',
            [
                'label' => __( 'Hover Color', 'renev' ),
                'type' => Controls_Manager::COLOR,
                'selectors' => [
                    '{{WRAPPER}} .homepage1-menu .vl-main-menu ul > li .sub-menu li:hover > a' => 'color: {{VALUE}}',
                ],
            ]
        );
        $this->add_group_control(
            Group_Control_Typography::get_type(),
            [
                'name' => 'header_submenu_typography',
                'selector' => '{{WRAPPER}} .homepage1-menu .vl-main-menu ul > li .sub-menu li a',
            ]
        );  
        $this->add_responsive_control(
            'header_submenu_padding',
            [
                'label' => __( 'Padding', 'renev' ),
                'type' => Controls_Manager::DIMENSIONS,
                'size_units' => [ 'px', 'em', '%' ],
                'selectors' => [
                    '{{WRAPPER}} .homepage1-menu .vl-main-menu ul > li .sub-menu li a' => 'padding: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
                ],
            ]
        );
        $this->add_responsive_control(
            'aheader_submenu_height',
            [
                'label' => esc_html__( 'Border Height', 'renev' ),
                'type' => Controls_Manager::SLIDER,
                'size_units' => [ 'px', '%', 'em', 'rem' ],
                'range' => [
                    'px' => [
                        'min' => 0,
                        'max' => 1000,
                        'step' => 1,
                    ],
                    '%' => [
                        'min' => 0,
                        'max' => 100,
                    ],
                    'em' => [
                        'min' => 0,
                        'max' => 50,
                    ],
                    'rem' => [
                        'min' => 0,
                        'max' => 50,
                    ],
                ],
                'selectors' => [
                    '{{WRAPPER}} .homepage1-menu .vl-main-menu ul > li .sub-menu li a::after' => 'height: {{SIZE}}{{UNIT}};',
                ],
            ]
        );   
        $this->add_control(
            'header_submenu_border-bg',
            [
                'label' => __( 'Border BG', 'renev' ),
                'type' => Controls_Manager::COLOR,
                'selectors' => [
                    '{{WRAPPER}} .homepage1-menu .vl-main-menu ul > li .sub-menu li a::after' => 'background: {{VALUE}}',
                ],
            ]
        ); 
        $this->add_responsive_control(
            'submenu_width',
            [
                'label' => esc_html__('Sub Menu Box Width', 'renev'),
                'type' => \Elementor\Controls_Manager::SLIDER,
                'range' => [
                    'px' => [
                        'min' => 100,
                        'max' => 600,
                    ],
                ],
                'selectors' => [
                    '{{WRAPPER}} .homepage1-menu .vl-main-menu ul > li .sub-menu' => 'width: {{SIZE}}{{UNIT}};',
                ],
            ]
        );
        $this->add_responsive_control(
            'submenu_padding',
            [
                'label' => esc_html__('Sub Menu Box Padding', 'renev'),
                'type' => \Elementor\Controls_Manager::DIMENSIONS,
                'size_units' => ['px', '%'],
                'selectors' => [
                    '{{WRAPPER}} .homepage1-menu .vl-main-menu ul > li .sub-menu' => 'padding: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
                ],
            ]
        );
        $this->add_group_control(
            \Elementor\Group_Control_Border::get_type(),
            [
                'name' => 'submenu_border',
                'selector' => '{{WRAPPER}} .homepage1-menu .vl-main-menu ul > li .sub-menu',
            ]
        );
        $this->add_control(
            'submenu_border_radius',
            [
                'label' => esc_html__('Box Border Radius', 'renev'),
                'type' => \Elementor\Controls_Manager::DIMENSIONS,
                'selectors' => [
                    '{{WRAPPER}} .homepage1-menu .vl-main-menu ul > li .sub-menu' => 'border-radius: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
                ],
            ]
        );
        $this->add_group_control(
            \Elementor\Group_Control_Background::get_type(),
            [
                'name' => 'submenu_background',
                'label' => esc_html__('Sub Menu Box Background', 'renev'),
                'types' => ['classic', 'gradient'],
                'selector' => '{{WRAPPER}} .homepage1-menu .vl-main-menu ul > li .sub-menu',
            ]
        );
        $this->add_group_control(
            \Elementor\Group_Control_Box_Shadow::get_type(),
            [
                'name' => 'submenu_box_shadow',
                'selector' => '{{WRAPPER}} .homepage1-menu .vl-main-menu ul > li .sub-menu',
            ]
        );

        $this->end_controls_section();

        //Mobile Menu Style
        $this->start_controls_section(
            'header_mobile_menu_style',
            [
                'label' => __( 'Mobile Menu', 'renev' ),
                'tab'   => Controls_Manager::TAB_STYLE,
            ]
        );
        $this->add_responsive_control(
            'header_mobile_padding',
            [
                'label' => __( 'Menu Padding', 'renev' ),
                'type' => Controls_Manager::DIMENSIONS,
                'size_units' => [ 'px', 'em', '%' ],
                'selectors' => [
                    '{{WRAPPER}} .vl-offcanvas-menu ul li a' => 'padding: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
                ],
            ]
        );
        $this->add_control(
            'header_mobile_menu_color',
            [
                'label' => __( 'Color', 'renev' ),
                'type' => Controls_Manager::COLOR,
                'selectors' => [
                    '{{WRAPPER}} .vl-offcanvas-menu ul li a' => 'color: {{VALUE}}',
                ],
            ]
        );
        $this->add_group_control(
			Group_Control_Typography::get_type(),
			[
				'name' => 'header_mobile_menu_typography',
				'selector' => '{{WRAPPER}} .vl-offcanvas-menu ul li a',
			]
		);
        $this->add_responsive_control(
            'header_mobile_sub_padding',
            [
                'label' => __( 'Padding', 'renev' ),
                'type' => Controls_Manager::DIMENSIONS,
                'size_units' => [ 'px', 'em', '%' ],
                'selectors' => [
                    '{{WRAPPER}} .vl-offcanvas-menu ul li .sub-menu' => 'padding: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
                ],
            ]
        );
        $this->end_controls_section();

        //Header Mobile Logo style
        $this->start_controls_section(
            'header_mobile_logo_style',
            [
                'label' => __( 'Mobile Logo', 'renev' ),
                'tab'   => Controls_Manager::TAB_STYLE,
            ]
        );
        $this->add_responsive_control(
			'mobile_logo_width',
			[
				'label' => esc_html__( 'Width', 'renev' ),
				'type' => Controls_Manager::SLIDER,
				'size_units' => [ 'px', '%', 'em', 'rem', 'custom' ],
				'range' => [
					'px' => [
						'min' => 0,
						'max' => 1000,
						'step' => 1,
					],
					'%' => [
						'min' => 0,
						'max' => 100,
					],
				],
				'selectors' => [
					'{{WRAPPER}} .vl-offcanvas .vl-offcanvas-logo' => 'width: {{SIZE}}{{UNIT}};',
				],
			]
		);
        $this->add_responsive_control(
			'mobile_logo_height',
			[
				'label' => esc_html__( 'Height', 'renev' ),
				'type' => Controls_Manager::SLIDER,
				'size_units' => [ 'px', '%', 'em', 'rem', 'custom' ],
				'range' => [
					'px' => [
						'min' => 0,
						'max' => 1000,
						'step' => 1,
					],
					'%' => [
						'min' => 0,
						'max' => 100,
					],
				],
				'selectors' => [
					'{{WRAPPER}} .vl-offcanvas .vl-offcanvas-logo' => 'height: {{SIZE}}{{UNIT}};',
				],
			]
		);
        $this->add_responsive_control(
            'mobile_logo_margin',
            [
                'label' => __( 'Margin', 'renev' ),
                'type' => Controls_Manager::DIMENSIONS,
                'size_units' => [ 'px', 'em', '%' ],
                'selectors' => [
                    '{{WRAPPER}} .vl-offcanvas-header' => 'margin: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
                ],
            ]
        );
        //Header Mobile close Button style
        $this->add_control(
            'mobile_logo_close_button_color',
            [
                'label' => __( 'Close Button Color', 'renev' ),
                'type' => Controls_Manager::COLOR,
                'selectors' => [
                    '{{WRAPPER}} .vl-offcanvas .vl-offcanvas-close button' => 'color: {{VALUE}}',
                ],
            ]
        );
        $this->end_controls_section();

        // Header Mobile Menu Social style
        $this->start_controls_section(
            'header_mobile_social_style',
            [
                'label' => __( 'Mobile Social', 'renev' ),
                'tab'   => Controls_Manager::TAB_STYLE,
            ]
        );
        $this->add_group_control(
			Group_Control_Typography::get_type(),
			[
				'name' => 'header_mobile_social_typography',
				'selector' => '{{WRAPPER}} .vl-offcanvas-sm-title',
			]
		);
        $this->add_control(
            'header_mobile-social-text',
            [
                'label' => __( 'Text Color', 'renev' ),
                'type' => Controls_Manager::COLOR,
                'selectors' => [
                    '{{WRAPPER}} .vl-offcanvas-sm-title' => 'color: {{VALUE}}',
                ],
            ]
        );
        $this->add_responsive_control(
            'header_mobile-social-text_margin',
            [
                'label' => __( 'Text Margin', 'renev' ),
                'type' => Controls_Manager::DIMENSIONS,
                'size_units' => [ 'px', 'em', '%' ],
                'selectors' => [
                    '{{WRAPPER}} .vl-offcanvas-sm-title' => 'margin: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
                ],
            ]
        );
        //Social Icon Style
        $this->add_control(
            'header_mobile-social-icon',
            [
                'label' => __( 'Icon Color', 'renev' ),
                'type' => Controls_Manager::COLOR,
                'selectors' => [
                    '{{WRAPPER}} .vl-offcanvas-social a i' => 'color: {{VALUE}}',
                    '{{WRAPPER}} .vl-offcanvas-social a svg path' => 'fill: {{VALUE}};',
                ],
            ]
        );
        $this->add_control(
            'header_mobile-social-icon_hover',
            [
                'label' => __( 'Icon Color Hover', 'renev' ),
                'type' => Controls_Manager::COLOR,
                'selectors' => [
                    '{{WRAPPER}} .vl-offcanvas-social a:hover i' => 'color: {{VALUE}}',
                    '{{WRAPPER}} .vl-offcanvas-social a:hover svg path' => 'fill: {{VALUE}};',
                ],
            ]
        );
        $this->add_responsive_control(
			'header_mobile-social-box_width',
			[
				'label' => esc_html__( 'Box Width', 'renev' ),
				'type' => Controls_Manager::SLIDER,
				'size_units' => [ 'px', '%', 'em', 'rem', 'custom' ],
				'range' => [
					'px' => [
						'min' => 0,
						'max' => 1000,
						'step' => 1,
					],
					'%' => [
						'min' => 0,
						'max' => 100,
					],
				],
				'selectors' => [
					'{{WRAPPER}} .vl-offcanvas-social a' => 'width: {{SIZE}}{{UNIT}};',
				],
			]
		);
        $this->add_responsive_control(
			'header_mobile-social-box_height',
			[
				'label' => esc_html__( 'box height', 'renev' ),
				'type' => Controls_Manager::SLIDER,
				'size_units' => [ 'px', '%', 'em', 'rem', 'custom' ],
				'range' => [
					'px' => [
						'min' => 0,
						'max' => 1000,
						'step' => 1,
					],
					'%' => [
						'min' => 0,
						'max' => 100,
					],
				],
				'selectors' => [
					'{{WRAPPER}} .vl-offcanvas-social a' => 'height: {{SIZE}}{{UNIT}};',
				],
			]
		);
        $this->add_group_control(
            Group_Control_Border::get_type(),
            [
                'name' => 'header_mobile-social-box_border',
                'selector' => '{{WRAPPER}} .vl-offcanvas-social a',
            ]
        );
        $this->add_control(
            'header_mobile-social-box_background',
            [
                'label' => __( 'Box Background', 'renev' ),
                'type' => Controls_Manager::COLOR,
                'selectors' => [
                    '{{WRAPPER}} .vl-offcanvas-social a' => 'background: {{VALUE}}',
                ],
            ]
        );
        $this->add_control(
            'header_mobile-social-box_background_hover',
            [
                'label' => __( 'Box Background Hover', 'renev' ),
                'type' => Controls_Manager::COLOR,
                'selectors' => [
                    '{{WRAPPER}} .vl-offcanvas-social a:hover' => 'background: {{VALUE}}',
                ],
            ]
        );
        $this->add_responsive_control(
            'header_mobile-social_margin',
            [
                'label' => __( 'Icon Margin', 'renev' ),
                'type' => Controls_Manager::DIMENSIONS,
                'size_units' => [ 'px', 'em', '%' ],
                'selectors' => [
                    '{{WRAPPER}} .vl-offcanvas-social a svg' => 'margin: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
                    '{{WRAPPER}} .vl-offcanvas-social a i' => 'margin: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
                ],
            ]
        );
        $this->add_responsive_control(
			'header_mobile-social_icon_size',
			[
				'label' => __( 'Social Size', 'renev' ),
				'type' => Controls_Manager::SLIDER,
				'size_units' => [ 'px' ],
				'range' => [
					'px' => [
						'min' => 0,
						'max' => 100,
						'step' => 1,
					]
				],
				'selectors' => [
					'{{WRAPPER}} .vl-offcanvas-social a i' => 'font-size: {{SIZE}}{{UNIT}};',
					'{{WRAPPER}} .vl-offcanvas-social a svg' => 'width: {{SIZE}}{{UNIT}};',
				],
			]
		);
        $this->end_controls_section();

        















             // Header Mobile Menu Info style
             $this->start_controls_section(
                'header_mobile_info_style',
                [
                    'label' => __( 'Mobile Contact', 'renev' ),
                    'tab'   => Controls_Manager::TAB_STYLE,
                ]
            );

            $this->add_group_control(
                Group_Control_Typography::get_type(),
                [
                    'name' => 'header_mobile_info_typography',
                    'selector' => '{{WRAPPER}} .vl-offcanvas-info span a',
                ]
            );
            $this->add_control(
                'header_mobile-info-text',
                [
                    'label' => __( 'Text Color', 'renev' ),
                    'type' => Controls_Manager::COLOR,
                    'selectors' => [
                        '{{WRAPPER}} .vl-offcanvas-info span a' => 'color: {{VALUE}}',
                    ],
                ]
            );
            //info Icon Style
            $this->add_control(
                'header_mobile-info-icon',
                [
                    'label' => __( 'Info Color', 'renev' ),
                    'type' => Controls_Manager::COLOR,
                    'selectors' => [
                        '{{WRAPPER}} .vl-offcanvas-info span a i' => 'color: {{VALUE}}',
                        '{{WRAPPER}} .vl-offcanvas-info span a svg path' => 'fill: {{VALUE}};',
                    ],
                ]
            );
            $this->add_responsive_control(
                'header_mobile-info_margin',
                [
                    'label' => __( 'Margin', 'renev' ),
                    'type' => Controls_Manager::DIMENSIONS,
                    'size_units' => [ 'px', 'em', '%' ],
                    'selectors' => [
                        '{{WRAPPER}} .vl-offcanvas-info span a' => 'margin: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
                    ],
                ]
            );

            $this->add_responsive_control(
                'header_mobile-info_icon_size',
                [
                    'label' => __( 'info Size', 'renev' ),
                    'type' => Controls_Manager::SLIDER,
                    'size_units' => [ 'px' ],
                    'range' => [
                        'px' => [
                            'min' => 0,
                            'max' => 100,
                            'step' => 1,
                        ]
                    ],
                    'selectors' => [
                        '{{WRAPPER}} .vl-offcanvas-info span a i' => 'font-size: {{SIZE}}{{UNIT}};',
                        '{{WRAPPER}} .vl-offcanvas-info span a svg' => 'width: {{SIZE}}{{UNIT}};',
                    ],
                ]
            );
            $this->end_controls_section();
    }

    // Render
	protected function render() {
        $settings = $this->get_settings_for_display();
        
        if ( 'yes' == $settings['use_main_menu'] ) {
            $args = [
                'theme_location'  => 'primary-menu',
                'container'      => false, 
                'menu_id'        => false, 
                'menu_class'     => 'navigation', 
            ];
        } else {
            $args = [
                'menu'            => $settings['primary_menu'],
                'container'      => false, 
                'menu_id'        => false, 
                'menu_class'     => 'navigation', 
            ];
        }
        ?>
        <!-- MAIN MUNU STARTS -->
        <?php if ( 'yes' === $settings['need_header_menu'] ): ?>
            
            <header class="homepage1-menu">
                <div class="d-none d-lg-block">
                    <div class="vl-main-menu text-center">
                        <nav class="vl-mobile-menu-active">
                             <?php wp_nav_menu( $args );?>
                        </nav>
                    </div>
                </div>
            </header>
        <?php endif; ?>
        <!--- MAIN MUNU END -->

        <!--- MOBILE HEADER STARTS --->
        <div class="vl-header-action-item d-block d-lg-none">
            <button type="button" class="vl-offcanvas-toggle">
                <i class="fa-solid fa-bars-staggered"></i>
            </button>
        </div>

        <div class="homepage1-menu">
            <div class="vl-offcanvas">
                <div class="vl-offcanvas-wrapper">
                    <div class="vl-offcanvas-header d-flex justify-content-between align-items-center mb-90">
                        <div class="vl-offcanvas-logo">
                            <a href="<?php echo esc_url( home_url('/') ); ?>">
                                <img src="<?php echo esc_url( $settings[ 'mobile_menu_logo' ]['url'] ); ?>" alt="">
                            </a>
                        </div>
                        <div class="vl-offcanvas-close">
                           <button class="vl-offcanvas-close-toggle">
                            <i class="fa-solid fa-xmark"></i>
                           </button>
                        </div>
                    </div>
                    <div class="vl-offcanvas-menu d-lg-none">
                        <nav></nav>
                    </div>
                    <div class="vl-offcanvas-info">
                        <h3 class="vl-offcanvas-sm-title">
                            <?php echo esc_html( $settings[ 'contact_title' ]  ); ?>
                        </h3>
                        <?php foreach( $settings['mobile_menu_list'] as $mobile_menu ) : ?>
                            <?php if ( !empty($mobile_menu['mobile_menu_contact']) ) : ?>
                                <span>
                                    <a href="<?php echo esc_url( $mobile_menu['mobile_menu_link']['url'] ); ?>">
                                    <?php \Elementor\Icons_Manager::render_icon( $mobile_menu['mobile_menu_contact_icon'], [ 'aria-hidden' => 'true' ] ); ?>
                                        <?php echo esc_html( $mobile_menu['mobile_menu_contact'] ); ?>
                                    </a>
                                </span>
                            <?php endif; ?>
                        <?php endforeach; ?>
                    </div>
                    <div class="vl-offcanvas-social">
                        <h3 class="vl-offcanvas-sm-title">
                            <?php echo esc_html( $settings[ 'contact_info' ]  ); ?>
                        </h3>
                        <?php foreach( $settings['mobile_menu_social_list'] as $mobile_menu_icon ) : ?>
                            <?php if ( !empty( $mobile_menu_icon['mobile_menu_social_icon'] ) ) : ?>
                                <a href="<?php echo esc_url( $mobile_menu_icon[ 'mobile_menu_icon_url' ]['url'] ); ?>">
                                     <?php \Elementor\Icons_Manager::render_icon( $mobile_menu_icon['mobile_menu_social_icon'], [ 'aria-hidden' => 'true' ] ); ?>
                                </a>
                            <?php endif; ?>
                        <?php endforeach; ?>
                    </div>

                </div>
            </div>
            <div class="vl-offcanvas-overlay"></div>
            </div>
        <!---MOBILE HEADER END --->
        <?php
    }

}
$widgets_manager->register( new \Renev_Header_Menu() );