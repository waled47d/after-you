<?php
use \Elementor\Widget_Base;
use \Elementor\Controls_Manager;
use \Elementor\Repeater;
use \Elementor\Group_Control_Typography;
use \Elementor\Group_Control_Border;


/**
 * Renev Service Widget
 */
class Renev_Service_Post extends Widget_Base {

	public function get_name() {
		return 'renev_service_post';
	}

	public function get_title() {
		return __( 'Renev Service', 'renev' );
	}

	public function get_icon() {
		return 'eicon-code';
	}

	public function get_categories() {
		return [ 'renev' ];
	}

	protected function register_controls() {

    $this->start_controls_section(
        'service_section',
        [
            'label' => __('Service', 'renev'),
            'tab'   => Controls_Manager::TAB_CONTENT,
        ]
    );
    $this->add_control(
        'service_layout',
        [
            'label' => esc_html__('Select Layout', 'renev'),
            'type' => Controls_Manager::SELECT,
            'options' => [
                'layout-1' => esc_html__('Layout 1', 'renev'),
                'layout-2' => esc_html__('Layout 2', 'renev'),
                'layout-3' => esc_html__('Layout 3', 'renev'),
            ],
            'default' => 'layout-1',
        ]
    );
    $repeater = new Repeater();

    $repeater->add_control(
        'select_post',
        [
            'label' => __('Select a Post', 'renev'),
            'type' => Controls_Manager::SELECT2,
            'label_block' => true,
            'default' => 'none',
            'options' => $this->get_all_services(),
        ]
    );
    $repeater->add_control(
        'hiden_image',
        [
            'label' => __('Hidden Image', 'renev'),
            'type'  => Controls_Manager::MEDIA,
        ]
    );
    $repeater->add_control(
        'show_Text3',
        [
            'label' => __( 'Show Text 3', 'renev' ),
            'type' => \Elementor\Controls_Manager::SWITCHER,
            'label_on' => __( 'Show', 'renev' ),
            'label_off' => __( 'Hide', 'renev' ),
            'return_value' => 'yes',
            'default' => 'yes',
        ]
    );
    $repeater->add_control(
        'show_Text4',
        [
            'label' => __( 'Show Text 4', 'renev' ),
            'type' => \Elementor\Controls_Manager::SWITCHER,
            'label_on' => __( 'Show', 'renev' ),
            'label_off' => __( 'Hide', 'renev' ),
            'return_value' => 'yes',
            'default' => 'yes',
        ]
    );
    $repeater->add_control(
        'serviceslist_text', 
        [
        'label' => __( 'Tag One', 'renev' ),
        'type' => Controls_Manager::TEXT,
        'default' => __( 'User Interface Designer', 'renev' ),
        'label_block' => true,
        'description' => __('Used for layout 1,3', 'renev'),
    ]);
    $repeater->add_control( 'serviceslist2_text', [
        'label' => __( 'Tag Two', 'renev' ),
        'type' => Controls_Manager::TEXT,
        'default' => __( 'UI Expert', 'renev' ),
        'label_block' => true,
        'description' => __('Used for layout 1,3', 'renev'),
    ]);
    $repeater->add_control( 'serviceslist3_text', [
        'label' => __( 'Tag Three', 'renev' ),
        'type' => Controls_Manager::TEXT,
        'default' => __( 'UX Engineer', 'renev' ),
        'label_block' => true,
        'description' => __('Used for layout 1,3', 'renev'),
    ]);
    $repeater->add_control( 'serviceslist4_text', [
        'label' => __( 'Tag Four', 'renev' ),
        'type' => Controls_Manager::TEXT,
        'default' => __( 'Product Designer', 'renev' ),
        'label_block' => true,
        'description' => __('Used for layout 1,3', 'renev'),
    ]);
    $repeater->add_control(
        'renev_arrow_icon',
        [
            'label'       => __( 'Arrow Icon', 'renev' ),
            'type'        => Controls_Manager::ICONS,
            'label_block' => true,
        ]
    );
    $this->add_control(
        'service_lists',
        [
            'label' => __('Service Lists', 'renev'),
            'type' => Controls_Manager::REPEATER,
            'fields' => $repeater->get_controls(),
        ]
    );
    $this->end_controls_section();

    //Services style

    // Box style
    $this->start_controls_section(
        'services_box_style',
        [
            'label' => __( 'Services Box', 'renev' ),
            'tab'   => Controls_Manager::TAB_STYLE,
        ]
    );
    $this->add_responsive_control(
        'services_box_padding',
        [
            'label' => __( 'Service Box Padding', 'renev' ),
            'type' => Controls_Manager::DIMENSIONS,
            'size_units' => [ 'px', 'em', '%' ],
            'selectors' => [
                '{{WRAPPER}} .service-branding-boxesarea' => 'padding: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
                '{{WRAPPER}} .list-container li' => 'padding: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
            ],
        ]
    );
    $this->add_group_control(
        Group_Control_Border::get_type(),
        [
            'name' => 'services_box_border',
            'selector' => '{{WRAPPER}} .list-container li, {{WRAPPER}} .service-branding-boxesarea',
            'condition' => [
                'service_layout!' => 'layout-1',
            ]
        ]
    );
    $this->add_control(
        'services_box_border_bg',
        [
            'label' => __( 'Border Bg', 'renev' ),
            'type' => Controls_Manager::COLOR,
            'selectors' => [
                '{{WRAPPER}} .service-branding-boxesarea::after' => 'background-color: {{VALUE}}',
            ],
            'condition' => [
                'service_layout' => 'layout-1',
            ]
        ]
    );
    $this->add_control(
        'services_box_background',
        [
            'label' => __( 'Service Box Background', 'renev' ),
            'type' => Controls_Manager::COLOR,
            'selectors' => [
                '{{WRAPPER}} .service-branding-boxesarea' => 'background-color: {{VALUE}}',
            ],
            'condition' => [
                'service_layout!' => 'layout-2',
            ]
        ]
    );
    $this->add_responsive_control(
        'services_box_radius',
        [
            'label'         => __( 'Box Border Radius', 'renev' ),
            'type'          => Controls_Manager::DIMENSIONS,
            'size_units'    => [ 'px', '%', 'em' ],
            'selectors'     => [
                '{{WRAPPER}} .service-branding-boxesarea' => 'border-radius: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
            ],
            'condition' => [
                'service_layout!' => 'layout-2',
            ]
        ]
    );
    $this->add_responsive_control(
        'services_box_margin',
        [
            'label' => __( 'Service Box Margin', 'renev' ),
            'type' => Controls_Manager::DIMENSIONS,
            'size_units' => [ 'px', 'em', '%' ],
            'selectors' => [
                '{{WRAPPER}} .service-branding-boxesarea' => 'margin: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
            ],
            'condition' => [
                'service_layout!' => 'layout-2',
            ]
        ]
    );
    $this->end_controls_section();

    // Services Title style
    $this->start_controls_section(
        'services_title_style',
        [
            'label' => __( 'Services Title', 'renev' ),
            'tab'   => Controls_Manager::TAB_STYLE,
        ]
    );
    $this->add_control(
        'services_title_color',
        [
            'label' => __( 'Text Color', 'renev' ),
            'type' => Controls_Manager::COLOR,
            'selectors' => [
                '{{WRAPPER}} .service-branding-boxesarea .service-brand-head h2 a' => 'color: {{VALUE}}',
                '{{WRAPPER}} .list-container li .side-heading .heading-area a' => 'color: {{VALUE}}',
            ],
        ]
    );

    $this->add_control(
        'services_title_color_hover',
        [
            'label' => __( 'Text Hover Color', 'renev' ),
            'type' => Controls_Manager::COLOR,
            'selectors' => [
                '{{WRAPPER}} .service-branding-boxesarea .service-brand-head h2 a:hover' => 'color: {{VALUE}}',
                '{{WRAPPER}} .list-container li:hover .side-heading .heading-area a' => 'color: {{VALUE}}',
            ],
        ]
    );
    $this->add_group_control(
        Group_Control_Typography::get_type(),
        [
            'name' => 'services_title_typography', // Internal ID
            'label' => __( 'Title Typography', 'renev' ), // Label in Elementor panel
            'selector' => '{{WRAPPER}} .service-branding-boxesarea .service-brand-head h2 a, {{WRAPPER}} .list-container li .side-heading .heading-area a',
        ]
    );
    
    $this->add_responsive_control(
        'services_title_margin',
        [
            'label' => __( 'Text Margin', 'renev' ),
            'type' => Controls_Manager::DIMENSIONS,
            'size_units' => [ 'px', 'em', '%' ],
            'selectors' => [
                '{{WRAPPER}} .service-branding-boxesarea .service-brand-head h2 a' => 'margin: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
                '{{WRAPPER}} .list-container li .side-heading .heading-area a' => 'margin: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
            ],
        ]
    );
    
    $this->end_controls_section();

    // Services Description style
    $this->start_controls_section(
        'services_description_style',
        [
            'label' => __( 'Services Description', 'renev' ),
            'tab'   => Controls_Manager::TAB_STYLE,
            'condition' => [
                'service_layout' => 'layout-2',
            ]
        ]
    );
    $this->add_control(
        'services_description_color',
        [
            'label' => __( 'Description Color', 'renev' ),
            'type' => Controls_Manager::COLOR,
            'selectors' => [
                '{{WRAPPER}} .list-container li .side-heading .heading-area p' => 'color: {{VALUE}}',
            ],
        ]
    );

    $this->add_group_control(
        Group_Control_Typography::get_type(),
        [
            'name' => 'services_description_typography', // Internal ID
            'label' => __( 'Description Typography', 'renev' ), // Label in Elementor panel
            'selector' => '{{WRAPPER}} .list-container li .side-heading .heading-area p',
        ]
    );
    
    $this->add_control(
        'services_description_opacity',
        [
            'label' => __( 'Description Opacity', 'renev' ),
            'type' => Controls_Manager::SLIDER,
            'size_units' => [ '' ], 
            'range' => [
                '' => [
                    'min' => 0,
                    'max' => 1,
                    'step' => 0.1,
                ],
            ],
            'selectors' => [
                '{{WRAPPER}} .list-container li .side-heading .heading-area p' => 'opacity: {{SIZE}};',
            ],
        ]
    );
    $this->end_controls_section();


     // Services Tag style
    $this->start_controls_section(
        'services_tag_style',
        [
            'label' => __( 'Services Tag', 'renev' ),
            'tab'   => Controls_Manager::TAB_STYLE,
            'condition' => [
                'service_layout!' => 'layout-2',
            ]
        ]
    );
    $this->add_control(
        'services_tag_color',
        [
            'label' => __( 'Text Color', 'renev' ),
            'type' => Controls_Manager::COLOR,
            'selectors' => [
                '{{WRAPPER}} .service-branding-boxesarea .service-brand-head ul li a' => 'color: {{VALUE}}',
            ],
        ]
    );
    $this->add_control(
        'services_tag_bg',
        [
            'label' => __( 'Text Background', 'renev' ),
            'type' => Controls_Manager::COLOR,
            'selectors' => [
                '{{WRAPPER}} .service-branding-boxesarea .service-brand-head ul li a' => 'background: {{VALUE}}',
            ],
        ]
    );
    $this->add_group_control(
        Group_Control_Typography::get_type(),
        [
            'name' => 'services_tag_typography', // Internal ID
            'label' => __( 'Typography', 'renev' ), // Label in Elementor panel
            'selector' => '{{WRAPPER}} .service-branding-boxesarea .service-brand-head ul li a', // CSS target
        ]
    );
    $this->add_responsive_control(
        'services_tag_padding',
        [
            'label' => __( 'Text Padding', 'renev' ),
            'type' => Controls_Manager::DIMENSIONS,
            'size_units' => [ 'px', 'em', '%' ],
            'selectors' => [
                '{{WRAPPER}} .service-branding-boxesarea .service-brand-head ul li a' => 'padding: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
            ],
        ]
    );
    $this->add_responsive_control(
        'services_tag_radius',
        [
            'label'         => __( 'Border Radius', 'renev' ),
            'type'          => Controls_Manager::DIMENSIONS,
            'size_units'    => [ 'px', '%', 'em' ],
            'selectors'     => [
                '{{WRAPPER}} .service-branding-boxesarea .service-brand-head ul li a' => 'border-radius: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
            ],
        ]
    );
    $this->add_responsive_control(
        'services_tag_margin',
        [
            'label' => __( 'Text Margin', 'renev' ),
            'type' => Controls_Manager::DIMENSIONS,
            'size_units' => [ 'px', 'em', '%' ],
            'selectors' => [
                '{{WRAPPER}} .service-branding-boxesarea .service-brand-head ul li a' => 'margin: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
            ],
        ]
    );
    $this->end_controls_section();

    // Services Image style
    $this->start_controls_section(
        'services_image_style',
        [
            'label' => __( 'Services Image', 'renev' ),
            'tab'   => Controls_Manager::TAB_STYLE,
        ]
    );
    $this->add_responsive_control(
        'services_image_width',
        [
            'label' => esc_html__( 'Image Width', 'renev' ),
            'type' => Controls_Manager::SLIDER,
            'size_units' => [ 'px', '%', 'em', 'rem' ],
            'range' => [
                'px' => [
                    'min' => 0,
                    'max' => 1000,
                    'step' => 1,
                ],
                '%' => [
                    'min' => 0,
                    'max' => 100,
                ],
                'em' => [
                    'min' => 0,
                    'max' => 50,
                ],
                'rem' => [
                    'min' => 0,
                    'max' => 50,
                ],
            ],
            'selectors' => [
                '{{WRAPPER}} .service-branding-boxesarea .hidden-img img' => 'width: {{SIZE}}{{UNIT}};',
                '{{WRAPPER}} .image-container .image' => 'width: {{SIZE}}{{UNIT}};',
            ],
        ]
    );
    $this->add_responsive_control(
        'services_image_height',
        [
            'label' => esc_html__( 'Image Height', 'renev' ),
            'type' => Controls_Manager::SLIDER,
            'size_units' => [ 'px', '%', 'em', 'rem' ],
            'range' => [
                'px' => [
                    'min' => 0,
                    'max' => 1000,
                    'step' => 1,
                ],
                '%' => [
                    'min' => 0,
                    'max' => 100,
                ],
                'em' => [
                    'min' => 0,
                    'max' => 50,
                ],
                'rem' => [
                    'min' => 0,
                    'max' => 50,
                ],
            ],
            'selectors' => [
                '{{WRAPPER}} .service-branding-boxesarea .hidden-img img' => 'height: {{SIZE}}{{UNIT}};',
                '{{WRAPPER}} .image-container .image' => 'height: {{SIZE}}{{UNIT}};',
                
            ],
        ]
    );    
    $this->add_responsive_control(
        'services_image_radius',
        [
            'label'         => __( 'Border Radius', 'renev' ),
            'type'          => Controls_Manager::DIMENSIONS,
            'size_units'    => [ 'px', '%', 'em' ],
            'selectors'     => [
                '{{WRAPPER}} .service-branding-boxesarea .hidden-img img' => 'border-radius: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
                '{{WRAPPER}} .image-container .image' => 'border-radius: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
            ],
        ]
    );
    $this->end_controls_section();

    // Services Arrow style
    $this->start_controls_section(
        'services_arrow_style',
        [
            'label' => __( 'Services Arrow Button', 'renev' ),
            'tab'   => Controls_Manager::TAB_STYLE,
        ]
    );
    $this->add_control(
        'services_arrow_bg',
        [
            'label' => __( 'Background', 'renev' ),
            'type' => Controls_Manager::COLOR,
            'selectors' => [
                '{{WRAPPER}} .service-branding-boxesarea .arrow a' => 'background: {{VALUE}}',
                '{{WRAPPER}} .list-container li .side-heading .arrow a' => 'background: {{VALUE}}',
            ],
        ]
    );
    $this->add_control(
        'services_arrow_bg_hover',
        [
            'label' => __( 'Background Hover', 'renev' ),
            'type' => Controls_Manager::COLOR,
            'selectors' => [
                '{{WRAPPER}} .service-branding-boxesarea:hover .arrow a' => 'background: {{VALUE}}',
                '{{WRAPPER}} .list-container li:hover .side-heading .arrow a' => 'background: {{VALUE}}',
            ],
        ]
    );
    
    $this->add_control(
        'services_arrow_color',
        [
            'label' => __( 'Arrow Color', 'renev' ),
            'type' => Controls_Manager::COLOR,
            'selectors' => [
                '{{WRAPPER}} .service-branding-boxesarea .arrow a' => 'color: {{VALUE}}',
                '{{WRAPPER}} .list-container li .side-heading .arrow a svg path' => 'stroke: {{VALUE}}',
                '{{WRAPPER}} .list-container li .side-heading .arrow a i' => 'color: {{VALUE}}',
            ],
        ]
    );
    $this->add_control(
        'services_arrow_color_hover',
        [
            'label' => __( 'Arrow Color Hover', 'renev' ),
            'type' => Controls_Manager::COLOR,
            'selectors' => [
                '{{WRAPPER}} .service-branding-boxesarea:hover .arrow a' => 'color: {{VALUE}}',
                '{{WRAPPER}} .list-container li:hover .side-heading .arrow a svg path' => 'stroke: {{VALUE}}',
                '{{WRAPPER}} .list-container li:hover .side-heading .arrow a i' => 'color: {{VALUE}}',
            ],
        ]
    );
    $this->add_responsive_control(
        'services_arrow_width',
        [
            'label' => esc_html__( 'Width', 'renev' ),
            'type' => Controls_Manager::SLIDER,
            'size_units' => [ 'px', '%', 'em', 'rem' ],
            'range' => [
                'px' => [
                    'min' => 0,
                    'max' => 1000,
                    'step' => 1,
                ],
                '%' => [
                    'min' => 0,
                    'max' => 100,
                ],
                'em' => [
                    'min' => 0,
                    'max' => 50,
                ],
                'rem' => [
                    'min' => 0,
                    'max' => 50,
                ],
            ],
            'selectors' => [
                '{{WRAPPER}} .service-branding-boxesarea .arrow a' => 'width: {{SIZE}}{{UNIT}};',
                '{{WRAPPER}} .list-container li .side-heading .arrow a' => 'width: {{SIZE}}{{UNIT}};',
            ],
        ]
    );
    $this->add_responsive_control(
        'services_arrow_height',
        [
            'label' => esc_html__( 'Height', 'renev' ),
            'type' => Controls_Manager::SLIDER,
            'size_units' => [ 'px', '%', 'em', 'rem' ],
            'range' => [
                'px' => [
                    'min' => 0,
                    'max' => 1000,
                    'step' => 1,
                ],
                '%' => [
                    'min' => 0,
                    'max' => 100,
                ],
                'em' => [
                    'min' => 0,
                    'max' => 50,
                ],
                'rem' => [
                    'min' => 0,
                    'max' => 50,
                ],
            ],
            'selectors' => [
                '{{WRAPPER}} .service-branding-boxesarea .arrow a' => 'height: {{SIZE}}{{UNIT}};',
                '{{WRAPPER}} .list-container li .side-heading .arrow a' => 'height: {{SIZE}}{{UNIT}};',
            ],
        ]
    );    
    $this->add_responsive_control(
        'services_arrow_radius',
        [
            'label'         => __( 'Border Radius', 'renev' ),
            'type'          => Controls_Manager::DIMENSIONS,
            'size_units'    => [ 'px', '%', 'em' ],
            'selectors'     => [
                '{{WRAPPER}} .service-branding-boxesarea .arrow a' => 'border-radius: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
                '{{WRAPPER}} .list-container li .side-heading .arrow a' => 'border-radius: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
            ],
        ]
    );
    $this->add_group_control(
        Group_Control_Border::get_type(),
        [
            'name' => 'services_arrow_border',
            'selector' => '{{WRAPPER}} .list-container li .side-heading .arrow a',
            'condition' => [
                'service_layout' => 'layout-2',
            ]
        ]
    );
    $this->end_controls_section();

	}

	// Get all services
	public function get_all_services() {
		$posts = get_posts([
			'post_type' => 'renev_service',
			'posts_per_page' => -1,
			'orderby' => 'date',
			'post_status' => 'publish',
		]);

		$options = ['none' => __('None', 'renev')];

		foreach ($posts as $post) {
			$options[$post->ID] = $post->post_title;
		}

		return $options;
	}

    // Render
	protected function render() {
        $settings = $this->get_settings_for_display();
        $service_lists = $settings['service_lists'];
        $layout = $settings['service_layout'];

        ?>
            <?php
                if ( $layout) {
                    include('services/'.$layout.'.php');
                }
            ?> 
        <?php
    
    }
}
$widgets_manager->register( new \Renev_Service_Post() );