
<div class="about1-section-area">
    <div class="images">
        <?php if ( !empty( $settings['image_one']['url']) ) : ?>
            <div class="img1 reveal">
                <img src="<?php echo esc_url( $settings['image_one']['url'] ); ?>" alt="">
            </div>
        <?php endif; ?>

        <?php if ( !empty( $settings['image_two']['url']) ) : ?>
            <img src="<?php echo esc_url( $settings['image_two']['url'] ); ?>" alt="" class="elements8">
        <?php endif; ?>
    </div>
</div>