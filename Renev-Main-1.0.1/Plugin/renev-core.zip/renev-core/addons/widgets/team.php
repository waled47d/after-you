<?php
use \Elementor\Widget_Base;
use \Elementor\Controls_Manager;
use \Elementor\Group_Control_Typography;
use \Elementor\Group_Control_Border;
use \Elementor\Utils;
use \Elementor\Group_Control_Background;
use \Elementor\Repeater;
use \Elementor\Group_Control_Box_Shadow;

class Renev_Team_Member extends \Elementor\Widget_Base {

	public function get_name() {
		return 'renev_team_member';
	}

	public function get_title() {
		return esc_html__( 'Team', 'renev' );
	}

	public function get_icon() {
		return 'eicon-code';
	}

	public function get_categories() {
		return [ 'renev-addons' ];
	}

	protected function register_controls() {

		$this->start_controls_section(
			'team_section',
			[
				'label' => esc_html__( 'Team', 'renev' ),
				'tab' => Controls_Manager::TAB_CONTENT,
			]
		);

		$this->add_control(
			'team_layout',
			[
				'label' => esc_html__( 'Select Layout', 'renev' ),
				'type' => Controls_Manager::SELECT,
				'options' => [
					'layout-1' => esc_html__( 'Layout 1', 'renev' ),
					'layout-2' => esc_html__( 'Layout 2', 'renev' ),
				],
				'default' => 'layout-1',
			]
		);

		$repeater = new Repeater();

		$repeater->add_control(
			'team-author_box',
			[
				'label'   => __( 'Team Author Box', 'renev' ),
				'type'    => Controls_Manager::MEDIA,
				'default' => [
					'url' => Utils::get_placeholder_image_src(),
				],
			]
		);
		$repeater->add_control(
			'team-main_image',
			[
				'label'   => __( 'Team Main Image', 'renev' ),
				'type'    => Controls_Manager::MEDIA,
				'default' => [
					'url' => Utils::get_placeholder_image_src(),
				],
			]
		);
		$repeater->add_control(
			'author_name',
			[
				'label'       => esc_html__( 'Author Name', 'renev' ),
				'type'        => Controls_Manager::TEXT,
				'label_block' => true,
				'default'     => esc_html__( 'Alex Robertson', 'renev' ),
			]
		);
		$repeater->add_control(
			'author_Profession',
			[
				'label'       => esc_html__( 'Author Profession', 'renev' ),
				'type'        => Controls_Manager::TEXT,
				'label_block' => true,
				'default'     => esc_html__( 'Finance Consultant', 'renev' ),
			]
		);
		$repeater->add_control(
			'share_icon',
			[
				'label'   => __( 'Share Icon', 'renev' ),
				'type'    => Controls_Manager::MEDIA,
				'default' => [
					'url' => Utils::get_placeholder_image_src(),
				],
			]
		);
		$repeater->add_control(
			'share_icon_link',
			[
				'label' => __( 'Share URL', 'renev' ),
				'type'  => Controls_Manager::URL,
			]
		);
		$repeater->add_control(
			'social_icon_one',
			[
				'label'       => __( 'Icon 01', 'renev' ),
				'type'        => Controls_Manager::ICONS,
				'label_block' => true,
			]
		);
		$repeater->add_control(
			'icon_url_one',
			[
				'label' => __( 'URL 01', 'renev' ),
				'type'  => Controls_Manager::URL,
			]
		);
		$repeater->add_control(
			'social_icon_two',
			[
				'label'       => __( 'Icon 02', 'renev' ),
				'type'        => Controls_Manager::ICONS,
				'label_block' => true,
			]
		);
		$repeater->add_control(
			'icon_url_two',
			[
				'label' => __( 'URL 02', 'renev' ),
				'type'  => Controls_Manager::URL,
			]
		);
		$repeater->add_control(
			'social_icon_three',
			[
				'label'       => __( 'Icon 03', 'renev' ),
				'type'        => Controls_Manager::ICONS,
				'label_block' => true,
			]
		);
		$repeater->add_control(
			'icon_url_three',
			[
				'label' => __( 'URL 03', 'renev' ),
				'type'  => Controls_Manager::URL,
			]
		);
        $repeater->add_control(
			'social_icon_four',
			[
				'label'       => __( 'Icon 04', 'renev' ),
				'type'        => Controls_Manager::ICONS,
				'label_block' => true,
			]
		);
		$repeater->add_control(
			'icon_url_four',
			[
				'label' => __( 'URL 04', 'renev' ),
				'type'  => Controls_Manager::URL,
			]
		);
		$this->add_control(
			'team_lists',
			[
				'label'       => __( 'Team Lists', 'renev' ),
				'type'        => Controls_Manager::REPEATER,
				'fields'      => $repeater->get_controls(),
			]
		);
		$this->end_controls_section();

        // Team Box style
        $this->start_controls_section(
            'team_box_style',
            [
                'label' => __( 'Team Box', 'renev' ),
                'tab'   => Controls_Manager::TAB_STYLE,
            ]
        );
        $this->add_group_control(
            Group_Control_Background::get_type(),
            [
                'name' => 'team_after_background',
                'types' => [ 'classic', 'gradient', 'video' ],
                'selector' => '{{WRAPPER}} .team-author-boxarea::after, {{WRAPPER}} .team2-boxarea .img1::after',
            ]
        );
        $this->add_responsive_control(
            'team_box_margin',
            [
                'label' => __( 'Team Box Margin', 'renev' ),
                'type' => Controls_Manager::DIMENSIONS,
                'size_units' => [ 'px', 'em', '%' ],
                'selectors' => [
                    '{{WRAPPER}} .team-author-boxarea' => 'margin: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
                    '{{WRAPPER}} .team2-boxarea' => 'margin: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
                ],
            ]
        );
        $this->add_responsive_control(
            'team_aauthor_box_margin',
            [
                'label' => __( 'Team Author Img Margin', 'renev' ),
                'type' => Controls_Manager::DIMENSIONS,
                'size_units' => [ 'px', 'em', '%' ],
                'selectors' => [
                    '{{WRAPPER}} .team-author-boxarea .elements7' => 'margin: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
                ],
                'condition' => [
                    'team_layout!' => 'layout-2',
                ]
            ]
        );
        $this->end_controls_section();

        //Team Main Image style
         $this->start_controls_section(
            'team_main_img_style',
            [
                'label' => __( 'Team Main Img', 'renev' ),
                'tab'   => Controls_Manager::TAB_STYLE,
            ]
        );
        $this->add_responsive_control(
			'team_main_img_width',
			[
				'label' => __( 'Width', 'renev' ),
				'type' => Controls_Manager::SLIDER,
				'size_units' => [ 'px' ],
				'range' => [
					'px' => [
						'min' => 0,
						'max' => 1000,
						'step' => 1,
					]
				],
				'selectors' => [
					'{{WRAPPER}} .team-author-boxarea .img1 img' => 'width: {{SIZE}}{{UNIT}};',
                    '{{WRAPPER}} .team2-boxarea .img1 img' => 'width: {{SIZE}}{{UNIT}};',
                    
				],
			]
		);
        $this->add_responsive_control(
			'team_main_img_height',
			[
				'label' => __( 'Height', 'renev' ),
				'type' => Controls_Manager::SLIDER,
				'size_units' => [ 'px' ],
				'range' => [
					'px' => [
						'min' => 0,
						'max' => 1000,
						'step' => 1,
					]
				],
				'selectors' => [
					'{{WRAPPER}} .team-author-boxarea .img1 img' => 'height: {{SIZE}}{{UNIT}};',
                    '{{WRAPPER}} .team2-boxarea .img1 img' => 'height: {{SIZE}}{{UNIT}};',
				],
			]
		);
        $this->add_control(
            'team_main_img_border_radius',
            [
                'label' => esc_html__( 'Border Radius', 'renev' ),
                'type' => Controls_Manager::DIMENSIONS,
                'size_units' => [ 'px', '%', 'em', 'rem', 'custom' ],
                'selectors' => [
                    '{{WRAPPER}} .team-author-boxarea .img1 img' => 'border-radius: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
                    '{{WRAPPER}} .team2-boxarea .img1 img' => 'border-radius: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
                ],
            ]
        );
        $this->end_controls_section();

         // Content Box style
        $this->start_controls_section(
            'team_contant_box_style',
            [
                'label' => __( 'Team Content Box', 'renev' ),
                'tab'   => Controls_Manager::TAB_STYLE,
            ]
        );
        $this->add_responsive_control(
            'team_contant_padding',
            [
                'label' => __( 'Content Box Padding', 'renev' ),
                'type' => Controls_Manager::DIMENSIONS,
                'size_units' => [ 'px', 'em', '%' ],
                'selectors' => [
                    '{{WRAPPER}} .team-author-boxarea .content-area' => 'padding: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
                ],
                'condition' => [
                    'team_layout!' => 'layout-2',
                ]
            ]
        );
        $this->add_control(
            'team_contant_background',
            [
                'label' => __( 'Content Box Background', 'renev' ),
                'type' => Controls_Manager::COLOR,
                'selectors' => [
                    '{{WRAPPER}} .team-author-boxarea .content-area' => 'background: {{VALUE}}',
                ],
                'condition' => [
                    'team_layout!' => 'layout-2',
                ]
                
            ]
        );
        $this->add_control(
            'team_contant_border_radius',
            [
                'label' => esc_html__( 'Content Border Radius', 'renev' ),
                'type' => Controls_Manager::DIMENSIONS,
                'size_units' => [ 'px', '%', 'em', 'rem', 'custom' ],
                'selectors' => [
                    '{{WRAPPER}} .team-author-boxarea .content-area' => 'border-radius: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
                ],
                'condition' => [
                    'team_layout!' => 'layout-2',
                ]
            ]
        ); 

        //Team Author Name Style
        $this->add_control(
            'author_name_color',
            [
                'label' => __( 'Author Name Color', 'renev' ),
                'type' => Controls_Manager::COLOR,
                'selectors' => [
                    '{{WRAPPER}} .team-author-boxarea .content-area .content h4' => 'color: {{VALUE}}',
                    '{{WRAPPER}} .team2-boxarea .content-area a' => 'color: {{VALUE}}',
                ],
            ]
        );
        
        $this->add_control(
            'author_name_color_hover',
            [
                'label' => __( 'Author Name Hover Color', 'renev' ),
                'type' => Controls_Manager::COLOR,
                'selectors' => [
                    '{{WRAPPER}} .team-author-boxarea .content-area .content h4:hover' => 'color: {{VALUE}}',
                    '{{WRAPPER}} .team2-boxarea .content-area a:hover' => 'color: {{VALUE}}',
                ],
            ]
        );
        $this->add_group_control(
            Group_Control_Typography::get_type(),
            [
                'name' => 'author_name_typography',
                'selector' => '{{WRAPPER}} .team-author-boxarea .content-area .content h4, {{WRAPPER}} .team2-boxarea .content-area a',
            ]
        ); 

        $this->add_responsive_control(
            'author_name_margin',
            [
                'label' => __( 'Author Name Margin', 'renev' ),
                'type' => Controls_Manager::DIMENSIONS,
                'size_units' => [ 'px', 'em', '%' ],
                'selectors' => [
                    '{{WRAPPER}} .team-author-boxarea .content-area .content h4' => 'margin: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}} !important;',
                    '{{WRAPPER}} .team2-boxarea .content-area a' => 'margin: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}} !important;',
                ],
            ]
        );  
        //Team Author Profession Style
        $this->add_control(
            'author_profession_color',
            [
                'label' => __( 'Author Profession Color', 'renev' ),
                'type' => Controls_Manager::COLOR,
                'selectors' => [
                    '{{WRAPPER}} .team-author-boxarea .content-area .content p' => 'color: {{VALUE}}',
                    '{{WRAPPER}} .team2-boxarea .content-area p' => 'color: {{VALUE}}',
                ],
            ]
        );
        $this->add_group_control(
            Group_Control_Typography::get_type(),
            [
                'name' => 'author_profession_typography',
                'label' => __( 'Author Profession typography', 'renev' ),
                'selector' => '{{WRAPPER}} .team-author-boxarea .content-area .content p, {{WRAPPER}} .team2-boxarea .content-area p',
            ]
        ); 
        $this->add_responsive_control(
            'author_profession_margin',
            [
                'label' => __( 'Author Profession Margin', 'renev' ),
                'type' => Controls_Manager::DIMENSIONS,
                'size_units' => [ 'px', 'em', '%' ],
                'selectors' => [
                    '{{WRAPPER}} .team-author-boxarea .content-area .content p' => 'margin: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}} !important;',
                    '{{WRAPPER}} .team2-boxarea .content-area p' => 'margin: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}} !important;',
                ],
            ]
        );  
        $this->end_controls_section();

         //Team Share Icon Style
         $this->start_controls_section(
            'share_icon_style',
            [
                'label' => __('Share Icon', 'renev'),
                'tab'   => Controls_Manager::TAB_STYLE,
                'condition' => [
                    'team_layout!' => 'layout-2',
                ]
            ]
        );  
        $this->add_responsive_control(
            'share_icon_width',
            [
                'label'          => __('Width', 'renev'),
                'type'           => Controls_Manager::SLIDER,
                'size_units'     => ['%', 'px','vw'],
                'range'          => [
                    '%'  => [
                        'min' => 1,
                        'max' => 100,
                    ],
                    'px' => [
                        'min' => 1,
                        'max' => 1000,
                    ],
                    'vw' => [
                        'min' => 1,
                        'max' => 100,
                    ],
                ],
                'selectors'      => [
                    '{{WRAPPER}} .team-author-boxarea .content-area .share a' => 'width: {{SIZE}}{{UNIT}};',
                ],
            ]
        );
        $this->add_responsive_control(
            'share_icon_height',
            [
                'label'          => __('Height', 'renev'),
                'type'           => Controls_Manager::SLIDER,
                'size_units'     => ['px','%', 'vh'],
                'range'          => [
                    'px' => [
                        'min' => 1,
                        'max' => 1000,
                    ],
					'%'  => [
                        'min' => 1,
                        'max' => 100,
                    ],
                    'vh' => [
                        'min' => 1,
                        'max' => 100,
                    ],
                ],
                'selectors'      => [
                    '{{WRAPPER}} .team-author-boxarea .content-area .share a' => 'height: {{SIZE}}{{UNIT}} !important;',
                ],
            ]
        );
        $this->add_control(
            'share_icon_bg',
            [
                'label' => __( 'Background Color', 'renev' ),
                'type' => Controls_Manager::COLOR,
                'selectors' => [
                    '{{WRAPPER}} .team-author-boxarea .content-area .share a' => 'background-color: {{VALUE}}',
                ],
            ]
        );
        $this->add_control(
            'share_border_radius',
            [
                'label' => esc_html__( 'Border Radius', 'renev' ),
                'type' => Controls_Manager::DIMENSIONS,
                'size_units' => [ 'px', '%', 'em', 'rem', 'custom' ],
                'selectors' => [
                    '{{WRAPPER}} .team-author-boxarea .content-area .share a' => 'border-radius: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
                ],
            ]
        );
        $this->add_responsive_control(
			'share_icon_size',
			[
				'label' => __( 'Share Icon Size', 'renev' ),
				'type' => Controls_Manager::SLIDER,
				'size_units' => [ 'px' ],
				'range' => [
					'px' => [
						'min' => 0,
						'max' => 100,
						'step' => 1,
					]
				],
				'selectors' => [
					'{{WRAPPER}} .team-author-boxarea .content-area .share a img' => 'font-size: {{SIZE}}{{UNIT}};',
				],
			]
		);
        $this->end_controls_section();

        //Team Share Icon Style
        $this->start_controls_section(
            'social_icon_style',
            [
                'label' => __('Social Icon', 'renev'),
                'tab'   => Controls_Manager::TAB_STYLE,
            ]
        );  
        $this->add_responsive_control(
            'social_icon_width',
            [
                'label'          => __('Width', 'renev'),
                'type'           => Controls_Manager::SLIDER,
                'size_units'     => ['%', 'px','vw'],
                'range'          => [
                    '%'  => [
                        'min' => 1,
                        'max' => 100,
                    ],
                    'px' => [
                        'min' => 1,
                        'max' => 1000,
                    ],
                    'vw' => [
                        'min' => 1,
                        'max' => 100,
                    ],
                ],
                'selectors'      => [
                    '{{WRAPPER}} .team-author-boxarea .list ul li a' => 'width: {{SIZE}}{{UNIT}};',
                    '{{WRAPPER}} .team2-boxarea ul li a' => 'width: {{SIZE}}{{UNIT}};',
                ],
            ]
        );
        
        $this->add_responsive_control(
            'social_icon_height',
            [
                'label'          => __('Height', 'renev'),
                'type'           => Controls_Manager::SLIDER,
                'size_units'     => ['px','%', 'vh'],
                'range'          => [
                    'px' => [
                        'min' => 1,
                        'max' => 1000,
                    ],
					'%'  => [
                        'min' => 1,
                        'max' => 100,
                    ],
                    'vh' => [
                        'min' => 1,
                        'max' => 100,
                    ],
                ],
                'selectors'      => [
                    '{{WRAPPER}} .team-author-boxarea .list ul li a' => 'height: {{SIZE}}{{UNIT}} !important;',
                    '{{WRAPPER}} .team2-boxarea ul li a' => 'height: {{SIZE}}{{UNIT}} !important;',
                ],
            ]
        );
        $this->add_control(
            'social_icon_color',
            [
                'label' => __( 'Icon Color', 'renev' ),
                'type' => Controls_Manager::COLOR,
                'selectors' => [
                    '{{WRAPPER}} .team-author-boxarea .list ul li a i' => 'color: {{VALUE}}',
                    '{{WRAPPER}} .team-author-boxarea .list ul li a svg path' => 'fill: {{VALUE}}',

                    '{{WRAPPER}} .team2-boxarea ul li a i' => 'color: {{VALUE}}',
                    '{{WRAPPER}} .team2-boxarea ul li a svg path' => 'fill: {{VALUE}}',
                ],
            ]
        );
        $this->add_control(
            'social_icon_hover_color',
            [
                'label' => __( 'Icon Hover Color', 'renev' ),
                'type' => \Elementor\Controls_Manager::COLOR,
                'selectors' => [
                    '{{WRAPPER}} .team-author-boxarea .list ul li a:hover i'         => 'color: {{VALUE}};',
                    '{{WRAPPER}} .team-author-boxarea .list ul li a:hover svg path'  => 'fill: {{VALUE}};',
                    
                    '{{WRAPPER}} .team2-boxarea ul li a:hover i'         => 'color: {{VALUE}};',
                    '{{WRAPPER}} .team2-boxarea ul li a:hover svg path'  => 'fill: {{VALUE}};',
                ],
            ]
        );
        
        $this->add_control(
            'social_icon_bg',
            [
                'label' => __( 'Background Color', 'renev' ),
                'type' => Controls_Manager::COLOR,
                'selectors' => [
                    '{{WRAPPER}} .team-author-boxarea .list ul li a' => 'background-color: {{VALUE}}',
                    '{{WRAPPER}} .team2-boxarea ul li a' => 'background-color: {{VALUE}}',
                ],
            ]
        );
        $this->add_group_control(
            Group_Control_Background::get_type(),
            [
                'name' => 'social_icon_bg_hover',
                'label' => __( 'Social Icon Hover Background', 'renev' ),
                'types' => [ 'classic', 'gradient', 'video' ],
                'selector' => '{{WRAPPER}} .team-author-boxarea .list ul li a:hover, {{WRAPPER}} .team2-boxarea ul li a:hover',
            ]
        );
        
        $this->add_control(
            'social_border_radius',
            [
                'label' => esc_html__( 'Border Radius', 'renev' ),
                'type' => Controls_Manager::DIMENSIONS,
                'size_units' => [ 'px', '%', 'em', 'rem', 'custom' ],
                'selectors' => [
                    '{{WRAPPER}} .team-author-boxarea .list ul li a' => 'border-radius: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
                    '{{WRAPPER}} .team2-boxarea ul li a' => 'border-radius: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
                ],
            ]
        );
        $this->add_responsive_control(
			'social_icon_size',
			[
				'label' => __( 'Social Icon Size', 'renev' ),
				'type' => Controls_Manager::SLIDER,
				'size_units' => [ 'px' ],
				'range' => [
					'px' => [
						'min' => 0,
						'max' => 100,
						'step' => 1,
					]
				],
				'selectors' => [
					'{{WRAPPER}} .team-author-boxarea .list ul li a i' => 'font-size: {{SIZE}}{{UNIT}};',
                    '{{WRAPPER}} .team-author-boxarea .list ul li a svg' => 'width: {{SIZE}}{{UNIT}};',

                    '{{WRAPPER}} .team2-boxarea ul li a i' => 'font-size: {{SIZE}}{{UNIT}};',
                    '{{WRAPPER}} .team2-boxarea ul li a svg' => 'width: {{SIZE}}{{UNIT}};',
				],
			]
		);
        $this->end_controls_section();
	}
    // Get All teams
    protected function render() {
        $settings = $this->get_settings_for_display();
        $team_lists = $settings['team_lists'];
        $layout = $settings['team_layout'];

        ?>  
            <?php
                if ( $layout) {
                    include('team/'.$layout.'.php');
                }
            ?> 
        <?php
    }

}

$widgets_manager->register( new \Renev_Team_Member() );