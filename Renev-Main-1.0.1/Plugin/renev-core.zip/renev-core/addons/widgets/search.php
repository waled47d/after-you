<?php
use \Elementor\Widget_Base;
use \Elementor\Controls_Manager;
use \Elementor\Group_Control_Typography;
use \Elementor\Group_Control_Text_Shadow;
use \Elementor\Group_Control_Border;
use \Elementor\Group_Control_Box_Shadow;
use \Elementor\Repeater;
use \Elementor\Utils;
/**
 *
 * Renev Search Widget .
 *
 */
class Renev_Search extends Widget_Base {

	public function get_name() {
		return 'renev_search';
	}

	public function get_title() {
		return __( 'Renev Search', 'renev' );
	}

	public function get_icon() {
		return 'eicon-code';
    }

	public function get_categories() {
		return [ 'renev' ];
	}

	protected function register_controls() {

        $this->start_controls_section(
            'content_section',
            [
                'label' => __('Content', 'renev'),
                'tab'   => Controls_Manager::TAB_CONTENT,
            ]
        );
        $this->add_control(
            'search_img',
            [
                'label'   => __( 'Search White', 'renev' ),
                'type'    => Controls_Manager::MEDIA,
                'default' => [
                    
                ],
            ]
        );
        $this->add_control(
            'search_img_black',
            [
                'label'   => __( 'Search Black', 'renev' ),
                'type'    => Controls_Manager::MEDIA,
                'default' => [
                    
                ],
            ]
        );
        $this->end_controls_section();

        //Search Style
        $this->start_controls_section(
            'search_style',
            [
                'label' => __( 'Search Section', 'renev' ),
                'tab'   => Controls_Manager::TAB_STYLE,
            ]
        );
        $this->add_responsive_control(
            'search_height',
            [
                'label' => esc_html__( 'Search Height', 'renev' ),
                'type' => Controls_Manager::SLIDER,
                'size_units' => [ 'px', '%', 'em', 'rem' ],
                'range' => [
                    'px' => [
                        'min' => 0,
                        'max' => 1000,
                        'step' => 1,
                    ],
                    '%' => [
                        'min' => 0,
                        'max' => 100,
                    ],
                    'em' => [
                        'min' => 0,
                        'max' => 50,
                    ],
                    'rem' => [
                        'min' => 0,
                        'max' => 50,
                    ],
                ],
                'selectors' => [
                    '{{WRAPPER}} .header-search-form-wrapper' => 'height: {{SIZE}}{{UNIT}};',
                ],
            ]
        );   
        $this->add_control(
            'search-bg',
            [
                'label' => __( 'Search Background', 'renev' ),
                'type' => Controls_Manager::COLOR,
                'selectors' => [
                    '{{WRAPPER}} .header-search-form-wrapper' => 'background: {{VALUE}}',
                ],
            ]
        ); 
        //Search Close Style
        $this->add_responsive_control(
            'search_close_width',
            [
                'label' => esc_html__( 'Search Close Width', 'renev' ),
                'type' => Controls_Manager::SLIDER,
                'size_units' => [ 'px', '%', 'em', 'rem' ],
                'range' => [
                    'px' => [
                        'min' => 0,
                        'max' => 1000,
                        'step' => 1,
                    ],
                    '%' => [
                        'min' => 0,
                        'max' => 100,
                    ],
                    'em' => [
                        'min' => 0,
                        'max' => 50,
                    ],
                    'rem' => [
                        'min' => 0,
                        'max' => 50,
                    ],
                ],
                'selectors' => [
                    '{{WRAPPER}} .header-search-form-wrapper .tx-search-close' => 'width: {{SIZE}}{{UNIT}};',
                ],
            ]
        );   
        $this->add_responsive_control(
            'search_close_height',
            [
                'label' => esc_html__( 'Search Close Height', 'renev' ),
                'type' => Controls_Manager::SLIDER,
                'size_units' => [ 'px', '%', 'em', 'rem' ],
                'range' => [
                    'px' => [
                        'min' => 0,
                        'max' => 1000,
                        'step' => 1,
                    ],
                    '%' => [
                        'min' => 0,
                        'max' => 100,
                    ],
                    'em' => [
                        'min' => 0,
                        'max' => 50,
                    ],
                    'rem' => [
                        'min' => 0,
                        'max' => 50,
                    ],
                ],
                'selectors' => [
                    '{{WRAPPER}} .header-search-form-wrapper .tx-search-close' => 'height: {{SIZE}}{{UNIT}};',
                ],
            ]
        );   
        $this->add_control(
            'search_close-bg',
            [
                'label' => __( 'Close Background', 'renev' ),
                'type' => Controls_Manager::COLOR,
                'selectors' => [
                    '{{WRAPPER}} .header-search-form-wrapper .tx-search-close' => 'background: {{VALUE}}',
                ],
            ]
        ); 
        $this->add_responsive_control(
            'submenu_font_size',
            [
                'label' => esc_html__('Close Font Size', 'renev'),
                'type' => \Elementor\Controls_Manager::SLIDER,
                'size_units' => ['px', 'em', 'rem'],
                'range' => [
                    'px' => [
                        'min' => 10,
                        'max' => 40,
                    ],
                    'em' => [
                        'min' => 0.5,
                        'max' => 3,
                    ],
                ],
                'selectors' => [
                    '{{WRAPPER}} .header-search-form-wrapper .tx-search-close' => 'font-size: {{SIZE}}{{UNIT}};',
                ],
            ]
        );
        $this->add_control(
            'search_close_font_color',
            [
                'label' => __( 'Close Font Color', 'renev' ),
                'type' => Controls_Manager::COLOR,
                'selectors' => [
                    '{{WRAPPER}} .header-search-form-wrapper .tx-search-close' => 'color: {{VALUE}}',
                ],
            ]
        );
        $this->end_controls_section();
    }

    // Render
	protected function render() {
        $settings = $this->get_settings_for_display();
        
        ?>
        <header class="homepage1-menu">
            <div class="vl-hero-btn d-none d-lg-block text-end">
                <div class="search-icon header__search header-search-btn">
                    <a href="#">
                        <img src="<?php echo esc_url( $settings['search_img']['url'] ); ?>" alt="">
                    </a>
                </div>
            </div>
         </header>

         <div class="header-search-form-wrapper">
            <div class="tx-search-close tx-close">
                <i class="fa-solid fa-xmark"></i>
            </div>
                <div class="header-search-container">
                    <form role="search" class="search-form">
                        <input type="search"  class="search-field" placeholder="Search …" value="" name="s">
                        <button type="submit" class="search-submit">
                            <img src="<?php echo esc_url( $settings['search_img_black']['url'] ); ?>" alt="">
                        </button>
                    </form>
                </div>
            </div>
        <?php
    }

}
$widgets_manager->register( new \Renev_Search() );