<div class="hero1-section-area">
    <div class="container">
        <div class="row align-items-center">
            <div class="col-lg-7">
                <div class="hero-header-area">
                    <h5>
                        <img src="<?php echo esc_url( $settings['heading_image']['url'] ); ?>" alt="">
                        <?php echo renev_kses( $settings['section_heading'] ); ?>
                    </h5>
                    <h1 class="text-anime-style-3">
                        <?php echo esc_html( $settings[ 'section_subtitle' ]  ); ?>
                        <img src="<?php echo esc_url( $settings['subtitle_shape1']['url'] ); ?>" alt="" class="elements1 keyframe5">
                    </h1>
                    <h1 class="text-anime-style-3">
                        <img src="<?php echo esc_url( $settings['subtitle_shape2']['url'] ); ?>" alt="" class="others-img1">
                        <?php echo esc_html( $settings[ 'section_subtitle2' ]  ); ?> 
                    </h1>
                </div>
            </div>
            <div class="col-lg-1"></div>
            <div class="col-lg-4">
                <div class="imges-header">
                    <div class="img1">
                        <img src="<?php echo esc_url( $settings['circle_icon_img1']['url'] ); ?>" alt="" class="keyframe6">
                    </div>
                    <div class="arrow">
                        <a href="<?php echo esc_url($settings['arrow_link']['url']); ?>">
                            <img src="<?php echo esc_url( $settings['circle_icon_img2']['url'] ); ?>" alt="" class="keyframe5">
                            <img src="<?php echo esc_url( $settings['circle_icon_img3']['url'] ); ?>" alt="" class="arrow1">
                        </a>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>