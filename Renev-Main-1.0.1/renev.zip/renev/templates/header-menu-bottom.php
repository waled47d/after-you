<?php
/**
 * @Packge     : Renev
 * @Version    : 1.0
 * @Author     : Mthemeus
 * @Author URI : https://www.mthemeus.com/
 *
 */
 
    // Block direct access
    if( !defined( 'ABSPATH' ) ){
        exit();
    }

    if( defined( 'CMB2_LOADED' )  ){
        if( !empty( renev_meta('page_breadcrumb_area') ) ) {
            $renev_page_breadcrumb_area  = renev_meta('page_breadcrumb_area');
        } else {
            $renev_page_breadcrumb_area = '1';
        }
    }else{
        $renev_page_breadcrumb_area = '1';
    }

    $allowhtml = array(
        'p'         => array(
            'class'     => array()
        ),
        'span'      => array(
            'class'     => array(),
        ),
        'a'         => array(
            'href'      => array(),
            'title'     => array()
        ),
        'br'        => array(),
        'em'        => array(),
        'strong'    => array(),
        'b'         => array(),
        'sub'       => array(),
        'sup'       => array(),
    );

    if(  is_page() || is_page_template( 'template-builder.php' )  ) {
        if( $renev_page_breadcrumb_area == '1' ) {
            echo '<!-- Page title -->';
                if (defined('CMB2_LOADED') || class_exists('ReduxFramework')) {
                    echo '<div class="inner-section-area live-breadcrumb">';
                } else {
                    echo '<div class="inner-section-area local-breadcrumb">';
                }
                    echo '<div class="container">';
                        echo '<div class="row align-items-center">';
                            $prefix = '_renev_'; 
                            $breadcrumb_image_url = get_post_meta( get_the_ID(), $prefix . 'breadcumb_image', true );
                            
                            // Determine the column classes based on whether the image is uploaded
                            $upper_col_class = $breadcrumb_image_url ? 'col-xl-7' : 'col-lg-7';
                            echo '<div class="' . esc_attr( $upper_col_class ) . '">';
                                echo '<div class="hero-header-area">';
                                    if( defined('CMB2_LOADED') || class_exists('ReduxFramework') ) {
                                        if( renev_meta('page_breadcrumb_settings') == 'page' ) {
                                            $renev_breadcrumb_switcher = renev_meta('page_breadcrumb_trigger');
                                        } else {
                                            $renev_breadcrumb_switcher = renev_opt('renev_enable_breadcrumb');
                                        }

                                        } else {
                                        $renev_breadcrumb_switcher = '1';
                                        }
                                        
                                        // page title
                                        if( defined('CMB2_LOADED') || class_exists('ReduxFramework') ) {
                                            if( renev_meta('page_breadcrumb_settings') == 'page' ) {
                                                $renev_page_title_switcher = renev_meta('page_title');
                                            } elseif( renev_opt('renev_page_title_switcher') == true ) {
                                                $renev_page_title_switcher = renev_opt('renev_page_title_switcher');
                                            }else{
                                                $renev_page_title_switcher = '1';
                                            }
                                        } else {
                                            $renev_page_title_switcher = '1';
                                        }

                                        if( $renev_page_title_switcher == '1' ){
                                            if( class_exists( 'ReduxFramework' ) ){
                                                $renev_page_title_tag    = renev_opt('renev_page_title_tag');
                                            }else{
                                                $renev_page_title_tag    = 'h1';
                                            }

                                            if( defined( 'CMB2_LOADED' )  ){
                                                if( !empty( renev_meta('page_title_settings') ) ) {
                                                    $renev_custom_title = renev_meta('page_title_settings');
                                                } else {
                                                    $renev_custom_title = 'default';
                                                }
                                            }else{
                                                $renev_custom_title = 'default';
                                            }

                                            if( $renev_custom_title == 'default' ) {
                                                echo renev_heading_tag(
                                                    array(
                                                        "tag"   => esc_attr( $renev_page_title_tag ),
                                                        "text"  => esc_html( get_the_title( ) ),
                                                        'class' => 'title'
                                                    )
                                                );
                                            } else {
                                                echo renev_heading_tag(
                                                    array(
                                                        "tag"   => esc_attr( $renev_page_title_tag ),
                                                        "text"  => esc_html( renev_meta('custom_page_title') ),
                                                        'class' => 'title'
                                                    )
                                                );
                                            }
                                        }

                                        if ($renev_breadcrumb_switcher == '1' && (is_page() || is_page_template('template-builder.php'))) {
                                        ob_start(); // Start output buffering
                                        renev_breadcrumbs(array(
                                            'breadcrumbs_classes' => 'nav',
                                        ));
                                        $breadcrumbs = ob_get_clean(); // Get the buffered content and clear the buffer

                                        if (!empty($breadcrumbs)) { // Only show the div if breadcrumbs are not empty
                                            echo '<h4>';
                                                echo wp_kses_post($breadcrumbs);
                                           echo ' </h4>';
                                        }
                                    }
                                 
                                echo '</div>';
                            echo '</div>';

                            echo '<div class="col-lg-2">';
                            echo '</div>';

                            if( class_exists('ReduxFramework') ) {
                                $renev_breadcrumb_image_switcher = renev_opt( 'renev_enable_breadcrumb_right_image' );
                            } else {
                                $renev_breadcrumb_image_switcher = '';
                            }
                            $link = renev_opt('renev_breadcrumb_image_link');

                            if ($renev_breadcrumb_image_switcher == '1') {
                                echo '<div class="col-lg-3">';
                                    echo '<div class="imges-header">';
                                    $breadcrumb_main_image   = renev_opt('renev_breadcrumb_main_image');
                                    $breadcrumb_image_two    = renev_opt('renev_breadcrumb_image_two');
                                    $breadcrumb_image_three  = renev_opt('renev_breadcrumb_image_three');
                                    
                                    $main_image_url   = !empty($breadcrumb_main_image['url']) ? $breadcrumb_main_image['url'] : '';
                                    $image_two_url    = !empty($breadcrumb_image_two['url']) ? $breadcrumb_image_two['url'] : '';
                                    $image_three_url  = !empty($breadcrumb_image_three['url']) ? $breadcrumb_image_three['url'] : '';
                                    

                                        if ( $main_image_url ) {
                                            echo '<div class="img1">';
                                                echo '<img src="' . esc_url( $main_image_url ) . '" alt="" class="' . esc_attr__( 'keyframe6', 'renev' ) . '">';
                                            echo '</div>';
                                        }
                                        echo '<div class="arrow">';
                                            echo '<a href="' . esc_url( $link ) . '">';
                                                if ( $image_two_url ) {
                                                    echo '<img src="' . esc_url( $image_two_url ) . '" alt="" class="' . esc_attr__( 'keyframe5', 'renev' ) . '">';
                                                }
                                                if ( $image_three_url ) {
                                                    echo '<img src="' . esc_url( $image_three_url ) . '" alt="" class="' . esc_attr__( 'arrow1', 'renev' ) . '">';
                                                }
                                            echo '</a>';
                                        echo '</div>';
                                    echo '</div>';
                                echo '</div>';
                            }

                        echo '</div>';
                    echo '</div>';                              
                echo '</div>';
            echo '<!-- End of Page title -->';
        }
    } else {
        echo '<!-- Page title -->';
        if (defined('CMB2_LOADED') || class_exists('ReduxFramework')) {
            echo '<div class="inner-section-area live-breadcrumb">';
        } else {
            echo '<div class="inner-section-area local-breadcrumb">';
        }
            echo '<div class="container">';
                echo '<div class="row align-items-center">';
                    $prefix = '_renev_'; 
                    $breadcrumb_image_url = '';
                    
                    if ( is_page() || is_page_template( 'template-builder.php' ) || is_home() ) {
                        $blog_page_id = get_option( 'page_for_posts' );
                        if ( $blog_page_id ) {
                            $breadcrumb_image_url = get_post_meta( $blog_page_id, $prefix . 'breadcumb_image', true );
                        }
                    }
                    
                    // Determine the column classes based on whether the image is uploaded
                    $upper_col_class = $breadcrumb_image_url ? 'col-xl-7' : 'col-lg-7';
                    echo '<div class="' . esc_attr( $upper_col_class ) . '">';
                        echo '<div class="hero-header-area">';
                            if( defined('CMB2_LOADED') || class_exists('ReduxFramework') ) {

                            
                                if( renev_meta('page_breadcrumb_settings') == 'page' ) {
                                    $renev_breadcrumb_switcher = renev_meta('page_breadcrumb_trigger');
                                } else {
                                    $renev_breadcrumb_switcher = renev_opt('renev_enable_breadcrumb');
                                }

                            } else {
                                $renev_breadcrumb_switcher = '1';
                            }

                            // page title
                            if( class_exists( 'ReduxFramework' )  ){
                                $renev_page_title_switcher  = renev_opt('renev_page_title_switcher');
                            }else{
                                $renev_page_title_switcher = '1';
                            }

                            if( $renev_page_title_switcher ){
                                if( class_exists( 'ReduxFramework' ) ){
                                    $renev_page_title_tag    = renev_opt('renev_page_title_tag');
                                }else{
                                    $renev_page_title_tag    = 'h1';
                                }
                                if ( is_archive() ){
                                    echo renev_heading_tag(
                                        array(
                                            "tag"   => esc_attr( $renev_page_title_tag ),
                                            "text"  => wp_kses( get_the_archive_title(), $allowhtml ),
                                        )
                                    );
                                }elseif ( is_home() ){
                                    $renev_blog_page_title_setting = renev_opt('renev_blog_page_title_setting');
                                    $renev_blog_page_title_switcher = renev_opt('renev_blog_page_title_switcher');
                                    $renev_blog_page_custom_title = renev_opt('renev_blog_page_custom_title');
                                    if( class_exists('ReduxFramework') ){
                                        if( $renev_blog_page_title_switcher ){
                                            echo renev_heading_tag(
                                                array(
                                                    "tag"   => esc_attr( $renev_page_title_tag ),
                                                    "text"  => !empty( $renev_blog_page_custom_title ) && $renev_blog_page_title_setting == 'custom' ? esc_html( $renev_blog_page_custom_title) : esc_html__( 'Blog', 'renev' ),
                                                )
                                            );
                                        }
                                    }else{
                                        echo renev_heading_tag(
                                            array(
                                                "tag"   => "h1",
                                                "text"  => esc_html__( 'Blog', 'renev' ),
                                        
                                            )
                                        );
                                    }
                                }elseif( is_search() ){
                                    echo renev_heading_tag(
                                        array(
                                            "tag"   => esc_attr( $renev_page_title_tag ),
                                            "text"  => esc_html__( 'Search Result', 'renev' ),
                                        
                                        )
                                    );
                                }elseif( is_404() ){
                                    echo renev_heading_tag(
                                        array(
                                            "tag"   => esc_attr( $renev_page_title_tag ),
                                            "text"  => esc_html__( '404 PAGE', 'renev' ),
                                        
                                        )
                                    );
                                }elseif( is_singular( 'renev_class' ) ){
                                    echo renev_heading_tag(
                                        array(
                                            "tag"   => "h1",
                                            "text"  => esc_html__( 'Class Details', 'renev' ),
                                        
                                        )
                                    );
                                }elseif( is_singular( 'renev_event' ) ){
                                    echo renev_heading_tag(
                                        array(
                                            "tag"   => "h1",
                                            "text"  => esc_html__( 'Event Details', 'renev' ),
                                            
                                        )
                                    );
                                }elseif( is_singular( 'renev_teacher' ) ){
                                    echo renev_heading_tag(
                                        array(
                                            "tag"   => "h1",
                                            "text"  => esc_html__( 'Teacher Details', 'renev' ),
                                            
                                        )
                                    );
                                }elseif( is_singular( 'product' ) ){
                                    $posttitle_position  = renev_opt('renev_product_details_title_position');
                                    $postTitlePos = false;
                                    if( class_exists( 'ReduxFramework' ) ){
                                        if( $posttitle_position && $posttitle_position != 'header' ){
                                            $postTitlePos = true;
                                        }
                                    }else{
                                        $postTitlePos = false;
                                    }
                                    
                                    if( $postTitlePos != true ){
                                        echo renev_heading_tag(
                                            array(
                                                "tag"   => esc_attr( $renev_page_title_tag ),
                                                "text"  => wp_kses( get_the_title( ), $allowhtml ),
                                            
                                            )
                                        );
                                    } else {
                                        if( class_exists( 'ReduxFramework' ) ){
                                            $renev_post_details_custom_title  = renev_opt('renev_product_details_custom_title');
                                        }else{
                                            $renev_post_details_custom_title = __( 'Shop Details','renev' );
                                        }

                                        if( !empty( $renev_post_details_custom_title ) ) {
                                            echo renev_heading_tag(
                                                array(
                                                    "tag"   => esc_attr( $renev_page_title_tag ),
                                                    "text"  => wp_kses( $renev_post_details_custom_title, $allowhtml ),
                                                    
                                                )
                                            );
                                        }
                                    }
                                }else{
                                    $posttitle_position  = renev_opt('renev_post_details_title_position');
                                    $postTitlePos = false;
                                    if( is_single() ){
                                        if( class_exists( 'ReduxFramework' ) ){
                                            if( $posttitle_position && $posttitle_position != 'header' ){
                                                $postTitlePos = true;
                                            }
                                        }else{
                                            $postTitlePos = false;
                                        }
                                    }
                                    if( is_singular( 'product' ) ){
                                        $posttitle_position  = renev_opt('renev_product_details_title_position');
                                        $postTitlePos = false;
                                        if( class_exists( 'ReduxFramework' ) ){
                                            if( $posttitle_position && $posttitle_position != 'header' ){
                                                $postTitlePos = true;
                                            }
                                        }else{
                                            $postTitlePos = false;
                                        }
                                    }

                                    if( $postTitlePos != true ){
                                        echo renev_heading_tag(
                                            array(
                                                "tag"   => esc_attr( $renev_page_title_tag ),
                                                "text"  => wp_kses( get_the_title( ), $allowhtml ),
                                            
                                            )
                                        );
                                    } else {
                                        if( class_exists( 'ReduxFramework' ) ){
                                            $renev_post_details_custom_title  = renev_opt('renev_post_details_custom_title');
                                        }else{
                                            $renev_post_details_custom_title = __( 'Blog Details','renev' );
                                        }

                                        if( !empty( $renev_post_details_custom_title ) ) {
                                            echo renev_heading_tag(
                                                array(
                                                    "tag"   => esc_attr( $renev_page_title_tag ),
                                                    "text"  => wp_kses( $renev_post_details_custom_title, $allowhtml ),
                                                
                                                )
                                            );
                                        }
                                    }
                                }
                            }

                            if ($renev_breadcrumb_switcher == '1' && (is_page() || is_page_template('template-builder.php'))) {
                                ob_start(); // Start output buffering
                                    renev_breadcrumbs(array(
                                        'breadcrumbs_classes' => 'nav',
                                    ));
                                $breadcrumbs = ob_get_clean(); // Get the buffered content and clear the buffer

                                if (!empty($breadcrumbs)) { // Only show the div if breadcrumbs are not empty
                                    echo '<h4>';
                                        echo wp_kses_post($breadcrumbs);
                                    echo ' </h4>';
                                }
                                
                            }else{
                                if( class_exists('ReduxFramework') ) {
                                    $renev_breadcrumb_switcher = renev_opt( 'renev_enable_breadcrumb' );
                                } else {
                                    $renev_breadcrumb_switcher = '1';
                                }
                                if ($renev_breadcrumb_switcher == '1') {
                                    ob_start(); // Start output buffering
                                    renev_breadcrumbs(array(
                                        'breadcrumbs_classes' => 'nav',
                                    ));
                                    $breadcrumbs = ob_get_clean(); // Get the buffered content and clear the buffer
                                
                                    if (!empty($breadcrumbs)) { // Only show the div if breadcrumbs are not empty
                                        echo '<h4>';
                                            echo wp_kses_post($breadcrumbs);
                                        echo ' </h4>';
                                    }
                                }
                            }

                        echo '</div>';
                    echo '</div>';

                    echo '<div class="col-lg-2">';
                    echo '</div>';



                    if( class_exists('ReduxFramework') ) {
                        $renev_breadcrumb_image_switcher = renev_opt( 'renev_enable_breadcrumb_right_image' );
                    } else {
                        $renev_breadcrumb_image_switcher = '';
                    }
                    $link = renev_opt('renev_breadcrumb_image_link');

                    if ($renev_breadcrumb_image_switcher == '1') {
                        echo '<div class="col-lg-3">';
                            echo '<div class="imges-header">';
                            $breadcrumb_main_image   = renev_opt('renev_breadcrumb_main_image');
                            $breadcrumb_image_two    = renev_opt('renev_breadcrumb_image_two');
                            $breadcrumb_image_three  = renev_opt('renev_breadcrumb_image_three');
                            
                            $main_image_url   = !empty($breadcrumb_main_image['url']) ? $breadcrumb_main_image['url'] : '';
                            $image_two_url    = !empty($breadcrumb_image_two['url']) ? $breadcrumb_image_two['url'] : '';
                            $image_three_url  = !empty($breadcrumb_image_three['url']) ? $breadcrumb_image_three['url'] : '';
                            

                                if ( $main_image_url ) {
                                    echo '<div class="img1">';
                                        echo '<img src="' . esc_url( $main_image_url ) . '" alt="" class="' . esc_attr__( 'keyframe6', 'renev' ) . '">';
                                    echo '</div>';
                                }
                                echo '<div class="arrow">';
                                    echo '<a href="' . esc_url( $link ) . '">';
                                        if ( $image_two_url ) {
                                            echo '<img src="' . esc_url( $image_two_url ) . '" alt="" class="' . esc_attr__( 'keyframe5', 'renev' ) . '">';
                                        }
                                        if ( $image_three_url ) {
                                            echo '<img src="' . esc_url( $image_three_url ) . '" alt="" class="' . esc_attr__( 'arrow1', 'renev' ) . '">';
                                        }
                                    echo '</a>';
                                echo '</div>';
                            echo '</div>';
                        echo '</div>';
                    }

                echo '</div>';
            echo '</div>';
        echo '</div>';
        echo '<!-- End of Page title -->';
    }