<?php
/**
 * @Packge     : Renev
 * @Version    : 1.0
 * @Author     : Mthemeus
 * @Author URI : https://www.mthemeus.com/
 *
 */

    // Block direct access
    if( ! defined( 'ABSPATH' ) ){
        exit();
    }

    // preloader hook function
    if( ! function_exists( 'renev_preloader_wrap_cb' ) ) {
        function renev_preloader_wrap_cb() {
            $preloader_display              =  renev_opt('renev_display_preloader');

            if( class_exists('ReduxFramework') ){
                if( $preloader_display ){
                    echo '<div id="preloader">';
                        echo '<div id="loader"></div>';
                    echo '</div>';
                }
            }else{
                echo '<div id="preloader">';
                    echo '<div id="loader"></div>';
                echo '</div>';         
            }
        }
    }


    // cursor hook function
    if( ! function_exists( 'renev_cursor_wrap_cb' ) ) {
        function renev_cursor_wrap_cb() {
            $cursor_display              =  renev_opt('renev_display_cursor');

            if( class_exists('ReduxFramework') ){
                if( $cursor_display ){                    
                    echo '<div class="procus-cursor" style="transform: translate3d(calc(-50% + 1919px), calc(-50% + 787px), 0px);">';
                    echo '</div>';
                    echo '<div class="procus-cursor2" style="left: 551px; top: 918px;">';
                    echo '</div>';
                }
            }
        }
    }

    // back top top hook function
    if( ! function_exists( 'renev_back_to_top_wrap_cb' ) ) {
        function renev_back_to_top_wrap_cb() {
            $back_to_top_display =  renev_opt('renev_display_back_to_top');

            if( class_exists('ReduxFramework') ){
                if( $back_to_top_display ){
                    echo '<div class="paginacontainer">';
                        echo '<div class="progress-wrap">';
                            echo '<svg class="progress-circle svg-content" width="100%" height="100%" viewBox="-1 -1 102 102">';
                                echo '<path d="M50,1 a49,49 0 0,1 0,98 a49,49 0 0,1 0,-98"/>';
                            echo '</svg>';
                        echo '</div>';
                    echo '</div>';
                }
            }
        }
    }


    // Header Hook function
    if( !function_exists('renev_header_cb') ) {
        function renev_header_cb( ) {
            get_template_part('templates/header');
            get_template_part('templates/header-menu-bottom');
        }
    }

    // back top top hook function
    if( ! function_exists( 'renev_back_to_top_cb' ) ) {
        function renev_back_to_top_cb( ) {
            $backtotop_trigger = renev_opt('renev_display_bcktotop');
            $custom_bcktotop   = renev_opt('renev_custom_bcktotop');
            $custom_bcktotop_icon   = renev_opt('renev_custom_bcktotop_icon');
            if( class_exists( 'ReduxFramework' ) ) {
                if( $backtotop_trigger ) {
                    if( $custom_bcktotop ) {
                        echo '<!-- Back to Top Button -->';
                        echo '<a href="#" class="scrollToTop scroll-btn">';
                            echo '<i class="fa '.esc_attr( $custom_bcktotop_icon ).'"></i>';
                        echo '</a>';
                        echo '<!-- End of Back to Top Button -->';
                    } else {
                        echo '<!-- Back to Top Button -->';
                        echo '<a href="#" class="scrollToTop scroll-btn">';
                            echo '<i class="fas fa-arrow-up"></i>';
                        echo '</a>';
                        echo '<!-- End of Back to Top Button -->';
                    }
                }
            }

        }
    }
    // Blog Start Wrapper Function
    if( !function_exists('renev_blog_start_wrap_cb') ) {
        function renev_blog_start_wrap_cb() {
            echo '<div class="vl-blog-1-area sp6">';
                echo '<div class="container">';
                    echo '<div class="row">';
        }
    }

    // Blog End Wrapper Function
    if( !function_exists('renev_blog_end_wrap_cb') ) {
        function renev_blog_end_wrap_cb() {
                    echo '</div>';
                echo '</div>';
            echo '</div>';
        }
    }

    // Blog Column Start Wrapper Function
    if( !function_exists('renev_blog_col_start_wrap_cb') ) {
        function renev_blog_col_start_wrap_cb() {
            if( class_exists('ReduxFramework') ) {
                $renev_blog_sidebar = renev_opt('renev_blog_sidebar');
                if( $renev_blog_sidebar == '2' && is_active_sidebar('renev-blog-sidebar') ) {
                    echo '<div class="col-lg-8 order-lg-last">';
                        echo '<div class="blog-others-sidebar">';
                } elseif( $renev_blog_sidebar == '3' && is_active_sidebar('renev-blog-sidebar') ) {
                    echo '<div class="col-lg-8">';
                        echo '<div class="blog-others-sidebar">';
                } else {
                    echo '<div class="col-lg-12">';
                }

            } else {
                if( is_active_sidebar('renev-blog-sidebar') ) {
                    echo '<div class="col-lg-8">';
                        echo '<div class="blog-others-sidebar">';
                } else {
                    echo '<div class="col-lg-12">';
                }
            }
        }
    }
    // Blog Column End Wrapper Function
    if( !function_exists('renev_blog_col_end_wrap_cb') ) {
        function renev_blog_col_end_wrap_cb() { 
            if( class_exists('ReduxFramework') ) {
                $renev_blog_sidebar = renev_opt('renev_blog_sidebar');
                if( $renev_blog_sidebar == '2' && is_active_sidebar('renev-blog-sidebar') ) {
                        echo '</div>';
                    echo '</div>';
                } elseif( $renev_blog_sidebar == '3' && is_active_sidebar('renev-blog-sidebar') ) {
                        echo '</div>';
                    echo '</div>';
                } else {
                    echo '</div>';
                }

            } else {
                if( is_active_sidebar('renev-blog-sidebar') ) {
                        echo '</div>';
                    echo '</div>';
                } else {
                     echo '</div>';
                }
            }
        }
    }


    // Blog Sidebar
    if( !function_exists('renev_blog_sidebar_cb') ) {
        function renev_blog_sidebar_cb( ) {
            if( class_exists('ReduxFramework') ) {
                $renev_blog_sidebar = renev_opt('renev_blog_sidebar');
            } else {
                $renev_blog_sidebar = 2;
            }
            if( $renev_blog_sidebar != 1 && is_active_sidebar('renev-blog-sidebar') ) {
                // Sidebar
                get_sidebar();
            }
        }
    }


    if( !function_exists('renev_blog_details_sidebar_cb') ) {
        function renev_blog_details_sidebar_cb( ) {
            if( class_exists('ReduxFramework') ) {
                $renev_blog_single_sidebar = renev_opt('renev_blog_single_sidebar');
            } else {
                $renev_blog_single_sidebar = 4;
            }
            if( $renev_blog_single_sidebar != 1 ) {
                // Sidebar
                get_sidebar();
            }

        }
    }

    // Blog Pagination Function
    if( !function_exists('renev_blog_pagination_cb') ) {
        function renev_blog_pagination_cb( ) {
            get_template_part('templates/pagination');
        }
    }

    // Blog Content Function
    if( !function_exists('renev_blog_content_cb') ) {
        function renev_blog_content_cb( ) {
            if( class_exists('ReduxFramework') ) {
                $renev_blog_grid = renev_opt('renev_blog_grid');
            } else {
                $renev_blog_grid = '1';
            }

            if( $renev_blog_grid == '1' ) {
                $renev_blog_grid_class = 'col-lg-12';
            } elseif( $renev_blog_grid == '2' ) {
                $renev_blog_grid_class = 'col-sm-6';
            } else {
                $renev_blog_grid_class = 'col-lg-4 col-sm-6';
            }

            echo '<div class="row">';
                if( have_posts() ) {
                    while( have_posts() ) {
                        the_post();
                        echo '<div class="'.esc_attr($renev_blog_grid_class).'">';
                            get_template_part('templates/content',get_post_format());
                        echo '</div>';
                    }
                    wp_reset_postdata();
                } else{
                    get_template_part('templates/content','none');
                }
            echo '</div>';
        }
    }

    // footer content Function
    if( !function_exists('renev_footer_content_cb') ) {
        function renev_footer_content_cb( ) {

            if( class_exists('ReduxFramework') && did_action( 'elementor/loaded' )  ){
                if( is_page() || is_page_template('template-builder.php') ) {
                    $post_id = get_the_ID();

                    // Get the page settings manager
                    $page_settings_manager = \Elementor\Core\Settings\Manager::get_settings_managers( 'page' );

                    // Get the settings model for current post
                    $page_settings_model = $page_settings_manager->get_model( $post_id );

                    // Retrieve the Footer Style
                    $footer_settings = $page_settings_model->get_settings( 'renev_footer_style' );

                    // Footer Local
                    $footer_local = $page_settings_model->get_settings( 'renev_footer_builder_option' );

                    // Footer Enable Disable
                    $footer_enable_disable = $page_settings_model->get_settings( 'renev_footer_choice' );

                    if( $footer_enable_disable == 'yes' ){
                        if( $footer_settings == 'footer_builder' ) {
                            // local options
                            $renev_local_footer = get_post( $footer_local );
                            echo '<footer>';
                            echo \Elementor\Plugin::instance()->frontend->get_builder_content_for_display( $renev_local_footer->ID );
                            echo '</footer>';
                        } else {
                            // global options
                            $renev_footer_builder_trigger = renev_opt('renev_footer_builder_trigger');
                            if( $renev_footer_builder_trigger == 'footer_builder' ) {
                                echo '<footer>';
                                $renev_global_footer_select = get_post( renev_opt( 'renev_footer_builder_select' ) );
                                $footer_post = get_post( $renev_global_footer_select );
                                echo \Elementor\Plugin::instance()->frontend->get_builder_content_for_display( $footer_post->ID );
                                echo '</footer>';
                            } else {
                                // wordpress widgets
                                renev_footer_global_option();
                            }
                        }
                    }
                } else {
                    // global options
                    $renev_footer_builder_trigger = renev_opt('renev_footer_builder_trigger');
                    if( $renev_footer_builder_trigger == 'footer_builder' ) {
                        echo '<footer>';
                        $renev_global_footer_select = get_post( renev_opt( 'renev_footer_builder_select' ) );
                        $footer_post = get_post( $renev_global_footer_select );
                        echo \Elementor\Plugin::instance()->frontend->get_builder_content_for_display( $footer_post->ID );
                        echo '</footer>';
                    } else {
                        // wordpress widgets
                        renev_footer_global_option();
                    }
                }
            } else {
                echo '<div class="footer-copyright text-center bg-black py-3 link-inherit z-index-common">';
                    echo '<div class="container">';
                        echo '<p class="mb-0 text-white">'.sprintf( 'Copyright <i class="fas fa-copyright"></i> %s <a href="%s">%s</a> All Rights Reserved by <a href="%s">%s</a>',date('Y'),esc_url('#'),__( 'Renev.','renev' ),esc_url('#'),__( 'Mthemeus', 'renev' ) ).'</p>';
                    echo '</div>';
                echo '</div>';
            }

        }
    }

    // blog details wrapper start hook function
    if( !function_exists('renev_blog_details_wrapper_start_cb') ) {
        function renev_blog_details_wrapper_start_cb( ) {
            if( class_exists('ReduxFramework') ) {       
                echo '<div class="blog-details-section-area live-blog-details-section sp6">';
            }else {
                echo '<div class="blog-details-section-area sp6">';
            }
                echo '<div class="container">';
                    echo '<div class="row">';
        }
    }

    // Blog details column start hook function
    if( !function_exists('renev_blog_details_col_start_cb') ) {
        function renev_blog_details_col_start_cb() {
            if( class_exists('ReduxFramework') ) {
                $renev_blog_single_sidebar = renev_opt('renev_blog_single_sidebar');
                if( $renev_blog_single_sidebar == '2' && is_active_sidebar('renev-blog-sidebar') ) {
                    echo '<div class="col-lg-8 order-last">';
                        echo '<div class="blog-others-sidebar">';
                } elseif( $renev_blog_single_sidebar == '3' && is_active_sidebar('renev-blog-sidebar') ) {
                    echo '<div class="col-lg-8">';
                        echo '<div class="blog-others-sidebar">'; // Open .blog__details-wrap
                } else {
                    echo '<div class="col-lg-12">';
                }
            } else {
                if( is_active_sidebar('renev-blog-sidebar') ) {
                    echo '<div class="col-lg-8">';
                        echo '<div class="blog-others-sidebar">'; // Open .blog__details-wrap
                } else {
                    echo '<div class="col-lg-12">';
                }
            }
        }
    }
    
     // blog post meta hook function
     if( !function_exists('renev_blog_post_meta_cb') ) {
        function renev_blog_post_meta_cb( ) {
            if( class_exists('ReduxFramework') ) {
                $renev_display_post_author    =  renev_opt('renev_display_post_author');
                $renev_display_post_date      =  renev_opt('renev_display_post_date');

            } else {
                $renev_display_post_author    = '1';
                $renev_display_post_date      = '1';
            }

            // Blog Meta
            echo '<div class="vl-blog-meta">';
                echo '<ul>';
                    if( $renev_display_post_date ) {
                        echo '<li>';
                            echo '<a href="' . get_day_link(get_the_date('Y'), get_the_date('m'), get_the_date('d')) . '">';
                                echo '<svg xmlns="http://www.w3.org/2000/svg" width="20" height="20" viewBox="0 0 20 20" fill="none"><g clip-path="url(#clip0_91_5623)"><path d="M5.673 0C5.85865 0 6.0367 0.0737498 6.16797 0.205025C6.29925 0.336301 6.373 0.514348 6.373 0.7V2.009H13.89V0.709C13.89 0.523348 13.9637 0.345301 14.095 0.214025C14.2263 0.0827498 14.4043 0.009 14.59 0.009C14.7757 0.009 14.9537 0.0827498 15.085 0.214025C15.2162 0.345301 15.29 0.523348 15.29 0.709V2.009H18C18.5303 2.009 19.0388 2.21958 19.4139 2.59443C19.7889 2.96929 19.9997 3.47774 20 4.008V18.001C19.9997 18.5313 19.7889 19.0397 19.4139 19.4146C19.0388 19.7894 18.5303 20 18 20H2C1.46974 20 0.961184 19.7894 0.58614 19.4146C0.211096 19.0397 0.00026513 18.5313 0 18.001L0 4.008C0.00026513 3.47774 0.211096 2.96929 0.58614 2.59443C0.961184 2.21958 1.46974 2.009 2 2.009H4.973V0.699C4.97327 0.513522 5.04713 0.335731 5.17838 0.204672C5.30963 0.0736123 5.48752 -1.89263e-07 5.673 0ZM1.4 7.742V18.001C1.4 18.0798 1.41552 18.1578 1.44567 18.2306C1.47583 18.3034 1.52002 18.3695 1.57574 18.4253C1.63145 18.481 1.69759 18.5252 1.77039 18.5553C1.84319 18.5855 1.92121 18.601 2 18.601H18C18.0788 18.601 18.1568 18.5855 18.2296 18.5553C18.3024 18.5252 18.3685 18.481 18.4243 18.4253C18.48 18.3695 18.5242 18.3034 18.5543 18.2306C18.5845 18.1578 18.6 18.0798 18.6 18.001V7.756L1.4 7.742ZM6.667 14.619V16.285H5V14.619H6.667ZM10.833 14.619V16.285H9.167V14.619H10.833ZM15 14.619V16.285H13.333V14.619H15ZM6.667 10.642V12.308H5V10.642H6.667ZM10.833 10.642V12.308H9.167V10.642H10.833ZM15 10.642V12.308H13.333V10.642H15ZM4.973 3.408H2C1.92121 3.408 1.84319 3.42352 1.77039 3.45367C1.69759 3.48382 1.63145 3.52802 1.57574 3.58374C1.52002 3.63945 1.47583 3.70559 1.44567 3.77839C1.41552 3.85119 1.4 3.92921 1.4 4.008V6.343L18.6 6.357V4.008C18.6 3.92921 18.5845 3.85119 18.5543 3.77839C18.5242 3.70559 18.48 3.63945 18.4243 3.58374C18.3685 3.52802 18.3024 3.48382 18.2296 3.45367C18.1568 3.42352 18.0788 3.408 18 3.408H15.29V4.337C15.29 4.52265 15.2162 4.7007 15.085 4.83197C14.9537 4.96325 14.7757 5.037 14.59 5.037C14.4043 5.037 14.2263 4.96325 14.095 4.83197C13.9637 4.7007 13.89 4.52265 13.89 4.337V3.408H6.373V4.328C6.373 4.51365 6.29925 4.6917 6.16797 4.82297C6.0367 4.95425 5.85865 5.028 5.673 5.028C5.48735 5.028 5.3093 4.95425 5.17803 4.82297C5.04675 4.6917 4.973 4.51365 4.973 4.328V3.408Z" fill="white"></path></g><defs><clipPath id="clip0_91_5623"><rect width="20" height="20" fill="white"></rect></clipPath></defs></svg>';
                                echo get_the_date('j F Y');
                            echo '</a>';
                        echo '</li>';
                    }
                    if( has_post_thumbnail(  ) ){
                        if( $renev_display_post_author ){
                            echo '<li>';
                                echo '<a href="' . esc_url( get_author_posts_url( get_the_author_meta('ID') ) ) . '">';
                                    echo '<svg xmlns="http://www.w3.org/2000/svg" width="22" height="22" viewBox="0 0 22 22" fill="none"><path d="M17.4163 19.25V17.4167C17.4163 16.4442 17.03 15.5116 16.3424 14.8239C15.6548 14.1363 14.7221 13.75 13.7497 13.75H8.24967C7.27721 13.75 6.34458 14.1363 5.65695 14.8239C4.96932 15.5116 4.58301 16.4442 4.58301 17.4167V19.25" stroke="#03060A" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"></path><path d="M10.9997 10.0833C13.0247 10.0833 14.6663 8.44171 14.6663 6.41667C14.6663 4.39162 13.0247 2.75 10.9997 2.75C8.97463 2.75 7.33301 4.39162 7.33301 6.41667C7.33301 8.44171 8.97463 10.0833 10.9997 10.0833Z" stroke="#03060A" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"></path></svg>';
                                    echo '' . esc_html( ucwords( get_the_author() ) );
                                echo '</a>';
                            echo '</li>';
                        }
                    }               
                echo '</ul>';
            echo '</div>';

        }
    }

    // blog post Details meta hook function
    if( !function_exists('renev_blog_details_post_meta_cb') ) {
        function renev_blog_details_post_meta_cb() {
            if( class_exists('ReduxFramework') ) {
                $renev_display_post_author   = renev_opt('renev_display_post_author');
                $renev_display_post_tag = renev_opt('renev_display_post_tag');
                $renev_display_post_date     = renev_opt('renev_display_post_date'); // Added missing variable
            } else {
                $renev_display_post_author   = '1';
                $renev_display_post_tag = '1';
                $renev_display_post_date     = '1'; // Added missing variable
            }
    
            echo '<ul class="list-author">';
            // Tag Meta
            if( $renev_display_post_tag ) {
                $tags = get_the_tags();
                if (!empty($tags)) {
                    $tag_link = get_tag_link($tags[0]->term_id);
                    echo '<li class="tag">';
                        echo '<a href="' . esc_url($tag_link) . '">';
                            echo esc_html($tags[0]->name);
                        echo '</a>';
                    echo '</li>';
                }
            }
            // Post Date Meta
            if( $renev_display_post_date ) {
                $date = get_the_date(); // Get formatted date
                echo '<li>';
                    echo '<a href="' . esc_url( get_permalink() ) . '">';
                        echo '<svg xmlns="http://www.w3.org/2000/svg" width="20" height="20" viewBox="0 0 20 20" fill="none"><g clip-path="url(#clip0_91_5623)"><path d="M5.673 0C5.85865 0 6.0367 0.0737498 6.16797 0.205025C6.29925 0.336301 6.373 0.514348 6.373 0.7V2.009H13.89V0.709C13.89 0.523348 13.9637 0.345301 14.095 0.214025C14.2263 0.0827498 14.4043 0.009 14.59 0.009C14.7757 0.009 14.9537 0.0827498 15.085 0.214025C15.2162 0.345301 15.29 0.523348 15.29 0.709V2.009H18C18.5303 2.009 19.0388 2.21958 19.4139 2.59443C19.7889 2.96929 19.9997 3.47774 20 4.008V18.001C19.9997 18.5313 19.7889 19.0397 19.4139 19.4146C19.0388 19.7894 18.5303 20 18 20H2C1.46974 20 0.961184 19.7894 0.58614 19.4146C0.211096 19.0397 0.00026513 18.5313 0 18.001L0 4.008C0.00026513 3.47774 0.211096 2.96929 0.58614 2.59443C0.961184 2.21958 1.46974 2.009 2 2.009H4.973V0.699C4.97327 0.513522 5.04713 0.335731 5.17838 0.204672C5.30963 0.0736123 5.48752 -1.89263e-07 5.673 0ZM1.4 7.742V18.001C1.4 18.0798 1.41552 18.1578 1.44567 18.2306C1.47583 18.3034 1.52002 18.3695 1.57574 18.4253C1.63145 18.481 1.69759 18.5252 1.77039 18.5553C1.84319 18.5855 1.92121 18.601 2 18.601H18C18.0788 18.601 18.1568 18.5855 18.2296 18.5553C18.3024 18.5252 18.3685 18.481 18.4243 18.4253C18.48 18.3695 18.5242 18.3034 18.5543 18.2306C18.5845 18.1578 18.6 18.0798 18.6 18.001V7.756L1.4 7.742ZM6.667 14.619V16.285H5V14.619H6.667ZM10.833 14.619V16.285H9.167V14.619H10.833ZM15 14.619V16.285H13.333V14.619H15ZM6.667 10.642V12.308H5V10.642H6.667ZM10.833 10.642V12.308H9.167V10.642H10.833ZM15 10.642V12.308H13.333V10.642H15ZM4.973 3.408H2C1.92121 3.408 1.84319 3.42352 1.77039 3.45367C1.69759 3.48382 1.63145 3.52802 1.57574 3.58374C1.52002 3.63945 1.47583 3.70559 1.44567 3.77839C1.41552 3.85119 1.4 3.92921 1.4 4.008V6.343L18.6 6.357V4.008C18.6 3.92921 18.5845 3.85119 18.5543 3.77839C18.5242 3.70559 18.48 3.63945 18.4243 3.58374C18.3685 3.52802 18.3024 3.48382 18.2296 3.45367C18.1568 3.42352 18.0788 3.408 18 3.408H15.29V4.337C15.29 4.52265 15.2162 4.7007 15.085 4.83197C14.9537 4.96325 14.7757 5.037 14.59 5.037C14.4043 5.037 14.2263 4.96325 14.095 4.83197C13.9637 4.7007 13.89 4.52265 13.89 4.337V3.408H6.373V4.328C6.373 4.51365 6.29925 4.6917 6.16797 4.82297C6.0367 4.95425 5.85865 5.028 5.673 5.028C5.48735 5.028 5.3093 4.95425 5.17803 4.82297C5.04675 4.6917 4.973 4.51365 4.973 4.328V3.408Z" fill="white"></path></g><defs><clipPath id="clip0_91_5623"><rect width="20" height="20" fill="white"></rect></clipPath></defs></svg>';
                        echo get_the_date('j F Y');
                        echo ' <span> | </span>'; // Separator
                    echo '</a>';
                echo '</li>';
            }
            // Author Meta
            if( $renev_display_post_author ) {
                echo '<li>';
                    echo '<a href="' . esc_url( get_author_posts_url( get_the_author_meta('ID') ) ) . '">';
                        echo '<svg xmlns="http://www.w3.org/2000/svg" width="22" height="22" viewBox="0 0 22 22" fill="none"><path d="M17.4163 19.25V17.4167C17.4163 16.4442 17.03 15.5116 16.3424 14.8239C15.6548 14.1363 14.7221 13.75 13.7497 13.75H8.24967C7.27721 13.75 6.34458 14.1363 5.65695 14.8239C4.96932 15.5116 4.58301 16.4442 4.58301 17.4167V19.25" stroke="#03060A" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"></path><path d="M10.9997 10.0833C13.0247 10.0833 14.6663 8.44171 14.6663 6.41667C14.6663 4.39162 13.0247 2.75 10.9997 2.75C8.97463 2.75 7.33301 4.39162 7.33301 6.41667C7.33301 8.44171 8.97463 10.0833 10.9997 10.0833Z" stroke="#03060A" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"></path></svg>';
                        echo esc_html( ucwords( get_the_author() ) );
                    echo '</a>';
                echo '</li>';
            }
            echo '</ul>';
        }
    }
    

    // blog details share options hook function
    if( !function_exists('renev_blog_details_share_options_cb') ) {
        function renev_blog_details_share_options_cb( ) {
            if( class_exists('ReduxFramework') ) {
                $renev_post_details_share_options = renev_opt('renev_post_details_share_options');
            } else {
                $renev_post_details_share_options = false;
            }
            if( function_exists( 'renev_social_sharing_buttons' ) && $renev_post_details_share_options ) {
                echo '<div class="social">';
                    echo '<ul>';
                        echo '<li>'.esc_html__( 'Social:', 'renev' ).'</li>';
                        echo renev_social_sharing_buttons();
                    echo '</ul>';
                echo '</div>';
            }
        }
    }

    // blog details post navigation hook function
    if( !function_exists('renev_blog_details_post_navigation_cb') ) {
        function renev_blog_details_post_navigation_cb( ) {
            if( class_exists('ReduxFramework') ) {
                $renev_post_details_post_navigation = renev_opt('renev_post_details_post_navigation');
            } else {
                $renev_post_details_post_navigation = true;
            }

            $prevpost = get_previous_post();
            $nextpost = get_next_post();

            if( $renev_post_details_post_navigation && ! empty( $prevpost ) || !empty( $nextpost ) ) {
                echo '<!-- Post Navigation -->';
                echo '<div class="post-pagination">';
                    echo '<div class="row justify-content-between align-items-center">';
                        echo '<div class="col-6">';
                        if( ! empty( $prevpost ) ) {
                            echo '<!-- Nav Previous -->';
                            
                            echo '<div class="post-pagi-box prev">';
                                echo '<a href="'.esc_url( get_permalink( $prevpost->ID ) ).'">';
                                    echo  '<i class="fas fa-angle-double-left"></i>';
                                    echo esc_html__( 'Previous Post', 'renev' );
                                echo '</a>';
                            echo '</div>';
                        }
                        echo '</div>';
                        echo '<!-- End Nav Previous -->';
                        
                        echo '<div class="col-6">';
                        if( !empty( $nextpost ) ) {
                                echo '<div class="post-pagi-box next">';
                                    echo '<a href="'.esc_url( get_permalink( $nextpost->ID ) ).'">';
                                        echo  '<i class="fas fa-angle-double-right"></i>';
                                        echo esc_html__( 'Next Post', 'renev' );
                                    echo '</a>';
                                echo '</div>';
                            }
                        echo '</div>';
                    echo '</div>';
                echo '</div>';
                echo '<!-- End Post Navigation -->';
            }
        }
    }
    // blog details author bio hook function
    if( !function_exists('renev_blog_details_author_bio_cb') ) {
        function renev_blog_details_author_bio_cb( ) {
            if( class_exists('ReduxFramework') ) {
                $postauthorbox =  renev_opt( 'renev_post_details_author_desc_trigger' );
            } else {
                $postauthorbox = '1';
            }
            if( !empty( get_the_author_meta('description')  ) && $postauthorbox == '1' ) {
                echo '<!-- Post Author -->';
                echo '<div class="blog-author">';
                    echo '<!-- Author Thumb -->';
                    echo '<div class="media-img">';
                        echo renev_img_tag( array(
                            "url"   => esc_url( get_avatar_url( get_the_author_meta('ID'), array(
                            "size"  => 189
                            ) ) ),
                        ) );
                    echo '</div>';
                    echo '<!-- End of Author Thumb -->';
                    echo '<div class="media-body">';
                        echo renev_heading_tag( array(
                            "tag"   => "h3",
                            "text"  => renev_anchor_tag( array(
                                "text"  => esc_html( ucwords( get_the_author() ) ),
                                "url"   => esc_url( get_author_posts_url( get_the_author_meta('ID') ) ),
                                'class' => 'text-inherit',
                            ) ),
                            'class' => 'author-name h4',
                        ) );
                        
                        if( ! empty( get_the_author_meta('description') ) ) {
                            echo '<p class="author-text">';
                                echo esc_html( get_the_author_meta('description') );
                            echo '</p>';
                        };
                        if( function_exists( 'renev_social_icon' ) ){
                            renev_social_icon();
                        }
                    echo '</div>';
                echo '</div>';
                echo '<!-- End of Post Author -->';
            }

        }
    }

    // Blog Details Comments hook function
    if( !function_exists('renev_blog_details_comments_cb') ) {
        function renev_blog_details_comments_cb( ) {
            if ( ! comments_open() ) {
                echo '<div class="blog-comment-area">';
                    echo renev_heading_tag( array(
                        "tag"   => "h3",
                        "text"  => esc_html__( 'Comments are closed', 'renev' ),
                        "class" => "inner-title"
                    ) );
                echo '</div>';
            }

            // comment template.
            if ( comments_open() || get_comments_number() ) {
                comments_template();
            }
        }
    }

    // Blog Details Related Post hook function
    if( !function_exists('renev_blog_details_related_post_cb') ) {
        function renev_blog_details_related_post_cb( ) {
            if( class_exists('ReduxFramework') ) {
                $renev_post_details_related_post = renev_opt('renev_post_details_related_post');
            } else {
                $renev_post_details_related_post = false;
            }
            $relatedpost = new WP_Query( array(
                "post_type"         => "post",
                "posts_per_page"    => "3",
                "post__not_in"      =>  array( get_the_ID() )
            ) );
            if( $relatedpost->have_posts() && $renev_post_details_related_post ) {
                echo '<!-- Related Post -->';
                echo '<div class="vl-blog-1-area related-post">';
                    echo '<div class="container">';
                        echo '<div class="row">';
                            echo '<div class="col-lg-7 m-auto">';
                                echo '<div class="vl-blog-1-section-box heading1 text-center space-margin60">';
                                    echo '<h2>'.esc_html__( 'read more latest blog', 'renev' ).'</h2>';
                                echo '</div>';
                            echo '</div>';
                        echo '</div>';

                        echo '<div class="row">';
                            while( $relatedpost->have_posts() ) {
                                $relatedpost->the_post();
                                echo '<div class="col-lg-4 col-md-6">';
                                    echo '<!-- Single Post -->';
                                    echo '<div class="vl-blog-1-item">';
                                        echo '<div class="vl-blog-1-thumb image-anime">';
                                            if( has_post_thumbnail(  ) ){
                                                the_post_thumbnail( 'renev-related-post-size', [ 'class'  => 'w-100' ] );
                                            }
                                        echo '</div>';
                                        echo '<div class="vl-blog-1-content">';

                                            // Blog Post Meta
                                            do_action( 'renev_blog_post_meta');

                                            // Post Title
                                            echo '<div class="space14">';
                                            echo '</div>';
                                            echo '<h4 class="vl-blog-1-title"><a href="' . esc_url( get_permalink() ) . '">' . wp_kses_post( get_the_title() ) . '</a></h4>';
                                        

                                            echo '<div class="space20">';
                                            echo '</div>';
                                            echo '<div class="vl-blog-1-icon">';                               
                                                echo '<a href="' . esc_url( get_permalink() ) . '">';
                                                    echo esc_html__( 'LEARN MORE', 'renev' ); 
                                                    echo ' <i class="fas fa-arrow-right"></i>'; 
                                                echo '</a>';
                                            echo '</div>';

                                        echo '</div>';
                                    echo '</div>';
                                    echo '<!-- End Single Post -->';
                                echo '</div>';
                            }
                            wp_reset_postdata();
                        echo '</div>';
                    echo '</div>';
                echo '</div>';
                echo '<!-- End Related Post -->';
            }
        }
    }

    // Blog details column end hook function
    if( !function_exists('renev_blog_details_col_end_cb') ) {
        function renev_blog_details_col_end_cb() {
            if( class_exists('ReduxFramework') ) {
                $renev_blog_single_sidebar = renev_opt('renev_blog_single_sidebar');
                if( $renev_blog_single_sidebar == '2' && is_active_sidebar('renev-blog-sidebar') ) {
                    echo '</div>';
                        echo '</div>';
                } elseif( $renev_blog_single_sidebar == '3' && is_active_sidebar('renev-blog-sidebar') ) {
                    echo '</div>';
                        echo '</div>';
                } else {
                    echo '</div>';
                }
            } else {
                if( is_active_sidebar('renev-blog-sidebar') ) {
                    echo '</div>';
                        echo '</div>';
                } else {
                    echo '</div>';
                }
            }
        }
    }

    // Blog Details Wrapper end hook function
    if( !function_exists('renev_blog_details_wrapper_end_cb') ) {
        function renev_blog_details_wrapper_end_cb( ) {
                    echo '</div>';
                echo '</div>';
            echo '</div>';
        }
    }

    // page start wrapper hook function
    if( !function_exists('renev_page_start_wrap_cb') ) {
        function renev_page_start_wrap_cb( ) {
            if( is_page( 'cart' ) ){
                $section_class = "fav-cart-wrapper space-top black2-bg page__content";
            }elseif( is_page( 'checkout' ) ){
                $section_class = "fav-checkout-wrapper space-top black2-bg page__content";
            }else{
                $section_class = "space-top black2-bg page__content";
            }
            echo '<section class="'.esc_attr( $section_class ).'">';
                echo '<div class="content-block">';
                    echo '<div class="container">';
                        echo '<div class="row">';
        }
    }

    // page wrapper end hook function
    if( !function_exists('renev_page_end_wrap_cb') ) {
        function renev_page_end_wrap_cb( ) {
                        echo '</div>';
                    echo '</div>';
                echo '</div>';
            echo '</section>';
        }
    }

    // page column wrapper start hook function
    if( !function_exists('renev_page_col_start_wrap_cb') ) {
        function renev_page_col_start_wrap_cb( ) {
            if( class_exists('ReduxFramework') ) {
                $renev_page_sidebar = renev_opt('renev_page_sidebar');
            }else {
                $renev_page_sidebar = '1';
            }
            if( $renev_page_sidebar == '2' && is_active_sidebar('renev-page-sidebar') ) {
                echo '<div class="col-lg-8 order-last">';
            } elseif( $renev_page_sidebar == '3' && is_active_sidebar('renev-page-sidebar') ) {
                echo '<div class="col-lg-8">';
            } else {
                echo '<div class="col-lg-12">';
            }

        }
    }

    // page column wrapper end hook function
    if( !function_exists('renev_page_col_end_wrap_cb') ) {
        function renev_page_col_end_wrap_cb( ) {
            echo '</div>';
        }
    }

    // page sidebar hook function
    if( !function_exists('renev_page_sidebar_cb') ) {
        function renev_page_sidebar_cb( ) {
            if( class_exists('ReduxFramework') ) {
                $renev_page_sidebar = renev_opt('renev_page_sidebar');
            }else {
                $renev_page_sidebar = '1';
            }

            if( class_exists('ReduxFramework') ) {
                $renev_page_layoutopt = renev_opt('renev_page_layoutopt');
            }else {
                $renev_page_layoutopt = '3';
            }

            if( $renev_page_layoutopt == '1' && $renev_page_sidebar != 1 ) {
                get_sidebar('page');
            } elseif( $renev_page_layoutopt == '2' && $renev_page_sidebar != 1 ) {
                get_sidebar();
            }
        }
    }

    // page content hook function
    if( !function_exists('renev_page_content_cb') ) {
        function renev_page_content_cb( ) {
            echo '<div class="page--content clearfix">';
            
            the_content();
                // Link Pages
                renev_link_pages();

            echo '</div>';
            // comment template.
            if ( comments_open() || get_comments_number() ) {
                comments_template();
            }

        }
    }


    // Blog Post Thumb hook function start
    if( !function_exists('renev_blog_post_thumb_cb') ) {
        function renev_blog_post_thumb_cb( ) {
            if( get_post_format() ) {
                $format = get_post_format();
            }else{
                $format = 'standard';
            }

            $renev_post_slider_thumbnail = renev_meta( 'post_format_slider' );

            if( !empty( $renev_post_slider_thumbnail ) ){
                    echo '<div class="vl-blog-1-thumb image-anime fav-carousel" data-arrows="true" data-slide-show="1" data-fade="true">';
                        echo '<div class="td-postbox-slider swiper-container p-relative">';
                            echo '<div class="swiper-wrapper">';
                                foreach( $renev_post_slider_thumbnail as $single_image ){
                                    echo '<div class="td-postbox-slider-item swiper-slide">';
                                        echo '<a href="'.esc_url( get_permalink() ).'">';
                                            echo renev_img_tag( array(
                                                'url'   => esc_url( $single_image )
                                            ) );
                                        echo '</a>';                                     
                                    echo '</div>';
                                }
                            echo '</div>';
                            echo '<div class="td-postbox-nav">';
                                echo '<button class="td-postbox-slider-button-next"><i class="fa-regular fa-angle-right"></i></button>';
                                echo '<button class="td-postbox-slider-button-prev"><i class="fa-regular fa-angle-left"></i></button>';
                            echo '</div>';
                        echo '</div>';

                    echo '</div>';
            }elseif( has_post_thumbnail() && $format == 'standard' ) {
                echo '<!-- Post Thumbnail -->';
                echo '<div class="vl-blog-1-thumb image-anime">';
                        the_post_thumbnail();
                echo '</div>';
                echo '<!-- End Post Thumbnail -->';
            }elseif( has_post_thumbnail() && $format == 'image' ) {
                echo '<!-- Post Thumbnail -->';
                echo '<div class="vl-blog-1-thumb image-anime">';
                        the_post_thumbnail();
                echo '</div>';
                echo '<!-- End Post Thumbnail -->';
            }elseif( has_post_thumbnail() && $format == 'video' ){
                if( !empty( renev_meta( 'post_format_video' ) ) ){
                    echo '<div class="blog-video vl-blog-1-thumb image-anime">';
                        echo '<a href="'.esc_url( get_permalink() ).'">';
                            the_post_thumbnail();
                        echo '</a>';
                        echo '<div class="td-video-7-popup">';
                            echo '<a href="'.esc_url( renev_meta( 'post_format_video' ) ).'" class="td-video-play td-video-5-play popup-video td-pulse-border">';
                                echo '<span class="p-relative z-index-11">';
                                    echo    '<svg width="14" height="20" viewBox="0 0 14 20" fill="none" xmlns="http://www.w3.org/2000/svg">
                                                <path d="M14 10L0 20V0L14 10Z" fill="currentColor" />
                                            </svg>';
                                echo '</span>';
                            echo '</a>';
                        echo '</div>';
                       
                    echo '</div>';
                }elseif( ! has_post_thumbnail() && ! is_single() ){
                    echo '<div class="blog-video vl-blog-1-thumb image-anime">';
                            the_post_thumbnail();
                    echo '</div>';
                }
            }elseif( $format == 'audio' ){
                $renev_audio = renev_meta( 'post_format_audio' );
                if( !empty( $renev_audio ) ){
                    echo '<div class="blog-audio vl-blog-1-thumb image-anime">';
                            echo wp_oembed_get( $renev_audio );
                    echo '</div>';
                }elseif( !is_single() ){
                    echo '<div class="blog-audio vl-blog-1-thumb image-anime">';
                            echo renev_embedded_media( array( 'audio', 'iframe' ) );
                    echo '</div>';
                }
            }

        }
    }
    // Blog Post Thumb hook function end

    // Blog Post Details Thumb hook function start
    if( !function_exists('renev_blog_post_details_thumb_cb') ) {
        function renev_blog_post_details_thumb_cb( ) {
            if( get_post_format() ) {
                $format = get_post_format();
            }else{
                $format = 'standard';
            }

            $renev_post_slider_thumbnail = renev_meta( 'post_format_slider' );

            if( !empty( $renev_post_slider_thumbnail ) ){
                    echo '<div class="img1 fav-carousel" data-arrows="true" data-slide-show="1" data-fade="true">';
                        echo '<div class="td-postbox-slider swiper-container p-relative">';
                            echo '<div class="swiper-wrapper">';
                                foreach( $renev_post_slider_thumbnail as $single_image ){
                                    echo '<div class="td-postbox-slider-item swiper-slide">';
                                            echo renev_img_tag( array(
                                                'url'   => esc_url( $single_image )
                                            ) );
                                    echo '</div>';
                                }
                            echo '</div>';
                            echo '<div class="td-postbox-nav">';
                                echo '<button class="td-postbox-slider-button-next"><i class="fa-regular fa-angle-right"></i></button>';
                                echo '<button class="td-postbox-slider-button-prev"><i class="fa-regular fa-angle-left"></i></button>';
                            echo '</div>';
                        echo '</div>';
                    echo '</div>';
            }elseif( has_post_thumbnail() && $format == 'standard' ) {
                echo '<!-- Post Thumbnail -->';
                    echo '<div class="img1">';
                            the_post_thumbnail();
                    echo '</div>';
                    echo '<div class="space32">';
               echo ' </div>';

                echo '<!-- End Post Thumbnail -->';
            }elseif( $format == 'video' ){
                if( has_post_thumbnail() && !empty ( renev_meta( 'post_format_video' ) ) ){
                    echo '<div class="blog-video img1">';
                            the_post_thumbnail();
                        echo '<div class="td-video-7-popup">';
                            echo '<a href="'.esc_url( renev_meta( 'post_format_video' ) ).'" class="td-video-play td-video-5-play popup-video td-pulse-border">';
                                echo '<span class="p-relative z-index-11">';
                                    echo    '<svg width="14" height="20" viewBox="0 0 14 20" fill="none" xmlns="http://www.w3.org/2000/svg">
                                                <path d="M14 10L0 20V0L14 10Z" fill="currentColor" />
                                            </svg>';
                                echo '</span>';
                            echo '</a>';
                        echo '</div>';
                    echo '</div>';
                }elseif( ! has_post_thumbnail() && ! is_single() ){
                    echo '<div class="blog-video img1">';
                            the_post_thumbnail();
                        echo '<div class="td-video-7-popup">';
                            echo '<a href="'.esc_url( renev_meta( 'post_format_video' ) ).'" class="td-video-play td-video-5-play popup-video td-pulse-border">';
                                echo '<span class="p-relative z-index-11">';
                                    echo    '<svg width="14" height="20" viewBox="0 0 14 20" fill="none" xmlns="http://www.w3.org/2000/svg">
                                                <path d="M14 10L0 20V0L14 10Z" fill="currentColor" />
                                            </svg>';
                                echo '</span>';
                            echo '</a>';
                        echo '</div>';
                    echo '</div>';
                }
            }elseif( $format == 'audio' ){
                $renev_audio = renev_meta( 'post_format_audio' );
                if( !empty( $renev_audio ) ){
                    echo '<div class="blog-audio img1">';
                            echo wp_oembed_get( $renev_audio );
                    echo '</div>';
                }elseif( !is_single() ){
                    echo '<div class="blog-audio img1">';
                            echo renev_embedded_media( array( 'audio', 'iframe' ) );
                    echo '</div>';
                }
            }

        }
    }
    // Blog Post Details Thumb hook function end


    if( !function_exists( 'renev_blog_post_content_cb' ) ) {
        function renev_blog_post_content_cb( ) {
            $allowhtml = array(
                'p'         => array(
                    'class'     => array()
                ),
                'span'      => array(),
                'a'         => array(
                    'href'      => array(),
                    'title'     => array()
                ),
                'br'        => array(),
                'em'        => array(),
                'strong'    => array(),
                'b'         => array(),
                'sup'       => array(),
                'sub'       => array(),
            );
            echo '<!-- blog-content -->';

            echo '<div class="vl-blog-1-content">';

                // Blog Post Meta
                do_action( 'renev_blog_post_meta');

                if( ! is_single() ){
                    // Post Title
                    echo '<div class="space14">';
                    echo '</div>';
                    echo '<h4 class="vl-blog-1-title"><a style="text-transform: uppercase;" href="'.esc_url( get_permalink() ).'">'.wp_kses( get_the_title(), $allowhtml ).'</a></h4>';
                }

                echo '<div class="space20">';
                echo '</div>';
                echo '<div class="vl-blog-1-icon">';                               
                    echo '<a href="' . esc_url( get_permalink() ) . '">';
                        echo esc_html__( 'LEARN MORE', 'renev' ); 
                        echo ' <i class="fas fa-arrow-right"></i>'; 
                    echo '</a>';
                echo '</div>';
            echo '</div>';
            echo '<!-- End Post Content -->';
        }
    }

    if( ! function_exists( 'renev_blog_postexcerpt_read_content_cb') ) {
        function renev_blog_postexcerpt_read_content_cb( ) {
            if( class_exists( 'ReduxFramework' ) ) {
                $renev_excerpt_length = renev_opt('renev_blog_postExcerpt');
            } else {
                $renev_excerpt_length = '24';
            }
            $allowhtml = array(
                'p'         => array(
                    'class'     => array()
                ),
                'span'      => array(),
                'a'         => array(
                    'href'      => array(),
                    'title'     => array()
                ),
                'br'        => array(),
                'em'        => array(),
                'strong'    => array(),
                'b'         => array(),
            );

            echo '<!-- Post Summary -->';
            echo '<div class="renev_blog_post_excerpt"><p class="text-white">' . 
                wp_kses( wp_trim_words( get_the_excerpt(), $renev_excerpt_length, '' ), $allowhtml ) . 
                '</p></div>';                     
            echo '<!-- End Post Summary -->';
        }
    }