(function ($) {

    "use strict";


    /*---------- Global Js ----------*/
    var Global_Js = function ($scope) {

    }


    // Mobile Menu
    var mobile_menu_Js = function ($scope) {
        var vlMenuWrap = $('.vl-mobile-menu-active > ul').clone();
        var vlSideMenu = $('.vl-offcanvas-menu nav');
        vlSideMenu.append(vlMenuWrap);
        if ($(vlSideMenu).find('.sub-menu, .vl-mega-menu').length != 0) {
          $(vlSideMenu).find('.sub-menu, .vl-mega-menu').parent().append('<button class="vl-menu-close"><i class="fas fa-chevron-right"></i></button>');
        }
      
        var sideMenuList = $('.vl-offcanvas-menu nav > ul > li button.vl-menu-close, .vl-offcanvas-menu nav > ul li.has-dropdown > a');
        $(sideMenuList).on('click', function (e) {
          console.log(e);
          e.preventDefault();
          if (!($(this).parent().hasClass('active'))) {
            $(this).parent().addClass('active');
            $(this).siblings('.sub-menu, .vl-mega-menu').slideDown();
          } else {
            $(this).siblings('.sub-menu, .vl-mega-menu').slideUp();
            $(this).parent().removeClass('active');
          }
        });
      
      
      $(".vl-offcanvas-toggle").on('click',function(){
        $(".vl-offcanvas").addClass("vl-offcanvas-open");
        $(".vl-offcanvas-overlay").addClass("vl-offcanvas-overlay-open");
      });
      
      $(".vl-offcanvas-close-toggle,.vl-offcanvas-overlay").on('click', function(){
        $(".vl-offcanvas").removeClass("vl-offcanvas-open");
        $(".vl-offcanvas-overlay").removeClass("vl-offcanvas-overlay-open");
      });        
    }
    //========== MOBILE MENU ENDS ============= //

    // Search Js
    var Search_Js = function ($scope) {
      $(".header-search-btn").on("click", function (e) {
        e.preventDefault();
        $(".header-search-form-wrapper").addClass("open");
        $('.header-search-form-wrapper input[type="search"]').focus();
        $('.body-overlay').addClass('active');
      });
    
      $(".tx-search-close").on("click", function (e) {
        e.preventDefault();
        $(".header-search-form-wrapper").removeClass("open");
        $("body").removeClass("active");
        $('.body-overlay').removeClass('active');
      });
    
      // Close search and mobile menu on overlay click
      $(".body-overlay").on("click", function () {
        $(".header-search-form-wrapper").removeClass("open");
        $(".slide-bar").removeClass("show");
        $("body").removeClass("on-side");
        $(this).removeClass("active");
        $(".hamburger_menu").removeClass("active");
      });
    
      $('#mobile-menu-active').metisMenu();
      $('#mobile-menu-active .dropdown > a').on('click', function (e) {
        e.preventDefault();
      });
    
      $(".hamburger_menu").on("click", function (e) {
        e.preventDefault();
        $(".slide-bar").toggleClass("show");
        $("body").addClass("on-side");
        $('.body-overlay').addClass('active');
        $(this).addClass('active');
      });
    
      $(".close-mobile-menu > a").on("click", function (e) {
        e.preventDefault();
        $(".slide-bar").removeClass("show");
        $("body").removeClass("on-side");
        $('.body-overlay').removeClass('active');
        $('.hamburger_menu').removeClass('active');
      });
    }
        
    // Offcanvas Js
    var Offcanvas_Js = function ($scope) {
      $(".body-overlay").on("click", function () {
        $(".slide-bar").removeClass("show");
        $("body").removeClass("on-side");
        $(this).removeClass("active");
        $(".hamburger_menu").removeClass("active");
      });
    }

    //image Js
    var Image_Js = function ($scope) {
        if ($('.text-anime-style-1').length) {
            let staggerAmount 	= 0.05,
            translateXValue = 0,
            delayValue 		= 0.5,
             animatedTextElements = document.querySelectorAll('.text-anime-style-1');
          
            animatedTextElements.forEach((element) => {
            let animationSplitText = new SplitText(element, { type: "chars, words" });
              gsap.from(animationSplitText.words, {
              duration: 1,
              delay: delayValue,
              x: 20,
              autoAlpha: 0,
              stagger: staggerAmount,
              scrollTrigger: { trigger: element, start: "top 85%" },
              });
            });
            }
          
            if ($('.text-anime-style-2').length) {
            let	 staggerAmount 		= 0.05,
             translateXValue	= 20,
             delayValue 		= 0.5,
             easeType 			= "power2.out",
             animatedTextElements = document.querySelectorAll('.text-anime-style-2');
          
            animatedTextElements.forEach((element) => {
            let animationSplitText = new SplitText(element, { type: "chars, words" });
              gsap.from(animationSplitText.chars, {
                duration: 1,
                delay: delayValue,
                x: translateXValue,
                autoAlpha: 0,
                stagger: staggerAmount,
                ease: easeType,
                scrollTrigger: { trigger: element, start: "top 85%"},
              });
            });
            }
          
            if ($('.text-anime-style-3').length) {
            let	animatedTextElements = document.querySelectorAll('.text-anime-style-3');
          
            animatedTextElements.forEach((element) => {
            //Reset if needed
            if (element.animation) {
              element.animation.progress(1).kill();
              element.split.revert();
            }
          
            element.split = new SplitText(element, {
              type: "lines,words,chars",
              linesClass: "split-line",
            });
            gsap.set(element, { perspective: 400 });
          
            gsap.set(element.split.chars, {
              opacity: 0,
              x: "50",
            });
          
            element.animation = gsap.to(element.split.chars, {
              scrollTrigger: { trigger: element,	start: "top 90%" },
              x: "0",
              y: "0",
              rotateX: "0",
              opacity: 1,
              duration: 1,
              ease: Back.easeOut,
              stagger: 0.02,
            });
            });
            }
          
        if ($scope.find('.reveal').length) {
            gsap.registerPlugin(ScrollTrigger);
    
            $scope.find('.reveal').each(function () {
                const container = this;
                const image = container.querySelector('img');
    
                gsap.set(container, { autoAlpha: 0 });
                gsap.set(image, { xPercent: 0, scale: 1 });
    
                const tl = gsap.timeline({
                    scrollTrigger: {
                        trigger: container,
                        toggleActions: "play none none none",
                        once: true
                    }
                });
    
                tl.set(container, { autoAlpha: 1 });
                tl.from(container, {
                    duration: 1.5,
                    xPercent: -100,
                    ease: Power2.out
                });
                tl.from(image, {
                    duration: 1.5,
                    xPercent: 100,
                    scale: 1.3,
                    ease: Power2.out
                }, "<");
            });
        }
    };

    //Project Slider Js
     var Project_Js = function ($scope) {
        $('.portfolio-slider-area').owlCarousel({
            loop:true,
            margin:30,
            nav:true,
            dots:false,
            items:10,
            navText:["<i class='fa-solid fa-angle-left'></i>","<i class='fa-solid fa-angle-right'></i>"],
            autoplay:true,
            smartSpeed:1500,
            autoplayTimeout:3000,
            responsiveClass:true,
            responsive:{
            0:{
              items:1,                
            },
            600:{
              items:1,
            },
            1000:{
              items:2,
            }
            }
          });

          //Project Slider Two
          $('.portfolio-slider2-boxarea').owlCarousel({
            loop:true,
            margin:30,
            nav:false,
            dots:false,
            items:10,
            autoplay:true,
            smartSpeed:1500,
            autoplayTimeout:3000,
            responsiveClass:true,
            responsive:{
            0:{
              items:1,                
            },
            600:{
              items:1,
            },
            1000:{
              items:2,
            }
            }
          });
    };
   
   // Testimonial Slider JS
    var Testimonial_Js = function ($scope) {
      var swiperThumb = new Swiper(".swiper-thumb2", {
        spaceBetween: 10,
        slidesPerView: 6,
        freeMode: true,
        watchSlidesProgress: true,
        autoplay: {
            delay: 2500,
            disableOnInteraction: false,
        },
        });
    
        var swiperMain = new Swiper(".swiper-testimonial-2", {
        spaceBetween: 10,
        loop: true,
        navigation: {
            nextEl: ".swiper-button-next",
            prevEl: ".swiper-button-prev",
        },
        autoplay: {
            delay: 2500,
            disableOnInteraction: false,
        },
        thumbs: {
            swiper: swiperThumb,
        },
      });
  
      // Optional: Sync slide on thumbnail click if needed
      const thumbs = document.querySelectorAll(".swiper-thumb2 .swiper-slide");
      thumbs.forEach((thumb, index) => {
        thumb.addEventListener("click", () => {
            swiperMain.slideToLoop(index); // Loop index-safe navigation
        });
      });


      // testimonial //
      $('.testimonial-review-area').owlCarousel({
        loop:true,
        margin:30,
        nav:true,
        dots:false,
        items:10,
        navText:["<i class='fa-solid fa-angle-left'></i>","<i class='fa-solid fa-angle-right'></i>"],
        autoplay:true,
        smartSpeed:1500,
        autoplayTimeout:3000,
        responsiveClass:true,
        responsive:{
          0:{
            items:1,                
          },
          600:{
            items:2,
          },
          1000:{
            items:3,
          }
        }
      });
      

      // testimonial //
      $('.testimonial-slider-box').owlCarousel({
        loop:true,
        margin:30,
        nav:true,
        dots:true,
        items:10,
        navText:["<i class='fa-solid fa-angle-up'></i>","<i class='fa-solid fa-angle-down'></i>"],
        autoplay:true,
        smartSpeed:1500,
        autoplayTimeout:3000,
        responsiveClass:true,
        responsive:{
          0:{
          items:1,                
          },
          600:{
          items:1,
          },
          1000:{
          items:1,
          }
        }
      });
    };


    // Services Animation Js 
     var Services_post_animation_Js = function ($scope, $) {
        const listItems = $scope.find('.list-container li');
        const images = $scope.find('.image-container .image');

        listItems.on('mouseover', function () {
            const targetImageId = $(this).data('image');

            images.removeClass('active');
            $scope.find('#' + targetImageId).addClass('active');
        });
    };
    $(window).on('elementor/frontend/init', function () {
        elementorFrontend.hooks.addAction('frontend/element_ready/YOUR_WIDGET_NAME.default', Services_post_animation_Js);
    });
    
    //Counter Js
      var Counter_Js = function ($scope) {
        const ucounter = $('.counter');
        if (ucounter.length > 0) {
         ucounter.countUp();  
        };
    }

    //Progressbar Js
      var Progressbar_Js = function ($scope) {
        var $element = $scope.find('.progressbar');
    
        function animateElements() {
            $element.each(function () {
                var $this = $(this);
                var elementPos = $this.offset().top;
                var topOfWindow = $(window).scrollTop();
                var windowHeight = $(window).height();
                var percent = $this.find('.circle').attr('data-percent');
                var percentage = parseInt(percent, 10) / 100;
                var animate = $this.data('animate');
    
                if (elementPos < topOfWindow + windowHeight - 10 && !animate) {
                    $this.data('animate', true);
                    $this.find('.circle').circleProgress({
                        startAngle: -Math.PI / 2,
                        value: percentage,
                        size: 80,
                        thickness: 5,
                        emptyFill: "#2B2D2E",
                        fill: { color: '#CEF12B' }
                    }).on('circle-animation-progress', function (event, progress, stepValue) {
                        $(this).find('.count span').text(Math.round(stepValue * 100) + "%");
                    });
                }
            });
        }
    
        // Run on scroll
        $(window).on('scroll', function () {
            animateElements();
        });
    
        // Run on init
        animateElements();
    };

     // VIDEO POPUP STARTS  Js
     var Video_Popup_Js = function ($scope) {
        if ($(".popup-youtube").length > 0) {
            $(".popup-youtube").magnificPopup({
            type: "iframe",
            });
            }
    }

    // Brand Slider Js
    var Brand_Slider_Js = function ($scope) {
        $('.about-brand-slider').owlCarousel({
            loop:true,
            margin:30,
            nav:false,
            dots:false,
            items:10,
            autoplay:true,
            smartSpeed:1500,
            autoplayTimeout:3000,
            responsiveClass:true,
            responsive:{
            0:{
              items:2,                
            },
            600:{
              items:3,
            },
            1000:{
              items:4,
            }
            }
          });
        }

    // Tab Js
    var Tab_Js = function($scope) {
      // helper: sync button ↔ collapse state inside a given container
      function syncAccordion($context) {
          $context.find('.accordion-item').each(function() {
              var $item     = $(this),
                  $btn      = $item.find('.accordion-button'),
                  $collapse = $item.find('.accordion-collapse');
              if ($collapse.hasClass('show')) {
                  $btn.removeClass('collapsed').attr('aria-expanded', 'true');
              } else {
                  $btn.addClass('collapsed').attr('aria-expanded', 'false');
              }
          });
      }
  
      // 1) on init, sync the currently visible tab pane
      syncAccordion($scope);
  
      // 2) delegate click for ALL accordion-buttons in this widget
      $scope.on('click', '.accordion-button', function(e) {
          e.preventDefault();
          var $btn      = $(this),
              targetSel = $btn.attr('data-bs-target'),
              $collapse = $scope.find(targetSel),
              parentSel = $collapse.attr('data-bs-parent');
  
          // close siblings if within a parent accordion
          if (parentSel) {
              $scope.find(parentSel + ' .accordion-collapse').not($collapse).removeClass('show');
              $scope.find(parentSel + ' .accordion-button').not($btn)
                    .addClass('collapsed').attr('aria-expanded', 'false');
          }
  
          // toggle this one
          var willOpen = !$collapse.hasClass('show');
          $collapse.toggleClass('show', willOpen);
          $btn.toggleClass('collapsed', !willOpen).attr('aria-expanded', willOpen);
      });
  
      // 3) when switching tabs, re‑sync that pane’s accordions
      $scope.find('[data-bs-toggle="pill"]').on('shown.bs.tab', function() {
          var paneSel = $(this).attr('data-bs-target'),
              $pane   = $scope.find(paneSel);
          syncAccordion($pane);
      });
    };


    $(window).on("elementor/frontend/init", function () {

        elementorFrontend.hooks.addAction("frontend/element_ready/global", Global_Js);
        elementorFrontend.hooks.addAction("frontend/element_ready/renev_header_menu.default", mobile_menu_Js);
        elementorFrontend.hooks.addAction("frontend/element_ready/renev_search.default", Search_Js);
        elementorFrontend.hooks.addAction("frontend/element_ready/renev_offcanvas.default", Offcanvas_Js);
           
        elementorFrontend.hooks.addAction("frontend/element_ready/image_section.default", Image_Js);
        elementorFrontend.hooks.addAction("frontend/element_ready/renev_project.default", Project_Js);
        elementorFrontend.hooks.addAction("frontend/element_ready/testimonial_slider.default", Testimonial_Js);
        elementorFrontend.hooks.addAction("frontend/element_ready/renev_service_post.default", Services_post_animation_Js);
        elementorFrontend.hooks.addAction("frontend/element_ready/renev-counter.default", Counter_Js);
        elementorFrontend.hooks.addAction("frontend/element_ready/renev_progress_bar.default", Progressbar_Js);
        elementorFrontend.hooks.addAction("frontend/element_ready/video_box.default", Video_Popup_Js);
        elementorFrontend.hooks.addAction("frontend/element_ready/renev_brand_slider.default", Brand_Slider_Js);
        elementorFrontend.hooks.addAction("frontend/element_ready/renev-tab.default", Tab_Js);
     
        
    });

})(jQuery);






