<div class="row">
    <div class="col-lg-12">
        <?php
        $total = count($service_lists);
        $index = 0;

        foreach( $service_lists as $item ) :
            $index++;
            $args = new \WP_Query(array(
                'post_type'   => 'renev_service',
                'post_status' => 'publish',
                'post__in'    => [$item['select_post']]
            ));
            while ( $args->have_posts() ) : $args->the_post();
                $is_last = $index === $total;
        ?>
                <div class="service-branding-boxesarea" <?php if ($is_last) echo 'border-bottom: 1px solid #282A2D;'; ?>>
                    <div class="service-brand-head">
                        <h2>
                            <a href="<?php the_permalink(); ?>">
                                <?php the_title(); ?>
                            </a>
                        </h2>
                        <ul class="service-list">
                            <li>
                                <a href="#"><?php echo esc_html($item['serviceslist_text']); ?></a>
                            </li>
                            <li>
                                <a href="#"><?php echo esc_html($item['serviceslist2_text']); ?></a>
                            </li>
                        </ul>
                    </div>
                    <div class="hidden-img">
                        <img src="<?php echo esc_url($item['hiden_image']['url']); ?>" alt="">
                    </div>
                    <div class="arrow">
                        <a href="<?php the_permalink(); ?>">
                            <i class="fa-solid fa-arrow-right"></i>
                        </a>
                    </div>
                </div>
        <?php
            endwhile;
            wp_reset_postdata();
        endforeach;
        ?>
    </div>
</div>
