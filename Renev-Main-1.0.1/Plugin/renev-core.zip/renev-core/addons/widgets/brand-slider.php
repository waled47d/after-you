<?php
use \Elementor\Widget_Base;
use \Elementor\Controls_Manager;
use \Elementor\Group_Control_Background;
use \Elementor\Icons_Manager;
use \Elementor\Group_Control_Typography;
use \Elementor\Group_Control_Border;
use \Elementor\Group_Control_Box_Shadow;
use \Elementor\Repeater;
use \Elementor\Utils;
/**
 *
 * Text Slider Widget .
 *
 */
class Renev_Brand_Slider extends Widget_Base {

	public function get_name() {
		return 'renev_brand_slider';
	}

	public function get_title() {
		return __( 'Brand Slider', 'renev' );
	}

	public function get_icon() {
		return 'eicon-code';
    }

	public function get_categories() {
		return [ 'renev' ];
	}

	protected function register_controls() {

        // Brand Slider
        $this->start_controls_section(
            'brand_slider_section',
            [
                'label' => __('Brand Slider', 'renev'),
                'tab'   => Controls_Manager::TAB_CONTENT,
            ]
        );
        
        $repeater = new \Elementor\Repeater();

        $repeater->add_control(
            'slider_img',
            [
                'label' => __('Image', 'renev'),
                'type'  => Controls_Manager::MEDIA,
            ]
        );
        $this->add_control(
            'number_of_items',
            [
                'label' => __( 'Number of Items to Show', 'renev' ),
                'type' => \Elementor\Controls_Manager::NUMBER,
                'min' => 1,
                'max' => 50,
            ]
        );
        $this->add_control(
            'slider_lists',
            [
                'label' => __('Slider Lists', 'renev'),
                'type' => \Elementor\Controls_Manager::REPEATER,
                'fields' => $repeater->get_controls(),
            ]
            
        );
        $this->end_controls_section();

        //Brand Box Style
        $this->start_controls_section(
            'brand_box_style',
            [
                'label' => __( 'Slide Box Style', 'renev' ),
                'tab'   => Controls_Manager::TAB_STYLE,
            ]
        );
        // Background
        $this->add_group_control(
            Group_Control_Background::get_type(),
            [
                'name'     => 'brand_box_bg',
                'label'    => __( 'Background', 'renev' ),
                'types'    => [ 'classic', 'gradient' ],
                'selector' => '{{WRAPPER}} .about-brand-sliderarea .about-brand-slider .brand-img1',
            ]
        );
        // Border Radius
        $this->add_control(
            'brand_box_radius',
            [
                'label' => __( 'Border Radius', 'renev' ),
                'type'  => Controls_Manager::DIMENSIONS,
                'selectors' => [
                    '{{WRAPPER}} .about-brand-sliderarea .about-brand-slider .brand-img1' => 'border-radius: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
                ],
            ]
        );
        // Padding
        $this->add_responsive_control(
            'brand_box_padding',
            [
                'label' => __( 'Padding', 'renev' ),
                'type'  => Controls_Manager::DIMENSIONS,
                'selectors' => [
                    '{{WRAPPER}} .about-brand-sliderarea .about-brand-slider .brand-img1' => 'padding: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
                ],
            ]
        );
        $this->end_controls_section();

        //Brand Image Style
        $this->start_controls_section(
            'brand_image_style',
            [
                'label' => __( 'Image Style', 'renev' ),
                'tab'   => Controls_Manager::TAB_STYLE,
            ]
        );
        
        // Image Width
        $this->add_responsive_control(
            'brand_image_width',
            [
                'label' => __( 'Image Width', 'renev' ),
                'type'  => Controls_Manager::SLIDER,
                'range' => [
                    'px' => [
                        'min' => 10,
                        'max' => 1000,
                    ],
                    '%' => [
                        'min' => 1,
                        'max' => 100,
                    ],
                ],
                'selectors' => [
                    '{{WRAPPER}} .about-brand-sliderarea .about-brand-slider .brand-img1 img' => 'width: {{SIZE}}{{UNIT}};',
                ],
            ]
        );
        // Image Height
        $this->add_responsive_control(
            'brand_image_height',
            [
                'label' => __( 'Image Height', 'renev' ),
                'type'  => Controls_Manager::SLIDER,
                'range' => [
                    'px' => [
                        'min' => 10,
                        'max' => 1000,
                    ],
                ],
                'selectors' => [
                    '{{WRAPPER}} .about-brand-sliderarea .about-brand-slider .brand-img1 img' => 'height: {{SIZE}}{{UNIT}}; object-fit: contain;',
                ],
            ]
        );
        $this->end_controls_section();

    }

    // Render
	protected function render() {
        $settings = $this->get_settings_for_display(); 
        $slider_lists = $settings['slider_lists'];
        $max_items = !empty($settings['number_of_items']) ? intval($settings['number_of_items']) : count($slider_lists);
        $counter = 0;
    
    ?>
     <div class="about-brand-sliderarea">
        <div class="about-brand-slider owl-carousel">
            <?php foreach ( $slider_lists as $item ): ?>
                <?php if ( $counter >= $max_items ) break; ?>
                    <div class="brand-img1">
                        <img src="<?php echo esc_url( $item['slider_img']['url'] ); ?>" alt="">
                    </div>
                <?php $counter++; ?>
            <?php endforeach; ?>
        </div>
    </div>
     <?php
    }
}
$widgets_manager->register( new \Renev_Brand_Slider() );