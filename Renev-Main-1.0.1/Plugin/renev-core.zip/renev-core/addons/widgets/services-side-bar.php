<?php
use \Elementor\Widget_Base;
use \Elementor\Controls_Manager;
use \Elementor\Group_Control_Typography;
use \Elementor\Group_Control_Text_Shadow;
use \Elementor\Group_Control_Border;
use \Elementor\Group_Control_Box_Shadow;
use \Elementor\Repeater;
use \Elementor\Utils;
/**
 *
 * Renev Services Side Bar Widget .
 *
 */
class Renev_Services_Side_Bar extends Widget_Base {

	public function get_name() {
		return 'renev_services_side_bar';
	}

	public function get_title() {
		return __( 'Renev Side Bar Post', 'renev' );
	}

	public function get_icon() {
		return 'eicon-code';
    }

	public function get_categories() {
		return [ 'renev' ];
	}

	protected function register_controls() {

        $this->start_controls_section(
            'content_section',
            [
                'label' => __('Content', 'renev'),
                'tab'   => Controls_Manager::TAB_CONTENT,
            ]
        );
        $this->add_control(
            'category_title',
            [
                'label' => esc_html__('category', 'renev'),
                'type' => Controls_Manager::TEXT,
                'label_block' => true,
                'default' => esc_html__('Our Service', 'renev'),
            ]
        );

        $this->add_control(
            'show_per_page',
            [
                'label' => esc_html__('Posts Per Page', 'renev'),
                'description' => esc_html__('Leave blank or enter -1 for all.', 'renev'),
                'type' => Controls_Manager::NUMBER,
                'default' => 4,
            ]
        );
        $this->end_controls_section();

        // Services Box STYLE
        $this->start_controls_section(
            'services_box_style',
            [
                'label' => __('Services Box', 'renev'),
                'tab'   => Controls_Manager::TAB_STYLE,
            ]
        );
        $this->add_control(
            'services_box_bg',
            [
                'label' => __( 'Background', 'renev' ),
                'type' => Controls_Manager::COLOR,
                'selectors' => [
                    '{{WRAPPER}} .service-details-section .service-details-side .category-area' => 'background: {{VALUE}}',
                ]
            ]
        );
        $this->add_responsive_control(
            'services_box_padding',
            [
                'label' => __( 'Padding', 'renev' ),
                'type' => Controls_Manager::DIMENSIONS,
                'size_units' => [ 'px', 'em', '%' ],
                'selectors' => [
                    '{{WRAPPER}} .service-details-section .service-details-side .category-area' => 'padding: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
                ],
            ]
        );
        $this->add_control(
            'services_box_radius',
            [
                'label' => esc_html__( 'Border Radius', 'renev' ),
                'type' => Controls_Manager::DIMENSIONS,
                'size_units' => [ 'px', '%', 'em', 'rem', 'custom' ],
                'selectors' => [
                    '{{WRAPPER}} .service-details-section .service-details-side .category-area' => 'border-radius: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
                ],
            ]
        );
        $this->end_controls_section();

        // Title STYLE
        $this->start_controls_section(
            'category_title_style',
            [
                'label' => __('Title', 'renev'),
                'tab'   => Controls_Manager::TAB_STYLE,
            ]
        );

        $this->add_control(
            'category_title_color',
            [
                'label' => __( 'Color', 'renev' ),
                'type' => Controls_Manager::COLOR,
                'selectors' => [
                    '{{WRAPPER}} .service-details-section .service-details-side h3' => 'color: {{VALUE}}',
                ],
            ]
        );
        $this->add_group_control(
            Group_Control_Typography::get_type(),
            [
                'name' => 'category_title_typography',
                'selector' => '{{WRAPPER}} .service-details-section .service-details-side h3',
            ]
        );
       
        $this->add_responsive_control(
            'category_title_margin',
            [
                'label' => __( 'Margin', 'renev' ),
                'type' => Controls_Manager::DIMENSIONS,
                'size_units' => [ 'px', 'em', '%' ],
                'selectors' => [
                    '{{WRAPPER}} .service-details-section .service-details-side h3' => 'margin: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
                ],
            ]
        );
        $this->end_controls_section();


         // Sidebar List STYLE
         $this->start_controls_section(
            'sidebar_list_style',
            [
                'label' => __('Sidebar List', 'renev'),
                'tab'   => Controls_Manager::TAB_STYLE,
            ]
        );
        $this->add_responsive_control(
            'sidebar_list_margin',
            [
                'label' => __( 'List margin', 'renev' ),
                'type' => Controls_Manager::DIMENSIONS,
                'size_units' => [ 'px', 'em', '%' ],
                'selectors' => [
                    '{{WRAPPER}} .service-details-section .service-details-side .category-area ul li a' => 'margin: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
                ],
            ]
        );
        $this->add_control(
            'sidebar_list_color',
            [
                'label' => __( 'List Color', 'renev' ),
                'type' => Controls_Manager::COLOR,
                'selectors' => [
                    '{{WRAPPER}} .service-details-section .service-details-side .category-area ul li a' => 'color: {{VALUE}}',
                ],
            ]
        );
        $this->add_control(
            'sidebar_list_hover_color',
            [
                'label' => __( 'List Hover Color', 'renev' ),
                'type' => Controls_Manager::COLOR,
                'selectors' => [
                    '{{WRAPPER}} .service-details-section .service-details-side .category-area ul li a:hover' => 'color: {{VALUE}}',
                ],
            ]
        );
        $this->add_group_control(
            Group_Control_Typography::get_type(),
            [
                'name' => 'sidebar_list_typography',
                'selector' => '{{WRAPPER}} .service-details-section .service-details-side .category-area ul li a',
            ]
        );
        $this->add_control(
            'sidebar_list_box_bg',
            [
                'label' => __( 'List Box Background', 'renev' ),
                'type' => Controls_Manager::COLOR,
                'selectors' => [
                    '{{WRAPPER}} .service-details-section .service-details-side .category-area ul li a' => 'background: {{VALUE}}',
                ]
            ]
        );
        $this->add_control(
            'sidebar_list_box_hover_bg',
            [
                'label' => __( 'List Box Hover Background', 'renev' ),
                'type' => Controls_Manager::COLOR,
                'selectors' => [
                    '{{WRAPPER}} .service-details-section .service-details-side .category-area ul li a:hover' => 'background: {{VALUE}}',
                ]
            ]
        );
        $this->add_responsive_control(
            'sidebar_list_box_padding',
            [
                'label' => __( 'List Box Padding', 'renev' ),
                'type' => Controls_Manager::DIMENSIONS,
                'size_units' => [ 'px', 'em', '%' ],
                'selectors' => [
                    '{{WRAPPER}} .service-details-section .service-details-side .category-area ul li a' => 'padding: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
                ],
            ]
        );
        $this->add_control(
            'sidebar_list_box_radius',
            [
                'label' => esc_html__( 'List Box Radius', 'renev' ),
                'type' => Controls_Manager::DIMENSIONS,
                'size_units' => [ 'px', '%', 'em', 'rem', 'custom' ],
                'selectors' => [
                    '{{WRAPPER}} .service-details-section .service-details-side .category-area ul li a' => 'border-radius: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
                ],
            ]
        );
        $this->end_controls_section();
    }

    // Render
	protected function render() {
        $settings = $this->get_settings_for_display();
        
        ?>
            <div class="service-details-section">
                <div class="service-details-side">
                    <div class="category-area">
                        <?php if (!empty($settings['category_title'])) : ?>
                            <h3>
                                <?php echo esc_html($settings['category_title']); ?>
                            </h3>
                        <?php endif; ?>
                        <ul>
                            <?php
                            $args = new WP_Query([
                                'post_type'      => 'renev_service',
                                'post_status'    => 'publish',
                                'orderby'        => 'date',
                                'posts_per_page' => (int) $settings['show_per_page'], 
                            ]);

                            while ($args->have_posts()) : $args->the_post(); ?>
                                <li>
                                    <a href="<?php the_permalink(); ?>">
                                        <?php the_title(); ?>
                                        <i class="fa-solid fa-angle-right"></i>
                                    </a>
                                </li>
                                <?php endwhile;
                            wp_reset_postdata();
                            ?>
                        </ul>
                    </div>
                </div>
            </div>
        <?php
    }

}
$widgets_manager->register( new \Renev_Services_Side_Bar() );