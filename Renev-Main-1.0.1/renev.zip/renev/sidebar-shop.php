<?php
	// Block direct access
	if( ! defined( 'ABSPATH' ) ){
		exit( );
	}
	/**
	* @Packge 	   : Renev
	* @Version     : 1.0
	* @Author     : Mthemeus
    * @Author URI : https://www.mthemeus.com/
	*
	*/

	if( ! is_active_sidebar( 'renev-woo-sidebar' ) ){
		return;
	}
?>
<div class="col-lg-4 col-xl-3">
	<!-- Sidebar Begin -->
	<aside class="sidebar-area shop-sidebar">
		<?php
			dynamic_sidebar( 'renev-woo-sidebar' );
		?>
	</aside>
	<!-- Sidebar End -->
</div>