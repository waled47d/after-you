<?php
use \Elementor\Widget_Base;
use \Elementor\Controls_Manager;
use \Elementor\Icons_Manager;
use \Elementor\Group_Control_Typography;
use \Elementor\Group_Control_Border;
use \Elementor\Group_Control_Box_Shadow;
use \Elementor\Repeater;
use \Elementor\Utils;


/**
 *
 * Dual Heading Widget .
 *
 */

class Renev_Heading extends Widget_Base {

    public function get_name() {
        return 'renev_heading';
    }

    public function get_title() {
        return __( 'Renev Heading', 'renev' );
    }

    public function get_icon() {
        return 'eicon-code';
    }

    public function get_categories() {
        return [ 'renev' ];
    }

    protected function register_controls() {
        // Content Section
        $this->start_controls_section(
            'content_section',
            [
                'label' => __( 'Content', 'renev' ),
                'tab' => Controls_Manager::TAB_CONTENT,
            ]
        );
        $this->add_control(
            'show_title',
            [
                'label' => __( 'Show title', 'renev' ),
                'type' => \Elementor\Controls_Manager::SWITCHER,
                'label_on' => __( 'Show', 'renev' ),
                'label_off' => __( 'Hide', 'renev' ),
                'return_value' => 'yes',
                'default' => 'yes',
            ]
        );
        $this->add_responsive_control(
            'heading_alignment',
            [
                'label' => __( 'Alignment', 'renev' ),
                'type' => Controls_Manager::CHOOSE,
                'options' => [
                    'left' => [
                        'title' => __( 'Left', 'renev' ),
                        'icon' => 'eicon-text-align-left',
                    ],
                    'center' => [
                        'title' => __( 'Center', 'renev' ),
                        'icon' => 'eicon-text-align-center',
                    ],
                    'right' => [
                        'title' => __( 'Right', 'renev' ),
                        'icon' => 'eicon-text-align-right',
                    ],
                ],
                'selectors' => [
                    '{{WRAPPER}} .heading1' => 'text-align: {{VALUE}};',
                ],
                'default' => 'left',
            ]
        );        
        $this->add_control(
            'heading_image',
            [
                'label' => __( 'Image', 'renev' ),
                'type' => Controls_Manager::MEDIA,
                'default' => [
                    'url' => Utils::get_placeholder_image_src(),
                ],
            ]
            );
        $this->add_control(
            'dual_heading_one',
            [
                'label' => __( 'Text One', 'renev' ),
                'type' => Controls_Manager::TEXT,
                'default' => __( 'Real Feedback', 'renev' ),
                'label_block' => true,
            ]
        );
        $this->add_control(
            'dual_heading_two',
            [
                'label' => __( 'Text One', 'renev' ),
                'type' => Controls_Manager::TEXT,
                'default' => __( 'our experienced team', 'renev' ),
                'label_block' => true,
            ]
        ); 
        $this->end_controls_section();

        // Style Section
        $this->start_controls_section(
            'heading_style_section',
            [
                'label' => __( 'Style', 'renev' ),
                'tab' => Controls_Manager::TAB_STYLE,
            ]
        );
        $this->add_control(
            'dual_heading_one_color',
            [
                'label' => __( 'Heading One Color', 'renev' ),
                'type' => Controls_Manager::COLOR,
                'selectors' => [
                    '{{WRAPPER}} .heading1 h5' => 'color: {{VALUE}};',
                ],
            ]
        );
        $this->add_group_control(
            Group_Control_Typography::get_type(),
            [
                'name' => 'heading_typography',
                'label' => __( 'Typography', 'renev' ),
                'selector' => '{{WRAPPER}} .heading1 h5',
            ]
        );
        $this->add_control(
            'heading_one_margin',
            [
                'label'      => __( 'Heading One Margin', 'renev' ),
                'type'       => Controls_Manager::DIMENSIONS,
                'size_units' => [ 'px', '%', 'em' ],
                'selectors'  => [
                    '{{WRAPPER}} .heading1 h5' => 'margin: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
                ],
            ]
        );    
        $this->add_control(
            'dual_heading_two_color',
            [
                'label' => __( 'Heading Two Color', 'renev' ),
                'type' => Controls_Manager::COLOR,
                'selectors' => [
                    '{{WRAPPER}} .heading1 h2' => 'color: {{VALUE}} !important',
                ],
            ]
        );
        $this->add_group_control(
            Group_Control_Typography::get_type(),
            [
                'name' => 'heading_two_typography',
                'label' => __( 'Typography', 'renev' ),
                'selector' => '{{WRAPPER}} .heading1 h2',
            ]
        );
        $this->add_control(
            'heading_two_margin',
            [
                'label'      => __( 'Heading Two Margin', 'renev' ),
                'type'       => Controls_Manager::DIMENSIONS,
                'size_units' => [ 'px', '%', 'em' ],
                'selectors'  => [
                    '{{WRAPPER}} .heading1 h2' => 'margin: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
                ],
            ]
        );    
		$this->add_responsive_control(
			'heading_img_width',
			[
				'label' => esc_html__( 'Img Width', 'renev' ),
				'type' => Controls_Manager::SLIDER,
				'size_units' => [ 'px', '%', 'em', 'rem', 'custom' ],
				'range' => [
					'px' => [
						'min' => 0,
						'max' => 1000,
						'step' => 1,
					],
					'%' => [
						'min' => 0,
						'max' => 100,
					],
				],
				'selectors' => [
					'{{WRAPPER}} .heading1 h5 img' => 'width: {{SIZE}}{{UNIT}};',
				],
			]
		);
        $this->add_control(
            'heading_img_margin',
            [
                'label'      => __( 'Heading Img Margin', 'renev' ),
                'type'       => Controls_Manager::DIMENSIONS,
                'size_units' => [ 'px', '%', 'em' ],
                'selectors'  => [
                    '{{WRAPPER}} .heading1 h5 img' => 'margin: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
                ],
            ]
        );
        $this->end_controls_section();
    }

    // Render
    protected function render() {
        $settings = $this->get_settings_for_display();

        ?>
            <div class="heading1">
                <?php if (!empty($settings['dual_heading_one'])): ?>
                    <h5>
                        <img src="<?php echo esc_url( $settings['heading_image']['url'] ); ?>" alt="">
                        <?php echo esc_html( $settings[ 'dual_heading_one' ]  ); ?>
                    </h5>
                <?php endif; ?>

                <?php if ('yes' === $settings['show_title'] &&  !empty($settings['dual_heading_two'])): ?>
                    <h2 class="text-anime-style-3">
                        <?php echo renev_kses( $settings['dual_heading_two'] ); ?>
                    </h2>
                <?php endif; ?>
            </div>
        <?php
    }
}

// Register the widget
$widgets_manager->register( new \Renev_Heading() );


