<?php
// Block direct access
if( !defined( 'ABSPATH' ) ){
    exit();
}
/**
 * @Packge     : Renev
 * @Version    : 1.0
 * @Author     : Mthemeus
 * @Author URI : https://www.mthemeus.com/
 *
 */

// enqueue css
function renev_common_custom_css(){
	wp_enqueue_style( 'renev-color-schemes', get_template_directory_uri().'/assets/css/color.schemes.css' );

    $CustomCssOpt  = renev_opt( 'renev_css_editor' );
	if( $CustomCssOpt ){
		$CustomCssOpt = $CustomCssOpt;
	}else{
		$CustomCssOpt = '';
	}

    $customcss = "";

    if( get_header_image() ){
        $renev_header_bg =  get_header_image();
    }else{
        if( renev_meta( 'page_breadcrumb_settings' ) == 'page' && is_page() ){
            if( ! empty( renev_meta( 'breadcumb_image' ) ) ){
                $renev_header_bg = renev_meta( 'breadcumb_image' );
            }
        }
    }

    if( !empty( $renev_header_bg ) ){
        $customcss .= ".breadcumb-wrapper{
            background-image:url('{$renev_header_bg}')!important;
        }";
    }



	// theme color
	$renev_primary 	    = renev_opt('renev_primary');
	$renev_secondary      = renev_opt('renev_secondary');
	$renev_secondary_two  = renev_opt('renev_secondary_two');
	$renev_heading_color  = renev_opt('renev_heading_color');
	$renev_body_color     = renev_opt('renev_body_color');
	$renev_body_bg        = renev_opt('renev_body_bg');
	$light_color            = renev_opt('light_color');
	$black_color            = renev_opt('black_color');
	$white_color            = renev_opt('white_color');
	$renev_smoke            = renev_opt('renev_smoke');
	$yellow_color           = renev_opt('yellow_color');
	$success_color          = renev_opt('success_color');
	$error_color            = renev_opt('error_color');
	$border_color           = renev_opt('border_color');

	
	if( !empty( $renev_primary ) ) {
		$customcss .= ":root {
		  --theme-color: {$renev_primary};
		}";
	}

	if( !empty( $renev_secondary ) ) {
		$customcss .= ":root {
			--theme-color2: {$renev_secondary};
		}";
	}

	if( !empty( $renev_secondary_two ) ) {
		$customcss .= ":root {
			--fav-secondary-color: {$renev_secondary_two};
		}";
	}

	if( !empty( $renev_heading_color ) ) {
		$customcss .= ":root {
			--title-color: {$renev_heading_color};
		}";
	}

	if( !empty( $renev_body_color ) ) {
		$customcss .= ":root {
			--body-color: {$renev_body_color};
		}";
	}

	if( !empty( $renev_body_bg ) ) {
		$customcss .= ":root {
			--body-bg: {$renev_body_bg};
		}";
	}

	if( !empty( $light_color ) ) {
		$customcss .= ":root {
			--light-color: {$light_color};
		}";
	}

	if( !empty( $renev_smoke ) ) {
		$customcss .= ":root {
			--smoke-color: {$renev_smoke};
		}";
	}

	if( !empty( $black_color ) ) {
		$customcss .= ":root {
			--black-color: {$black_color};
		}";
	}

	if( !empty( $white_color  ) ) {
		$customcss .= ":root {
			--white-color: {$white_color };
		}";
	}

	if( !empty( $success_color ) ) {
		$customcss .= ":root {
			--success-color: {$success_color};
		}";
	}

	if( !empty( $error_color ) ) {
		$customcss .= ":root {
			--error-color: {$error_color};
		}";
	}

	if( !empty( $border_color ) ) {
		$customcss .= ":root {
			--border-color: {$border_color};
		}";
	}

	if( !empty( $CustomCssOpt ) ){
		$customcss .= $CustomCssOpt;
	}

    wp_add_inline_style( 'renev-color-schemes', $customcss );
}
add_action( 'wp_enqueue_scripts', 'renev_common_custom_css', 100 );