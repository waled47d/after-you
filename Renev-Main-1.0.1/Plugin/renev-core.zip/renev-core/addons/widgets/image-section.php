<?php
/**
 * Button Widget.
 *
 *
 * @since 1.0.0
 */
namespace Elementor;
use Elementor\Controls_Manager;
use Elementor\Group_Control_Border;
use Elementor\Group_Control_Box_Shadow;
use Elementor\Group_Control_Typography;
use Elementor\Widget_Base;
use Elementor\Group_Control_Background;
use Elementor\Group_Control_Css_Filter;
use Elementor\Icons_Manager;
use Elementor\Utils;
use Elementor\Repeater;
use Elementor\URL;

if (!defined('ABSPATH')) {
    exit;
}
// If this file is called directly, abort.
class Renev_Image_Section extends Widget_Base {
    public function get_name() {
        return 'image_section';
    }
    public function get_title() {
        return __('Image Section', 'renev');
    }
    public function get_icon() {
        return ('eicon-person');
    }
    public function get_categories() {
        return ['renev-addons'];
    }
    public function get_keywords() {
        return ['Image'];
    }

    protected function register_controls() {

        $this->start_controls_section(
            'content_section',
            [
                'label' => __('Content', 'renev'),
                'tab'   => Controls_Manager::TAB_CONTENT,
            ]
        );
        $this->add_control(
            'image_layout',
            [
                'label' => esc_html__('Select Layout', 'renev'),
                'type' => Controls_Manager::SELECT,
                'options' => [
                    'layout-1' => esc_html__('Layout 1', 'renev'),
                    'layout-2' => esc_html__('Layout 2', 'renev'),
                    'layout-3' => esc_html__('Layout 3', 'renev'),
                    'layout-4' => esc_html__('Layout 4', 'renev'),
                    'layout-5' => esc_html__('Layout 5', 'renev'),
                ],
                'default' => 'layout-1',
            ]
        );
        $this->add_control(
            'image_one',
            [
                'label'   => __( 'Image One', 'renev' ),
                'type'    => Controls_Manager::MEDIA,
                'default' => [
                    
                ],
            ]
        );
        $this->add_control(
            'shape-img',
            [
                'label'   => __( 'Shape Img', 'renev' ),
                'type'    => Controls_Manager::MEDIA,
                'default' => [
                    
                ],
                'condition' => [
                    'image_layout!' => 'layout-1',
                ],
            ]
        );
        $this->add_control(
            'circle-img',
            [
                'label'   => __( 'Circle Img', 'renev' ),
                'type'    => Controls_Manager::MEDIA,
                'default' => [
                    
                ],
                'condition' => [
                    'image_layout!' => 'layout-1',
                ],
            ]
        );
        $this->add_control(
            'btn_text',
            [
                'label' => esc_html__('Button Text', 'renev'),
                'type' => Controls_Manager::TEXT,
                'default' => esc_html__('Get Started', 'renev'),
                'label_block' => true,
                'condition' => [
                    'image_layout' => 'layout-2',
                ],
            ]
        );
        $this->add_control(
            'btn_link',
            [
                'label' => esc_html__('Button Url', 'renev'),
                'type' => Controls_Manager::URL,
                'default' => [
                    'url' => '#',
                ],
                'label_block' => true,
                'condition' => [
                    'image_layout' => 'layout-2',
                ],
            ]
        );
        $this->add_control(
            'image_two',
            [
                'label'   => __( 'Image Two', 'renev' ),
                'type'    => Controls_Manager::MEDIA,
                'default' => [],
                'condition' => [
                    'image_layout!' => ['layout-2', 'layout-4'],
                ],
            ]
        );
        $this->add_control(
            'image_three',
            [
                'label'   => __( 'Image Three', 'renev' ),
                'type'    => Controls_Manager::MEDIA,
                'default' => [],
                'condition' => [
                    'image_layout' => 'layout-5',
                ],
            ]
        );
        $this->end_controls_section();

        //Image Style
        $this->start_controls_section(
            'image_style_section',
            [
                'label' => __( 'Image Section', 'renev' ),
                'tab' => Controls_Manager::TAB_STYLE,
            ]
        );
        $this->add_responsive_control(
            'image_width',
            [
                'label' => esc_html__( 'Image Width', 'renev' ),
                'type' => Controls_Manager::SLIDER,
                'size_units' => [ 'px', '%', 'em', 'rem', 'custom' ],
                'range' => [
                    'px' => [
                        'min' => 0,
                        'max' => 1000,
                        'step' => 1,
                    ],
                    '%' => [
                        'min' => 0,
                        'max' => 100,
                    ],
                ],
                'selectors' => [
                    '{{WRAPPER}} .about1-section-area .images img' => 'width: {{SIZE}}{{UNIT}};',
                    '{{WRAPPER}} .hero-bottom-images .img1 img' => 'width: {{SIZE}}{{UNIT}};',
                    '{{WRAPPER}} .img1.reveal' => 'width: {{SIZE}}{{UNIT}};',
                    '{{WRAPPER}} .images-area .img1 img' => 'width: {{SIZE}}{{UNIT}};',
                    '{{WRAPPER}} .service-images .img1 img' => 'width: {{SIZE}}{{UNIT}};',
                ],
            ]
        );
        $this->add_responsive_control(
            'image_radius',
            [
                'label'         => __( 'Border Radius', 'renev' ),
                'type'          => Controls_Manager::DIMENSIONS,
                'size_units'    => [ 'px', '%', 'em' ],
                'selectors'     => [
                    '{{WRAPPER}} .about1-section-area .images img' => 'border-radius: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
                    '{{WRAPPER}} .hero-bottom-images .img1 img' => 'border-radius: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
                    '{{WRAPPER}} .img1.reveal' => 'border-radius: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
                    '{{WRAPPER}} .images-area .img1 img' => 'border-radius: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
                    '{{WRAPPER}} .service-images .img1 img' => 'border-radius: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
                ],
            ]
        );
        $this->add_control(
            'image_margin',
            [
                'label'      => __( 'Image Margin', 'renev' ),
                'type'       => Controls_Manager::DIMENSIONS,
                'size_units' => [ 'px', '%', 'em' ],
                'selectors'  => [
                    '{{WRAPPER}} .img1.reveal.margin' => 'margin: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
                ],
                'condition' => [
                    'image_layout' => 'layout-3',
                ],
            ]
        );    
        $this->add_responsive_control(
            'Shape_one_width',
            [
                'label' => esc_html__( 'Shape One Width', 'renev' ),
                'type' => Controls_Manager::SLIDER,
                'size_units' => [ 'px', '%', 'em', 'rem', 'custom' ],
                'range' => [
                    'px' => [
                        'min' => 0,
                        'max' => 1000,
                        'step' => 1,
                    ],
                    '%' => [
                        'min' => 0,
                        'max' => 100,
                    ],
                ],
                'selectors' => [
                    '{{WRAPPER}} .about-images-area .elements12' => 'width: {{SIZE}}{{UNIT}};',
                ],
                'condition' => [
                    'image_layout' => 'layout-3',
                ],
                
            ]
        );
        $this->add_responsive_control(
            'Shape_two_width',
            [
                'label' => esc_html__( 'Shape Two Width', 'renev' ),
                'type' => Controls_Manager::SLIDER,
                'size_units' => [ 'px', '%', 'em', 'rem', 'custom' ],
                'range' => [
                    'px' => [
                        'min' => 0,
                        'max' => 1000,
                        'step' => 1,
                    ],
                    '%' => [
                        'min' => 0,
                        'max' => 100,
                    ],
                ],
                'selectors' => [
                    '{{WRAPPER}} .about-images-area .elements13' => 'width: {{SIZE}}{{UNIT}};',
                ],
                'condition' => [
                    'image_layout' => 'layout-3',
                ],
                
            ]
        );
        $this->end_controls_section();
        

        //Circle Button Sytle
        $this->start_controls_section(
            'circle_button_style',
            [
                'label' => __( 'Circle Button', 'renev' ),
                'tab' => Controls_Manager::TAB_STYLE,
                'condition' => [
                    'image_layout' => 'layout-2',
                ],
            ]
        );
        $this->add_responsive_control(
            'circle_image_max_width', 
            [
                'label' => esc_html__( 'Circle Image Max Width', 'renev' ),
                'type' => Controls_Manager::SLIDER,
                'size_units' => [ 'px', '%', 'em', 'rem', 'custom' ],
                'range' => [
                    'px' => [
                        'min' => 0,
                        'max' => 1000,
                        'step' => 1,
                    ],
                    '%' => [
                        'min' => 0,
                        'max' => 100,
                    ],
                ],
                'selectors' => [
                    '{{WRAPPER}} .started-btn img' => 'max-width: {{SIZE}}{{UNIT}};',
                ],
            ]
        );
        $this->add_responsive_control(
            'circle_button_arrow_width',
            [
                'label' => esc_html__( 'circle Arrow Width', 'renev' ),
                'type' => Controls_Manager::SLIDER,
                'size_units' => [ 'px', '%', 'em', 'rem', 'custom' ],
                'range' => [
                    'px' => [
                        'min' => 0,
                        'max' => 1000,
                        'step' => 1,
                    ],
                    '%' => [
                        'min' => 0,
                        'max' => 100,
                    ],
                ],
                'selectors' => [
                    '{{WRAPPER}} .hero-bottom-images .started-btn a span' => 'width: {{SIZE}}{{UNIT}};',
                ],
            ]
        );
        $this->add_responsive_control(
            'circle_button_arrow_heighe',
            [
                'label' => esc_html__( 'circle Arrow Height', 'renev' ),
                'type' => Controls_Manager::SLIDER,
                'size_units' => [ 'px', '%', 'em', 'rem', 'custom' ],
                'range' => [
                    'px' => [
                        'min' => 0,
                        'max' => 1000,
                        'step' => 1,
                    ],
                    '%' => [
                        'min' => 0,
                        'max' => 100,
                    ],
                ],
                'selectors' => [
                    '{{WRAPPER}} .hero-bottom-images .started-btn a span' => 'height: {{SIZE}}{{UNIT}};',
                ],
            ]
        );
        $this->add_control(
            'circle_arrow_background',
            [
                'label' => __( 'Circle Arrow Background', 'renev' ),
                'type' => Controls_Manager::COLOR,
                'selectors' => [
                    '{{WRAPPER}} .hero-bottom-images .started-btn a span' => 'background: {{VALUE}};',
                ],
            ]
        );
        $this->add_control(
            'circle_arrow_color',
            [
                'label' => __( 'Circle Arrow Color', 'renev' ),
                'type' => Controls_Manager::COLOR,
                'selectors' => [
                    '{{WRAPPER}} .hero-bottom-images .started-btn a span' => 'color: {{VALUE}};',
                ],
            ]
        );
        $this->add_responsive_control(
            'circle_arrow_radius',
            [
                'label'         => __( 'Arrow Radius', 'renev' ),
                'type'          => Controls_Manager::DIMENSIONS,
                'size_units'    => [ 'px', '%', 'em' ],
                'selectors'     => [
                    '{{WRAPPER}} .hero-bottom-images .started-btn a span' => 'border-radius: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
                ],
            ]
        );
        //Circle Button Text Style
        $this->add_control(
            'circle_button_text_color',
            [
                'label' => __( 'Circle Text Color', 'renev' ),
                'type' => Controls_Manager::COLOR,
                'selectors' => [
                    '{{WRAPPER}} .hero-bottom-images .started-btn a' => 'color: {{VALUE}};',
                ],
            ]
        );
        $this->add_group_control(
            Group_Control_Typography::get_type(),
            [
                'name' => 'circle_button_text_typography',
                'label' => __( 'Typography', 'renev' ),
                'selector' => '{{WRAPPER}} .hero-bottom-images .started-btn a',
            ]
        );
        $this->end_controls_section();

    }

    protected function render() {
        $settings = $this->get_settings_for_display();
        $layout = $settings['image_layout'];

        ?>
            <?php
                if ( $layout) {
                    include('image/'.$layout.'.php');
                }
            ?> 
        <?php
    }
}
$widgets_manager->register(new \Elementor\Renev_Image_Section());