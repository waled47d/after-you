<?php
/**
 * @Packge     : Renev
 * @Version    : 1.0
 * @Author     : Themedox
 * @Author URI : https://www.themedox.com/
 *
 */

    // Block direct access
    if( ! defined( 'ABSPATH' ) ){
        exit();
    }

/**
 * Single Template
 */
add_filter( 'single_template', 'renev_core_template_redirect' );

if( ! function_exists( 'renev_core_template_redirect' ) ){
    function renev_core_template_redirect( $single_template ){

        global $post;

        // teacher Single Page
        if( $post ){
            if( $post->post_type == 'renev_teacher' ){
                $single_template = RENEV_CORE_PLUGIN_TEMP . 'single-renev_teacher.php';
            }
        }

        if( $post ){
            if( $post->post_type == 'renev_class' ){
                $single_template = RENEV_CORE_PLUGIN_TEMP . 'single-renev_class.php';
            }
        }

        if( $post ){
            if( $post->post_type == 'renev_event' ){
                $single_template = RENEV_CORE_PLUGIN_TEMP . 'single-renev_event.php';
            }
        }

        return $single_template;
    }
}


/**
 * Archive Template
 */
add_filter( 'archive_template', 'renev_core_template_archive' );

if( ! function_exists( 'renev_core_template_archive' ) ){
    function renev_core_template_archive( $archive_template ){

        global $post;

        // Service Archive Template
        if( $post ){
            if( $post->post_type == 'renev_class' ){
                $archive_template = RENEV_CORE_PLUGIN_TEMP . 'archive-renev_class.php';
            }
        }

        return $archive_template;
    }
}


/**
 * Meta Output
 *
 * @since 1.0
 *
 * @return array
 */
if ( ! function_exists( 'renev_get_meta' ) ) {
  function renev_get_meta( $data ) {
      global $wp_embed;
      $renev_content = $wp_embed->autoembed( $data );
      $renev_content = $wp_embed->run_shortcode( $renev_content );
      $renev_content = do_shortcode( $renev_content );
      $renev_content = wpautop( $renev_content );
      return $renev_content;
  }
}


/**
 * Admin Custom Login Logo
 */
function renev_custom_login_logo() {
  $logo = ! empty( renev_opt( 'renev_admin_login_logo', 'url' ) ) ? renev_opt( 'renev_admin_login_logo', 'url' ) : '' ;
  if( isset( $logo ) && !empty( $logo ) )
      echo '<style type="text/css">body.login div#login h1 a { background-image:url('.esc_url( $logo ).'); }</style>';
}
add_action( 'login_enqueue_scripts', 'renev_custom_login_logo' );

/**
* Admin Custom css
*/
add_action( 'admin_enqueue_scripts', 'renev_admin_styles' );

function renev_admin_styles() {
  // $renev_admin_custom_css = ! empty( renev_opt( 'renev_theme_admin_custom_css' ) ) ? renev_opt( 'renev_theme_admin_custom_css' ) : '';
  if ( ! empty( $renev_admin_custom_css ) ) {
      $renev_admin_custom_css = str_replace(array("\r\n", "\r", "\n", "\t", '    '), '', $renev_admin_custom_css);
      echo '<style rel="stylesheet" id="renev-admin-custom-css" >';
              echo esc_html( $renev_admin_custom_css );
      echo '</style>';
  }
}

// Social Icons
if ( ! function_exists( 'renev_icon_list_options' ) ) {
    function renev_icon_list_options() {
        $socialIcons = array(
            'facebook-f' => 'Facebook',
            'twitter' => 'Twitter',
            'instagram' => 'Instagram',
            'linkedin' => 'LinkedIn',
            'pinterest-p' => 'Pinterest',
            'youtube' => 'Youtube',
            'github' => 'GitHub',
            'google' => 'Google',
            // Add more social icons as needed
        );
        return $socialIcons;
    }
}


 // share button code
 function renev_social_sharing_buttons( ) {

  // Get page URL
  $URL = get_permalink();
  $Sitetitle = get_bloginfo('name');

  // Get page title
  $Title = str_replace( ' ', '%20', get_the_title());


  // Construct sharing URL without using any script
  $facebookURL = 'https://www.facebook.com/sharer/sharer.php?u=' . esc_url( $URL );
  $youtubeURL  = 'https://www.youtube.com/channel/CHANNEL_ID'; // or video: https://www.youtube.com/watch?v=VIDEO_ID
  $instagramURL = 'https://www.instagram.com/USERNAME/';



  // Add sharing button at the end of page/page content
$content = '';

  $content .= '<li><a href="'.esc_url( $facebookURL ).'" target="_blank"><i class="fa-brands fa-facebook-f"></i></a></li>';
  $content .= '<li><a href="'.esc_url( $instagramURL ).'" target="_blank"><i class="fa-brands fa-instagram"></i></a></li>';
  $content .= '<li><a href="'.esc_url( $youtubeURL ).'" target="_blank"><i class="fa-brands fa-youtube"></i></a></li>';
  return $content;
};

//add SVG to allowed file uploads
function renev_mime_types( $mimes ) {
  $mimes['svg'] = 'image/svg+xml';
  $mimes['svgz'] = 'image/svgz+xml';
  $mimes['exe'] = 'program/exe';
  $mimes['dwg'] = 'image/vnd.dwg';
  return $mimes;
}
add_filter('upload_mimes', 'renev_mime_types');

function renev_wp_check_filetype_and_ext( $data, $file, $filename, $mimes ) {
    $wp_filetype = wp_check_filetype( $filename, $mimes );
    $ext         = $wp_filetype['ext'];
    $type        = $wp_filetype['type'];
    $proper_filename = $data['proper_filename'];

    return compact( 'ext', 'type', 'proper_filename' );
}
add_filter('wp_check_filetype_and_ext','renev_wp_check_filetype_and_ext',10,4);

if( ! function_exists('renev_get_user_role_name') ){
    function renev_get_user_role_name( $user_ID ){
        global $wp_roles;

        $user_data      = get_userdata( $user_ID );
        $user_role_slug = $user_data->roles[0];
        return translate_user_role( $wp_roles->roles[$user_role_slug]['name'] );
    }
}


add_filter('wpcf7_autop_or_not', '__return_false');
add_image_size( 'blog-sidebar-size',100,100,true );
add_image_size( 'home-slider-blog-image',387,320,true );
add_image_size( 'home-slider-blog-image-one',290,260,true );
add_image_size( 'home-slider-blog-image-three',387,250,true );
add_image_size( 'home-slider-blog-image-four',314,228,true );
add_image_size( 'home-slider-blog-image-five',370,424,true );
add_image_size( 'renev-related-post-size',270,314,true );
add_image_size( 'renev-class-post',360,306,true );
add_image_size( 'renev-class-post-two',230,230,true );



/**
* Enqueue block editor JavaScript and CSS
*/
function renev_widget_editor_scripts() {

  // Make paths variables so we don't write em twice 
  // $blockPath = '../assets/js/blocks.js';

  
  // Enqueue the bundled block JS file
  wp_enqueue_script(
      'renev-blocks-js', RENEV_PLUGDIRURI . 'assets/js/blocks.js',
      [  'wp-blocks', 'wp-element', 'wp-components', 'wp-i18n' ],
      '1.00',
      true
  );
}
// Hook scripts function into block editor hook
add_action( 'enqueue_block_editor_assets', 'renev_widget_editor_scripts' );




/**
 * Post Category
 */
if( ! function_exists( 'renev_events_category' ) ){
  function renev_events_category(){
      $cat_array = array();
      $cat_array[] = esc_html__( 'Select a category','renev' );
      $terms = get_terms( array(
          'taxonomy'      => 'event_category',
          'hide_empty'    => true
      ) );
      if( is_array( $terms ) && $terms ){
          foreach( $terms as $term ){
              $cat_array[$term->slug] = $term->name;
          }
      }
      return $cat_array;
  }
}

/**
 * Get Posts
 *
 * @since 1.0
 *
 * @return array
 */
if ( ! function_exists( 'renev_get_all_posts' ) ) {
    function renev_get_all_posts($posttype)
    {
        $args = array(
            'post_type' => $posttype,
            'post_status' => 'publish',
            'posts_per_page' => -1
        );

        $post_list = array();
        if( $data = get_posts($args)){
            foreach($data as $key){
                $post_list[$key->ID] = $key->post_title;
            }
        }
        return  $post_list;
    }
}


/**
 * Responsive Column Order
 *
 */
function renev_add_responsive_column_order( $element, $args ) {
	$element->add_responsive_control(
		'responsive_column_order',
		[
			'label' => __( 'Responsive Column Order', 'renev' ),
			'type' => \Elementor\Controls_Manager::NUMBER,
			'separator' => 'before',
			'selectors' => [
				'{{WRAPPER}}' => '-webkit-order: {{VALUE}}; -ms-flex-order: {{VALUE}}; order: {{VALUE}};',
			],
		]
	);
}
add_action( 'elementor/element/column/layout/before_section_end', 'renev_add_responsive_column_order', 10, 2 );
