<?php
/**
 * Button Widget.
 *
 *
 * @since 1.0.0
 */
namespace Elementor;
use Elementor\Controls_Manager;
use Elementor\Group_Control_Border;
use Elementor\Group_Control_Box_Shadow;
use Elementor\Group_Control_Typography;
use Elementor\Widget_Base;
use Elementor\Group_Control_Background;
use Elementor\Group_Control_Css_Filter;
use Elementor\Icons_Manager;
use Elementor\Utils;
use Elementor\Repeater;
use Elementor\URL;

if (!defined('ABSPATH')) {
    exit;
}
// If this file is called directly, abort.
class RenevButton extends Widget_Base {
    public function get_name() {
        return 'renev-button';
    }
    public function get_title() {
        return __('Renev Button', 'renev');
    }
    public function get_icon() {
        return ('eicon-person');
    }
    public function get_categories() {
        return ['renev-addons'];
    }
    public function get_keywords() {
        return ['Button'];
    }

    protected function register_controls() {

        $this->start_controls_section(
            'content_section',
            [
                'label' => __('Content', 'renev'),
                'tab'   => Controls_Manager::TAB_CONTENT,
            ]
        );
        $this->add_control(
            'button_layout',
            [
                'label' => esc_html__('Select Layout', 'renev'),
                'type' => Controls_Manager::SELECT,
                'options' => [
                    'layout-1' => esc_html__('Layout 1', 'renev'),
                    'layout-2' => esc_html__('Layout 2', 'renev'),
                ],
                'default' => 'layout-1',
            ]
        );
        $this->end_controls_section();
        
        $this->start_controls_section('general_section',
            [
                'label' => __('Button', 'renev'),
                'tab'   => Controls_Manager::TAB_CONTENT,
            ]
        );
     
        $this->add_control(
            'circle-img',
            [
                'label'   => __( 'Cilcle Img', 'renev' ),
                'type'    => Controls_Manager::MEDIA,
                'default' => [
                    
                ],
                'condition' => [
                    'button_layout' => 'layout-2',
                ],
            ]
        );
        $this->add_control(
            'btn_text',
            [
                'label' => esc_html__('Button Text', 'renev'),
                'type' => Controls_Manager::TEXT,
                'default' => esc_html__('Schedule a Consultation', 'renev'),
                'label_block' => true,
            ]
        );
        $this->add_control(
            'btn_link',
            [
                'label' => esc_html__('Button Url', 'renev'),
                'type' => Controls_Manager::URL,
                'default' => [
                    'url' => '#',
                ],
                'label_block' => true,
            ]
        );
       
        $this->end_controls_section();

        // button 01
        $this->start_controls_section(
            'renev_butto1',
            [
                'label' => __( 'Button', 'renev' ),
                'tab'   => Controls_Manager::TAB_STYLE,
                'condition' => [
                    'button_layout' => 'layout-1',
                ],
            ]
        );
        // Button Normal part
        $this->start_controls_tabs(
            'style_tabs'
        );
        $this->start_controls_tab(
            '2',
            [
                'label' => esc_html__( 'Normal', 'renev' ),
            ]
        );
        $this->add_responsive_control(
            'normar_button1_width',
            [
                'label'          => __('Width', 'renev'),
                'type'           => Controls_Manager::SLIDER,
                'size_units'     => ['%', 'px','vw'],
                'range'          => [
                    '%'  => [
                        'min' => 1,
                        'max' => 100,
                    ],
                    'px' => [
                        'min' => 1,
                        'max' => 1000,
                    ],
                    'vw' => [
                        'min' => 1,
                        'max' => 100,
                    ],
                ],
                'selectors'      => [
                    '{{WRAPPER}} .btn-three' => 'width: {{SIZE}}{{UNIT}};',
                ],
            ]
        );
        $this->add_group_control(
            Group_Control_Background::get_type(),
            [
                'name' => 'normar_button1_background',
                'label' => __( 'Background', 'renev' ),
                'types' => [ 'classic', 'gradient', 'video' ],
                'selector' => '{{WRAPPER}} .vl-btn1',
            ]
        );
        $this->add_control(
            'button1-normal_text_color',
            [
                'label' => __( 'Text Color', 'renev' ),
                'type' => Controls_Manager::COLOR,
                'selectors' => [
                    '{{WRAPPER}} .vl-btn1' => 'color: {{VALUE}}',
                ],
            ]
        );
        $this->add_group_control(
            Group_Control_Typography::get_type(),
            [
                'name' => 'normal-button1_typography',
                'selector' => '{{WRAPPER}} .vl-btn1',
            ]
        );
        $this->add_group_control(
            Group_Control_Border::get_type(),
            [
                'name' => 'normal-button1_border',
                'selector' => '{{WRAPPER}} .vl-btn1::before',
            ]
        );
        $this->add_control(
            'Normal_button1_border_radius',
            [
                'label' => esc_html__( 'Border Radius', 'renev' ),
                'type' => Controls_Manager::DIMENSIONS,
                'size_units' => [ 'px', '%', 'em', 'rem', 'custom' ],
                'selectors' => [
                    '{{WRAPPER}} .vl-btn1' => 'border-radius: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
    
                ],
            ]
        );
        $this->add_responsive_control(
            'normal_button1_padding',
            [
                'label' => __( 'Padding', 'renev' ),
                'type' => Controls_Manager::DIMENSIONS,
                'size_units' => [ 'px', 'em', '%' ],
                'selectors' => [
                    '{{WRAPPER}} .vl-btn1' => 'padding: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
                ],
            ]
        );
        $this->end_controls_tab();

        // Button Hover part in here 
        $this->start_controls_tab(
            'style_hover_tabss',
            [
                'label' => esc_html__( 'Hover', 'renev' ),
            ]
        );
        $this->add_control(
            'button1_hover_background',
            [
                'label' => __( 'Background Hover', 'renev' ),
                'type' => Controls_Manager::COLOR,
                'selectors' => [
                    '{{WRAPPER}} .vl-btn1::after' => 'background: {{VALUE}}',
                ],
            ]
        );        
        $this->add_control(
            'button1_hover_text_color',
            [
                'label' => __( 'Text Color', 'renev' ),
                'type' => Controls_Manager::COLOR,
                'selectors' => [
                    '{{WRAPPER}} .vl-btn1:hover' => 'color: {{VALUE}} !important', 
                ],
            ]
        );
        $this->add_group_control(
            Group_Control_Border::get_type(),
            [
                'name' => 'normal-button1_hove_border',
                'selector' => '{{WRAPPER}} .vl-btn1:hover::before',
            ]
        );
        $this->end_controls_tabs();
        $this->end_controls_section();

          //Circle Button Sytle
        $this->start_controls_section(
        'circle_button_style',
            [
                'label' => __( 'Circle Button', 'renev' ),
                'tab' => Controls_Manager::TAB_STYLE,
                'condition' => [
                    'button_layout' => 'layout-2',
                ],
            ]
        );
        $this->add_responsive_control(
            'circle_image_max_width', 
            [
                'label' => esc_html__( 'Circle Image Max Width', 'renev' ),
                'type' => Controls_Manager::SLIDER,
                'size_units' => [ 'px', '%', 'em', 'rem', 'custom' ],
                'range' => [
                    'px' => [
                        'min' => 0,
                        'max' => 1000,
                        'step' => 1,
                    ],
                    '%' => [
                        'min' => 0,
                        'max' => 100,
                    ],
                ],
                'selectors' => [
                    '{{WRAPPER}} .started-btn img' => 'max-width: {{SIZE}}{{UNIT}};',
                ],
            ]
        );
        $this->add_responsive_control(
            'circle_button_arrow_width',
            [
                'label' => esc_html__( 'Circle Arrow Width', 'renev' ),
                'type' => Controls_Manager::SLIDER,
                'size_units' => [ 'px', '%', 'em', 'rem', 'custom' ],
                'range' => [
                    'px' => [
                        'min' => 0,
                        'max' => 1000,
                        'step' => 1,
                    ],
                    '%' => [
                        'min' => 0,
                        'max' => 100,
                    ],
                ],
                'selectors' => [
                    '{{WRAPPER}} .started-btn a span' => 'width: {{SIZE}}{{UNIT}};',
                ],
            ]
        );
        $this->add_responsive_control(
            'circle_button_arrow_heighe',
            [
                'label' => esc_html__( 'circle Arrow Height', 'renev' ),
                'type' => Controls_Manager::SLIDER,
                'size_units' => [ 'px', '%', 'em', 'rem', 'custom' ],
                'range' => [
                    'px' => [
                        'min' => 0,
                        'max' => 1000,
                        'step' => 1,
                    ],
                    '%' => [
                        'min' => 0,
                        'max' => 100,
                    ],
                ],
                'selectors' => [
                    '{{WRAPPER}} .started-btn a span' => 'height: {{SIZE}}{{UNIT}};',
                ],
            ]
        );
        $this->add_control(
            'circle_arrow_background',
            [
                'label' => __( 'Circle Arrow Background', 'renev' ),
                'type' => Controls_Manager::COLOR,
                'selectors' => [
                    '{{WRAPPER}}  .started-btn a span' => 'background: {{VALUE}};',
                ],
            ]
        );
        $this->add_control(
            'circle_arrow_color',
            [
                'label' => __( 'Circle Arrow Color', 'renev' ),
                'type' => Controls_Manager::COLOR,
                'selectors' => [
                    '{{WRAPPER}} .started-btn a span' => 'color: {{VALUE}};',
                ],
            ]
        );
        $this->add_responsive_control(
            'circle_arrow_radius',
            [
                'label'         => __( 'Arrow Radius', 'renev' ),
                'type'          => Controls_Manager::DIMENSIONS,
                'size_units'    => [ 'px', '%', 'em' ],
                'selectors'     => [
                    '{{WRAPPER}} .started-btn a span' => 'border-radius: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
                ],
            ]
        );
        //Circle Button Text Style
        $this->add_control(
            'circle_button_text_color',
            [
                'label' => __( 'Circle Text Color', 'renev' ),
                'type' => Controls_Manager::COLOR,
                'selectors' => [
                    '{{WRAPPER}} .started-btn a' => 'color: {{VALUE}};',
                ],
            ]
        );
        $this->add_group_control(
            Group_Control_Typography::get_type(),
            [
                'name' => 'circle_button_text_typography',
                'label' => __( 'Typography', 'renev' ),
                'selector' => '{{WRAPPER}} .started-btn a',
            ]
        );
        $this->end_controls_section();

    }

    protected function render() {
        $settings = $this->get_settings_for_display();
        $target = isset($settings['btn_link']['is_external']) && $settings['btn_link']['is_external'] ? 'target="_blank"' : '';
		$nofollow = isset($settings['btn_link']['nofollow']) ? ' rel="nofollow"' : '';
        $layout = $settings['button_layout'];

        ?>
            <?php
                if ( $layout) {
                    include('button/'.$layout.'.php');
                }
            ?> 
        <?php
    }
}
$widgets_manager->register(new \Elementor\RenevButton());