=== Renev ===
Contributors: mthemeus
Requires at least: 5.6
Tested up to: 5.8
Requires PHP: 7.4
Stable tag: 1.0.0
License: GNU General Public License v2 or later
License URI: https://www.gnu.org/licenses/gpl-2.0.html

== Description ==
Renev Business & Finance WordPress Theme is a modern, professional, and fully responsive solution designed for businesses, financial institutions, and consulting firms. Whether you’re a financial advisor, accountant, or corporate service provider, this template offers all the essential features needed to build a robust online presence.

Features include:
- Fully responsive design to ensure your site looks great on all devices
- Easy-to-use customizer for real-time changes
- Pre-built demo layouts that you can import with a single click
- Custom post types for projects and testimonials
- Built-in support for popular plugins such as Elementor and WooCommerce
- Optimized for SEO to help you rank higher in search engines

Whether you're building a website for a businesses, financial institutions, and consulting firms. Whether you’re a financial advisor, accountant, or corporate service provider, this template offers all the essential features needed to build a robust online presence.

For support  please knock [mailto:wpsakib@gmail.com](wpsakib@gmail.com).

== Installation ==
1. Download the theme zip file.
2. Upload the zip file via the WordPress admin panel under Appearance > Themes > Add New > Upload Theme.
3. Activate the theme.

== Changelog ==
= 1.0.0 =
* Initial release.
