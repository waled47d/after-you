<?php
/**
 * @Packge     : Renev
 * @Version    : 1.0
 * @Author     : Mthemeus
 * @Author URI : https://www.mthemeus.com/
 *
 */

// Block direct access
if ( ! defined( 'ABSPATH' ) ) {
    exit;
}
    /**
    *
    * Hook for Footer Content
    *
    * Hook renev_footer_content
    *
    * @Hooked renev_footer_content_cb 10
    *
    */
    do_action( 'renev_footer_content' );

    if( !is_404(  ) ) {
        /**
        *
        * Hook for Back to Top Button
        *
        * Hook renev_back_to_top
        *
        * @Hooked renev_back_to_top_cb 10
        *
        */
        do_action( 'renev_back_to_top' );
    }

    wp_footer();
    ?>
</body>
</html>