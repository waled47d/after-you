<?php
/**
 * Counter Widget.
 *
 *
 * @since 1.0.0
 */
namespace Elementor;
use Elementor\Controls_Manager;
use Elementor\Group_Control_Border;
use Elementor\Group_Control_Box_Shadow;
use Elementor\Group_Control_Typography;
use Elementor\Widget_Base;
use Elementor\Group_Control_Background;
use Elementor\Group_Control_Css_Filter;
use Elementor\Icons_Manager;
use Elementor\Utils;
use Elementor\Repeater;
use Elementor\URL;
use \Elementor\Control_Media;

if (!defined('ABSPATH')) {
    exit;
}
// If this file is called directly, abort.
class RenevCounter extends Widget_Base {
    public function get_name() {
        return 'renev-counter';
    }
    public function get_title() {
        return __('Counter', 'renev');
    }
    public function get_icon() {
        return ('eicon-person');
    }
    public function get_categories() {
        return ['renev-addons'];
    }
    public function get_keywords() {
        return ['counter', 'number'];
    }

    protected function register_controls() {

        // layout Panel
        $this->start_controls_section(
            'renev_counter',
            [
                'label' => esc_html__('Content', 'renev'),
            ]
        );
        $this->add_control(
            'counter_layout',
            [
                'label' => esc_html__('Select Layout', 'renev'),
                'type' => Controls_Manager::SELECT,
                'options' => [
                    'layout-1' => esc_html__('Layout 1', 'renev'),
                    'layout-2' => esc_html__('Layout 2', 'renev'),
                ],
                'default' => 'layout-1',
            ]
        );

        $counter = new Repeater();

        $counter->add_control(
			'counter_number',
			[
				'label' => esc_html__( 'Number', 'renev' ),
				'type' => Controls_Manager::TEXT,
				'default' => esc_html__( '35', 'renev' ),
				'label_block' => true,
			]
		);
        $counter->add_control(
			'counter_suffix',
			[
				'label' => esc_html__( 'Suffix', 'renev' ),
				'type' => Controls_Manager::TEXT,
				'default' => esc_html__( '+', 'renev' ),
				'label_block' => true,
			]
		);
        $counter->add_control(
			'counter_title',
			[
				'label' => esc_html__( 'Title', 'renev' ),
				'type' => Controls_Manager::TEXTAREA,
				'default' => esc_html__( 'Years of Experience', 'renev' ),
				'label_block' => true,
                'description' => 'For Not layout 3',
			]
		);
        $this->add_control(
			'counter_lists',
			[
				'label' => esc_html__( 'Counter Box', 'renev' ),
				'type' =>  Controls_Manager::REPEATER,
				'fields' =>  $counter->get_controls(),
			]
		);
        $this->end_controls_section();

        // Counter Box style
        $this->start_controls_section(
            'counter_box_style',
            [
                'label' => __( 'Counter Box', 'renev' ),
                'tab'   => Controls_Manager::TAB_STYLE,
                'condition' => [
                    'counter_layout' => 'layout-2',
                ]
            ]
        );
        $this->add_control(
            'counter_box_background',
            [
                'label' => __( 'Box Background', 'renev' ),
                'type' => Controls_Manager::COLOR,
                'selectors' => [
                    '{{WRAPPER}} .counter-section-area .counter-box' => 'background: {{VALUE}}',
                ],
            ]
        );
        $this->add_control(
            'counter_box__hover_background',
            [
                'label' => __( 'Box Hover Background', 'renev' ),
                'type' => Controls_Manager::COLOR,
                'selectors' => [
                    '{{WRAPPER}} .counter-section-area .counter-box:hover' => 'background: {{VALUE}}',
                ],
            ]
        );
        $this->add_control(
            'counter_box_border_radius',
            [
                'label' => esc_html__( 'Border Radius', 'renev' ),
                'type' => Controls_Manager::DIMENSIONS,
                'size_units' => [ 'px', '%', 'em', 'rem', 'custom' ],
                'selectors' => [
                    '{{WRAPPER}} .counter-section-area .counter-box' => 'border-radius: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
                ],
            ]
        );
        $this->add_responsive_control(
            'counter_box_padding',
            [
                'label' => __( 'Padding', 'renev' ),
                'type' => Controls_Manager::DIMENSIONS,
                'size_units' => [ 'px', 'em', '%' ],
                'selectors' => [
                    '{{WRAPPER}} .counter-section-area .counter-box' => 'padding: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
                ],
            ]
        );
        $this->end_controls_section();

        // Counter Number Style
         $this->start_controls_section(
            'counter_number_style',
            [
                'label' => __( 'Number', 'renev' ),
                'tab' => Controls_Manager::TAB_STYLE,
            ]
        );
        $this->add_control(
            'counter_number_color',
            [
                'label' => __( 'Number Color', 'renev' ),
                'type' => Controls_Manager::COLOR,
                'selectors' => [
                    '{{WRAPPER}} .counter-boxarea .counter-box h2' => 'color: {{VALUE}};',
                    '{{WRAPPER}} .counter-section-area .counter-box h2' => 'color: {{VALUE}};',
                ],
                
            ]
        );
        $this->add_control(
            'counter_number_hover_color',
            [
                'label' => __( 'Number Hover Color', 'renev' ),
                'type' => Controls_Manager::COLOR,
                'selectors' => [
                    '{{WRAPPER}} .counter-section-area .counter-box:hover h2' => 'color: {{VALUE}};',
                ],
                'condition' => [
                    'counter_layout' => 'layout-2',
                ] 
            ]
        );
        $this->add_group_control(
            Group_Control_Typography::get_type(),
            [
                'name' => 'counter_number_typography',
                'label' => __( 'Number Typography', 'renev' ),
                'selector' => '{{WRAPPER}} .counter-boxarea .counter-box h2, {{WRAPPER}} .counter-section-area .counter-box h2',
            ]
        );
        $this->add_control(
            'counter_number_margin',
            [
                'label'      => __( 'Number Margin', 'renev' ),
                'type'       => Controls_Manager::DIMENSIONS,
                'size_units' => [ 'px', '%', 'em' ],
                'selectors'  => [
                    '{{WRAPPER}} .counter-boxarea .counter-box h2 span' => 'margin: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
                    '{{WRAPPER}} .counter-section-area .counter-box h2 span' => 'margin: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
                ],
            ]
        );    
        $this->end_controls_section();

        // Counter Title Style
        $this->start_controls_section(
            'counter_title_style',
            [
                'label' => __( 'Counter Title', 'renev' ),
                'tab' => Controls_Manager::TAB_STYLE,
            ]
        );
        $this->add_control(
            'counter_title_color',
            [
                'label' => __( 'Color', 'renev' ),
                'type' => Controls_Manager::COLOR,
                'selectors' => [
                    '{{WRAPPER}} .counter-boxarea .counter-box p' => 'color: {{VALUE}};',
                    '{{WRAPPER}} .counter-section-area .counter-box p' => 'color: {{VALUE}};',
                ],
            ]
        );
        $this->add_control(
            'counter_title_hover_color',
            [
                'label' => __( 'Hover Color', 'renev' ),
                'type' => Controls_Manager::COLOR,
                'selectors' => [
                    '{{WRAPPER}} .counter-section-area .counter-box:hover p' => 'color: {{VALUE}};',
                ],
                'condition' => [
                    'counter_layout' => 'layout-2',
                ] 
            ]
        );
        $this->add_group_control(
            Group_Control_Typography::get_type(),
            [
                'name' => 'counter_title_typography',
                'label' => __( 'Typography', 'renev' ),
                'selector' => '{{WRAPPER}} .counter-boxarea .counter-box p, {{WRAPPER}} .counter-section-area .counter-box p',
            ]
        );
        $this->add_control(
            'counter_title_margin',
            [
                'label'      => __( 'Margin', 'renev' ),
                'type'       => Controls_Manager::DIMENSIONS,
                'size_units' => [ 'px', '%', 'em' ],
                'selectors'  => [
                    '{{WRAPPER}} .counter-boxarea .counter-box p' => 'margin: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
                    '{{WRAPPER}} .counter-section-area .counter-box p' => 'margin: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
                ],
            ]
        );    
        $this->end_controls_section();

    }

    protected function render() {
        $settings = $this->get_settings_for_display(); 
        $layout = $settings['counter_layout'];
        $counter_list = $settings['counter_lists'];

        ?> 
            <?php
                if ( $layout) {
                    include('counter/'.$layout.'.php');
                }
            ?>
        <?php
    }
}
$widgets_manager->register(new \Elementor\RenevCounter());

