<div class="circle">
    <div class="arrow">
        <a href="<?php echo esc_url($settings['arrow_link']['url']); ?>">
            <img src="<?php echo esc_url( $settings['circle_icon_img']['url'] ); ?>" alt="" class="keyframe5">
            <img src="<?php echo esc_url( $settings['circle_arrow']['url'] ); ?>" alt="" class="arrow1">
        </a>
    </div>
</div>