<?php
if (!defined('ABSPATH')) {
  exit; // Exit if accessed directly.
}
class Renev_Recent_Posts_Widget extends WP_Widget
{
  /**
   * To create the example widget all four methods will be
   * nested inside this single instance of the WP_Widget class.
   **/

  public function __construct()
  {
    $widget_options = array(
      'classname' => 'renev_recent_posts_Widget',
      'description' => 'This widget will show latest post with thumbnail.',
    );
    parent::__construct('renev_recent_posts_Widget', 'Renev Recent Posts', $widget_options);
  }


  public function widget($args, $instance)
  {
    $title = apply_filters('td-blog-sidebar-title mb-30', $instance['title']);
    $show_date = apply_filters('widget_show_date', $instance['show_date']);
    $ppp = (!empty($instance['ppp']) ? $instance['ppp'] : -1);

    echo $args['before_widget'] . $args['before_title'] . esc_html($title) . $args['after_title'];

    $query_args = array(
      'post_type' => 'post',
      'posts_per_page' => $ppp,
    );

    $query = new WP_Query($query_args);

    ?>
      <?php
      if ($query->have_posts()) {
          while ($query->have_posts()) {
            $query->the_post(); ?>
            
            <div class="rc-post-item">
              <?php
                if (has_post_thumbnail()) :
                  $thumb_id = get_post_thumbnail_id(get_the_ID());
                  $img = wp_get_attachment_image_src($thumb_id, 'renev-blog-widget-thumb');
              ?>
                <div class="img1">
                  <img src="<?php echo esc_url($img[0]); ?>" alt="<?php echo esc_attr(get_the_title()); ?>" />
                </div>
                <div class="space24"></div>
              <?php endif; ?>

              <div class="content-area">
                <?php if ($show_date) : ?>
                  <ul>
                    <li>
                      <a href="<?php echo get_day_link(get_the_date('Y'), get_the_date('m'), get_the_date('d')); ?>">
                        <svg xmlns="http://www.w3.org/2000/svg" width="20" height="20" viewBox="0 0 20 20" fill="none"><g clip-path="url(#clip0_91_5623)"><path d="M5.673 0C5.85865 0 6.0367 0.0737498 6.16797 0.205025C6.29925 0.336301 6.373 0.514348 6.373 0.7V2.009H13.89V0.709C13.89 0.523348 13.9637 0.345301 14.095 0.214025C14.2263 0.0827498 14.4043 0.009 14.59 0.009C14.7757 0.009 14.9537 0.0827498 15.085 0.214025C15.2162 0.345301 15.29 0.523348 15.29 0.709V2.009H18C18.5303 2.009 19.0388 2.21958 19.4139 2.59443C19.7889 2.96929 19.9997 3.47774 20 4.008V18.001C19.9997 18.5313 19.7889 19.0397 19.4139 19.4146C19.0388 19.7894 18.5303 20 18 20H2C1.46974 20 0.961184 19.7894 0.58614 19.4146C0.211096 19.0397 0.00026513 18.5313 0 18.001L0 4.008C0.00026513 3.47774 0.211096 2.96929 0.58614 2.59443C0.961184 2.21958 1.46974 2.009 2 2.009H4.973V0.699C4.97327 0.513522 5.04713 0.335731 5.17838 0.204672C5.30963 0.0736123 5.48752 -1.89263e-07 5.673 0ZM1.4 7.742V18.001C1.4 18.0798 1.41552 18.1578 1.44567 18.2306C1.47583 18.3034 1.52002 18.3695 1.57574 18.4253C1.63145 18.481 1.69759 18.5252 1.77039 18.5553C1.84319 18.5855 1.92121 18.601 2 18.601H18C18.0788 18.601 18.1568 18.5855 18.2296 18.5553C18.3024 18.5252 18.3685 18.481 18.4243 18.4253C18.48 18.3695 18.5242 18.3034 18.5543 18.2306C18.5845 18.1578 18.6 18.0798 18.6 18.001V7.756L1.4 7.742ZM6.667 14.619V16.285H5V14.619H6.667ZM10.833 14.619V16.285H9.167V14.619H10.833ZM15 14.619V16.285H13.333V14.619H15ZM6.667 10.642V12.308H5V10.642H6.667ZM10.833 10.642V12.308H9.167V10.642H10.833ZM15 10.642V12.308H13.333V10.642H15ZM4.973 3.408H2C1.92121 3.408 1.84319 3.42352 1.77039 3.45367C1.69759 3.48382 1.63145 3.52802 1.57574 3.58374C1.52002 3.63945 1.47583 3.70559 1.44567 3.77839C1.41552 3.85119 1.4 3.92921 1.4 4.008V6.343L18.6 6.357V4.008C18.6 3.92921 18.5845 3.85119 18.5543 3.77839C18.5242 3.70559 18.48 3.63945 18.4243 3.58374C18.3685 3.52802 18.3024 3.48382 18.2296 3.45367C18.1568 3.42352 18.0788 3.408 18 3.408H15.29V4.337C15.29 4.52265 15.2162 4.7007 15.085 4.83197C14.9537 4.96325 14.7757 5.037 14.59 5.037C14.4043 5.037 14.2263 4.96325 14.095 4.83197C13.9637 4.7007 13.89 4.52265 13.89 4.337V3.408H6.373V4.328C6.373 4.51365 6.29925 4.6917 6.16797 4.82297C6.0367 4.95425 5.85865 5.028 5.673 5.028C5.48735 5.028 5.3093 4.95425 5.17803 4.82297C5.04675 4.6917 4.973 4.51365 4.973 4.328V3.408Z" fill="white"></path></g><defs><clipPath id="clip0_91_5623"><rect width="20" height="20" fill="white"></rect></clipPath></defs></svg>
                        <?php echo get_the_date('j F Y'); ?>
                      </a>
                    </li>
                  </ul>
                <?php endif; ?>

                <div class="space14"></div>

                <a href="<?php the_permalink(); ?>">
                  <?php echo implode(' ', array_slice(explode(' ', get_the_title()), 0, 10)); ?>
                </a>

                <div class="space20"></div>

                <a href="<?php the_permalink(); ?>" class="readmore">
                  <?php echo esc_html( 'Learn More', 'renev' ); ?>
                  <i class="fa-solid fa-arrow-right"></i>
                </a>

              </div>
            </div>
          <?php
      }
      wp_reset_postdata();
    }
    ?><?php

    echo $args['after_widget'];
  }

  public function form($instance)
  {
    $title = !empty($instance['title']) ? $instance['title'] : '';
    $show_date = !empty($instance['show_date']) ? $instance['show_date'] : '';
    $ppp = !empty($instance['$ppp']) ? $instance['$ppp'] : 5;

    ?>
    <p>
      <label for="<?php echo esc_attr($this->get_field_id('title')); ?>"><?php esc_html_e('Title:', 'renev'); ?></label>
      <input type="text" class="widefat" id="<?php echo esc_attr($this->get_field_id('title')); ?>" name="<?php echo esc_attr($this->get_field_name('title')); ?>" value="<?php echo esc_attr($title); ?>" />
    </p>

    <p>
      <label for="<?php echo esc_attr($this->get_field_id('show_date')); ?>"><?php esc_html_e('Display Post Date?', 'renev'); ?></label>
      <input type="checkbox" id="<?php echo esc_attr($this->get_field_id('show_date')) ?>" name="<?php echo esc_attr($this->get_field_name('show_date')) ?>" <?php if ($show_date == 'on') { echo ' checked'; } ?>>
    </p>

    <p>
      <label for="<?php echo esc_attr($this->get_field_id('ppp')); ?>"><?php esc_html_e('Post per page:', 'renev'); ?></label>
      <input type="text" class="widefat" id="<?php echo esc_attr($this->get_field_id('ppp')); ?>" name="<?php echo esc_attr($this->get_field_name('ppp')); ?>" value="<?php echo esc_attr($ppp); ?>" />
    </p>

<?php
  }
  public function update($new_instance, $old_instance)
  {
    $instance = $old_instance;
    $instance['title'] = strip_tags($new_instance['title']);
    $instance['ppp'] = strip_tags($new_instance['ppp']);
    $instance['show_date'] = strip_tags($new_instance['show_date']);
    return $instance;
  }
}





function renev_plugin_widget_reg()
{
  register_widget('Renev_Recent_Posts_Widget');
}
add_action('widgets_init', 'renev_plugin_widget_reg');

?>