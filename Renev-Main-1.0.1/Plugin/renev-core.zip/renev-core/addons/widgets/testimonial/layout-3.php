<div class="testimonial-slider-box owl-carousel">
    <?php foreach ( $testimonial_items as $item ): ?>
        <div class="testimonial-boxarea">
            <ul>
                <?php for ( $i = 0; $i < 5; $i++ ): ?>
                    <li><i class="fa-solid fa-star"></i></li>
                <?php endfor; ?>
            </ul>
            <p><?php echo esc_html( $item['testimonial_description'] ); ?></p>
            <div class="names-area">
                <div class="man-textarea">
                    <div class="man">
                        <img src="<?php echo esc_url( $item['testimonial_author_img']['url'] ); ?>" alt="">
                    </div>
                    <div class="text">
                        <a><?php echo esc_html( $item['testimonial_author_name'] ); ?></a>
                        <p><?php echo esc_html( $item['testimonial_card_desig'] ); ?></p>
                    </div>
                </div>
                <img src="<?php echo esc_url( $item['testimonial_brand_img']['url'] ); ?>" alt="" class="elements20">
            </div>
        </div>
    <?php endforeach; ?>
</div>
