<?php
use \Elementor\Widget_Base;
use \Elementor\Controls_Manager;
use \Elementor\Icons_Manager;
use \Elementor\Group_Control_Typography;
use \Elementor\Group_Control_Border;
use \Elementor\Group_Control_Box_Shadow;
use \Elementor\Repeater;
use \Elementor\Utils;
use \Elementor\Group_Control_Background;

/**
 *
 * Blog Widget .
 *
 */
class Renev_Blog extends Widget_Base {

	public function get_name() {
		return 'renev_blog';
	}

	public function get_title() {
		return __( 'Renev Blog', 'renev' );
	}

	public function get_icon() {
		return 'eicon-code';
    }

	public function get_categories() {
		return [ 'renev' ];
	}

	protected function register_controls() {

        // Blog
        $this->start_controls_section('blog_section',
            [
                'label' => __('Blog', 'renev'),
                'tab'   => Controls_Manager::TAB_CONTENT,
            ]
        );
        $this->add_control(
            'blog_layout',
            [
                'label' => esc_html__('Select Layout', 'renev'),
                'type' => Controls_Manager::SELECT,
                'options' => [
                    'layout-1' => esc_html__('Layout 1', 'renev'),
                    'layout-2' => esc_html__('Layout 2', 'renev'),
                ],
                'default' => 'layout-1',
            ]
        );
        $this->add_control(
            'blog_per_page',
            [
                'label'       => __('Numbar Of Post', 'renev'),
                'type'        => Controls_Manager::NUMBER,
                'default'     => '',
                'description' => 'use empty value show all posts',
            ]
        );
		$this->add_control(
            'post_by',
            [
                'label' => __('Post By:', 'renev'),
                'type' => Controls_Manager::SELECT,
                'default' => 'latest',
                'label_block' => true,
                'options' => array(
                    'latest'   =>   __('Latest Post', 'renev'),
                    'selected' =>   __('Selected posts', 'renev'),
                ),
            ]
        );
        $this->add_control(
            'post__in',
            [
                'label' => __('Post In', 'renev'),
                'type' => Controls_Manager::SELECT2,
                'options' => renev_get_all_posts('post'),
                'multiple' => true,
                'label_block' => true,
                'condition'   => [
					'post_by' => 'selected',
				]
            ]
        );
        $this->add_control(
            'orderby',
            [
                'label' => __('Order By', 'renev'),
                'type' => Controls_Manager::SELECT,
                'options' => renev_get_post_orderby_options(),
                'default' => 'date',
                'label_block' => true,

            ]
        );
        $this->add_control(
            'order',
            [
                'label' => __('Order', 'renev'),
                'type' => Controls_Manager::SELECT,
                'options' => [
                    'asc' => 'Ascending',
                    'desc' => 'Descending',
                ],
                'default' => 'desc',
                'label_block' => true,
            ]
        );
        $this->add_control(
            'show_pagination',
            [
                'label' => __( 'Show Pagination', 'renev' ),
                'type' => \Elementor\Controls_Manager::SWITCHER,
                'label_on' => __( 'Show', 'renev' ),
                'label_off' => __( 'Hide', 'renev' ),
                'return_value' => 'yes',
                'default' => '',
                'condition' => [
                    'blog_layout' => 'layout-1',
                ]
            ]
        );
        $this->end_controls_section();

        // Blog Content
		$this->start_controls_section(
			'blog_content',
			[
				'label' 	=> __( 'Blog Content', 'renev' ),
				'tab' 		=> Controls_Manager::TAB_CONTENT,
			]
        );
        $this->add_control(
            'show_image',
            [
                'label' => __( 'Show Image', 'renev' ),
                'type' => \Elementor\Controls_Manager::SWITCHER,
                'label_on' => __( 'Show', 'renev' ),
                'label_off' => __( 'Hide', 'renev' ),
                'return_value' => 'yes',
                'default' => 'yes',
            ]
        );
		$this->add_control(
            'show_date',
            [
                'label' => __( 'Date?', 'renev' ),
                'type' => \Elementor\Controls_Manager::SWITCHER,
                'label_on' => __( 'Show', 'renev' ),
                'label_off' => __( 'Hide', 'renev' ),
                'return_value' => 'yes',
                'default' => 'yes',
            ]
        );
        $this->add_control(
            'show_category',
            [
                'label' => __( 'Show Category', 'renev' ),
                'type' => \Elementor\Controls_Manager::SWITCHER,
                'label_on' => __( 'Show', 'renev' ),
                'label_off' => __( 'Hide', 'renev' ),
                'return_value' => 'yes',
                'default' => 'yes',
            ]
        );
		$this->add_control(
            'show_excerpt',
            [
                'label' => __( 'Show Excerpt', 'renev' ),
                'type' => \Elementor\Controls_Manager::SWITCHER,
                'label_on' => __( 'Show', 'renev' ),
                'label_off' => __( 'Hide', 'renev' ),
                'return_value' => 'yes',
                'default' => 'yes',
            ]
        );
        $this->add_control(
            'excerpt_limit',
            [
                'label' => __('Excerpt Word Limit', 'renev'),
                'type' => \Elementor\Controls_Manager::SLIDER,
                'range' => [
                    'px' => [
                        'min' => 0,
                        'max' => 1000,
                    ],
                ],
                'default' => [
                    'unit' => 'px',
                    'size' => 15,
                ],
                'devices' => ['desktop', 'tablet', 'mobile'],
                'condition' => [
                    'show_excerpt' => 'yes',
                ]
            ]
        );
        $this->add_control(
            'meta_img',
            [
                'label'   => __( 'Meta Img', 'renev' ),
                'type'    => Controls_Manager::MEDIA,
                'default' => [
                    
                ],
            ]
        );
        $this->add_control(
            'meta_author_img',
            [
                'label'   => __( 'Meta Author Img', 'renev' ),
                'type'    => Controls_Manager::MEDIA,
                'default' => [
                    
                ],
                'condition' => [
                    'blog_layout' => 'layout-1',
                ],
            ]
        );
		$this->add_control(
            'show_btn',
            [
                'label' => __( 'Show Button', 'renev' ),
                'type' => \Elementor\Controls_Manager::SWITCHER,
                'label_on' => __( 'Show', 'renev' ),
                'label_off' => __( 'Hide', 'renev' ),
                'return_value' => 'yes',
                'default' => 'yes',
                'condition' => [
                    'blog_layout' => 'layout-2',
                ]
            ]
        );
        $this->add_control(
			'btn_text',
			[
				'label'   => esc_html__( 'Button Text', 'renev' ),
				'type'    => Controls_Manager::TEXT,
				'default' => esc_html__( 'READ MORE', 'renev' ),
                'label_block' => true,
                'condition' => [
                    'show_btn' => 'yes',
                ]
			]
		);
        $this->end_controls_section();

        // Start Blog Box Style
        $this->start_controls_section(
            'blog_box_style',
            [
                'label' => __( 'Blog Box', 'renev' ),
                'tab'   => Controls_Manager::TAB_STYLE,
            ]
        );
        $this->add_control(
            'blog_bx-bg_color',
            [
                'label' => __( 'Background', 'renev' ),
                'type' => Controls_Manager::COLOR,
                'selectors' => [
                    '{{WRAPPER}} .vl-blog-1-item' => 'background: {{VALUE}}',
                ],
            ]
        );
        $this->add_control(
            'blog_bx_border_radius',
            [
                'label' => esc_html__( 'Border Radius', 'renev' ),
                'type' => Controls_Manager::DIMENSIONS,
                'size_units' => [ 'px', '%', 'em', 'rem', 'custom' ],
                'selectors' => [
                    '{{WRAPPER}} .vl-blog-1-item' => 'border-radius: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
                ],
            ]
        );
        $this->add_responsive_control(
            'blog_box_margin',
            [
                'label' => __( 'Margin', 'renev' ),
                'type' => Controls_Manager::DIMENSIONS,
                'size_units' => [ 'px', 'em', '%' ],
                'selectors' => [
                    '{{WRAPPER}} .vl-blog-1-item' => 'margin: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
                ],
            ]
        );
        $this->add_responsive_control(
            'blog_box_padding',
            [
                'label' => __( 'Padding', 'renev' ),
                'type' => Controls_Manager::DIMENSIONS,
                'size_units' => [ 'px', 'em', '%' ],
                'selectors' => [
                    '{{WRAPPER}} .blog-2 .vl-blog-1-item' => 'padding: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
                ],
                'condition' => [
                    'blog_layout' => 'layout-2',
                ]
            ]
        );
        $this->add_group_control(
            Group_Control_Box_Shadow::get_type(),
            [
                'name'     => 'blog_box_shadow',
                'selector' => '{{WRAPPER}} .vl-blog-1-item',
            ]
        );
        $this->end_controls_section();

         //Blog Thumb Image style
         $this->start_controls_section(
            'blog_thumb_style',
            [
                'label' => __( 'Blog Thumb', 'renev' ),
                'tab'   => Controls_Manager::TAB_STYLE,
            ]
        );
        $this->add_responsive_control(
			'blog_thumb_width',
			[
				'label' => __( 'Width', 'renev' ),
				'type' => Controls_Manager::SLIDER,
				'size_units' => [ 'px' ],
				'range' => [
					'px' => [
						'min' => 0,
						'max' => 1000,
						'step' => 1,
					]
				],
				'selectors' => [
					'{{WRAPPER}} .vl-blog-1-item .vl-blog-1-thumb img' => 'width: {{SIZE}}{{UNIT}};',
                    
				],
			]
		);
        $this->add_responsive_control(
			'blog_thumb_height',
			[
				'label' => __( 'Height', 'renev' ),
				'type' => Controls_Manager::SLIDER,
				'size_units' => [ 'px' ],
				'range' => [
					'px' => [
						'min' => 0,
						'max' => 1000,
						'step' => 1,
					]
				],
				'selectors' => [
					'{{WRAPPER}} .vl-blog-1-item .vl-blog-1-thumb img' => 'height: {{SIZE}}{{UNIT}};',
				],
			]
		);
        $this->add_control(
            'blog_thumb_border_radius',
            [
                'label' => esc_html__( 'Image Border Radius', 'renev' ),
                'type' => Controls_Manager::DIMENSIONS,
                'size_units' => [ 'px', '%', 'em', 'rem', 'custom' ],
                'selectors' => [
                    '{{WRAPPER}} .vl-blog-1-item:hover .vl-blog-1-thumb' => 'border-radius: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
                    '{{WRAPPER}} .vl-blog-1-item .vl-blog-1-thumb' => 'border-radius: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
                ],
            ]
        );
        $this->end_controls_section();
        
        // Content Box style
        $this->start_controls_section(
            'blog_contant_box_style',
            [
                'label' => __( 'Blog Content Box', 'renev' ),
                'tab'   => Controls_Manager::TAB_STYLE,
            ]
        );
        $this->add_responsive_control(
            'blog_contant_padding',
            [
                'label' => __( 'Padding', 'renev' ),
                'type' => Controls_Manager::DIMENSIONS,
                'size_units' => [ 'px', 'em', '%' ],
                'selectors' => [
                    '{{WRAPPER}} .vl-blog-1-item .vl-blog-1-content' => 'padding: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
                ],
            ]
        );
        
         //Blog Date style
        $this->add_control(
            'blog_date_color',
            [
                'label' => __( 'Date Color', 'renev' ),
                'type' => Controls_Manager::COLOR,
                'selectors' => [
                    '{{WRAPPER}} .vl-blog-1-item .vl-blog-1-content .vl-blog-meta ul li:nth-child(1) a' => 'color: {{VALUE}}',
                ],
                
            ]
        );
        $this->add_group_control(
            Group_Control_Typography::get_type(),
            [
                'name' => 'date_typography',
                'selector' => '{{WRAPPER}} .vl-blog-1-item .vl-blog-1-content .vl-blog-meta ul li:nth-child(1) a',
            ]
        ); 

        $this->add_responsive_control(
            'date_margin',
            [
                'label' => __( 'Date Margin', 'renev' ),
                'type' => Controls_Manager::DIMENSIONS,
                'size_units' => [ 'px', 'em', '%' ],
                'selectors' => [
                    '{{WRAPPER}} .vl-blog-1-item .vl-blog-1-content .vl-blog-meta ul li:nth-child(1) a' => 'margin: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}} !important;',
                ],
            ]
        );    

        // Meta Author style
         $this->add_control(
            'meta_author_bg',
            [
                'label' => __( 'Author Background', 'renev' ),
                'type' => Controls_Manager::COLOR,
                'selectors' => [
                    '{{WRAPPER}} .vl-blog-1-item .vl-blog-1-content .vl-blog-meta ul li:nth-child(2) a' => 'background: {{VALUE}}',
                ],
                'condition' => [
                    'blog_layout!' => 'layout-2',
                ]
            ]
        );
        $this->add_group_control(
            Group_Control_Background::get_type(),
            [
                'name' => 'meta_author_bg',
                'label' => __( 'Author Background', 'renev' ),
                'types' => [ 'classic', 'gradient', 'video' ],
                'selector' => '{{WRAPPER}} .vl-blog-1-item .vl-blog-1-content .vl-blog-meta ul li:nth-child(2) a',
                'condition' => [
                    'blog_layout!' => 'layout-2',
                ]
            ]
        );
        $this->add_responsive_control(
            'meta_author_padding',
            [
                'label' => __( 'Author Box padding', 'renev' ),
                'type' => Controls_Manager::DIMENSIONS,
                'size_units' => [ 'px', 'em', '%' ],
                'selectors' => [
                    '{{WRAPPER}} .vl-blog-1-item .vl-blog-1-content .vl-blog-meta ul li:nth-child(2) a' => 'padding: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}} !important;',
                ],
                'condition' => [
                    'blog_layout!' => 'layout-2',
                ]
            ]
        );  
        $this->add_control(
            'meta_author_border_radius',
            [
                'label' => esc_html__( 'Author Border Radius', 'renev' ),
                'type' => Controls_Manager::DIMENSIONS,
                'size_units' => [ 'px', '%', 'em', 'rem', 'custom' ],
                'selectors' => [
                    '{{WRAPPER}} .vl-blog-1-item .vl-blog-1-content .vl-blog-meta ul li:nth-child(2) a' => 'border-radius: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
                ],
                'condition' => [
                    'blog_layout!' => 'layout-2',
                ]
            ]
        );         
        $this->add_control(
            'meta_author_color',
            [
                'label' => __( 'Author Text Color', 'renev' ),
                'type' => Controls_Manager::COLOR,
                'selectors' => [
                    '{{WRAPPER}} .vl-blog-1-item .vl-blog-1-content .vl-blog-meta ul li:nth-child(2) a' => 'color: {{VALUE}}',
                ],
                'condition' => [
                    'blog_layout!' => 'layout-2',
                ]
            ]
        );
        $this->add_group_control(
            Group_Control_Typography::get_type(),
            [
                'name' => 'meta_author_typography',
                'selector' => '{{WRAPPER}} .vl-blog-1-item .vl-blog-1-content .vl-blog-meta ul li:nth-child(2) a',
                'condition' => [
                    'blog_layout!' => 'layout-2',
                ]
            ]
        ); 
        $this->add_responsive_control(
            'meta_author_margin',
            [
                'label' => __( 'Author Box Margin', 'renev' ),
                'type' => Controls_Manager::DIMENSIONS,
                'size_units' => [ 'px', 'em', '%' ],
                'selectors' => [
                    '{{WRAPPER}} .vl-blog-1-item .vl-blog-1-content .vl-blog-meta' => 'margin: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}} !important;',
                ],
            ]
        );  
        $this->end_controls_section();

        
        // Title style
        $this->start_controls_section(
            'blog_title_style',
            [
                'label' => __( 'Blog Title', 'renev' ),
                'tab'   => Controls_Manager::TAB_STYLE,
            ]
        );
        $this->add_control(
            'blog_title_color',
            [
                'label' => __( 'Title Color', 'renev' ),
                'type' => Controls_Manager::COLOR,
                'selectors' => [
                    '{{WRAPPER}} .vl-blog-1-item .vl-blog-1-content .vl-blog-1-title a' => 'color: {{VALUE}}',
                ],
            ]
        );
        $this->add_control(
            'blog_title_hover_color',
            [
                'label' => __( 'Title Hover Color', 'renev' ),
                'type' => Controls_Manager::COLOR,
                'selectors' => [
                    '{{WRAPPER}} .vl-blog-1-item .vl-blog-1-content .vl-blog-1-title a:hover' => 'color: {{VALUE}}',
                ],
            ]
        );
        $this->add_group_control(
            Group_Control_Typography::get_type(),
            [
                'name' => 'blog_title_typography',
                'selector' => '{{WRAPPER}} .vl-blog-1-item .vl-blog-1-content .vl-blog-1-title a',
            ]
        ); 
        $this->add_responsive_control(
            'blog_title_margin',
            [
                'label' => __( 'Title Margin', 'renev' ),
                'type' => Controls_Manager::DIMENSIONS,
                'size_units' => [ 'px', 'em', '%' ],
                'selectors' => [
                    '{{WRAPPER}} .vl-blog-1-item .vl-blog-1-content .vl-blog-1-title a' => 'margin: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
                ],
            ]
        );
        $this->end_controls_section();

         // Title style
         $this->start_controls_section(
            'blog_excerpt_style',
            [
                'label' => __( 'Blog Excerpt', 'renev' ),
                'tab'   => Controls_Manager::TAB_STYLE,
                'condition' => [
                    'blog_layout!' => 'layout-1',
                ]
            ]
        );
        $this->add_control(
            'blog_excerpt_color',
            [
                'label' => __( 'Excerpt Color', 'renev' ),
                'type' => Controls_Manager::COLOR,
                'selectors' => [
                    '{{WRAPPER}} .vl-blog-1-item .vl-blog-1-content p' => 'color: {{VALUE}}',
                ],
            ]
        );
        $this->add_group_control(
            Group_Control_Typography::get_type(),
            [
                'name' => 'blog_excerpt_typography',
                'selector' => '{{WRAPPER}} .vl-blog-1-item .vl-blog-1-content p',
            ]
        ); 
        $this->add_responsive_control(
            'blog_excerpt_margin',
            [
                'label' => __( 'Excerpt Margin', 'renev' ),
                'type' => Controls_Manager::DIMENSIONS,
                'size_units' => [ 'px', 'em', '%' ],
                'selectors' => [
                    '{{WRAPPER}} .vl-blog-1-item .vl-blog-1-content p' => 'margin: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
                ],
            ]
        );
        $this->end_controls_section();

        // Button style
        $this->start_controls_section(
            'blog_btn_style',
            [
                'label' => __( 'Blog Button', 'renev' ),
                'tab'   => Controls_Manager::TAB_STYLE,
            ]
        );
        $this->add_responsive_control(
            'blog_btn_margin',
            [
                'label' => __( 'Blog Btn Margin', 'renev' ),
                'type' => Controls_Manager::DIMENSIONS,
                'size_units' => [ 'px', 'em', '%' ],
                'selectors' => [
                    '{{WRAPPER}} .vl-blog-1-item .vl-blog-1-content .vl-blog-1-icon a' => 'margin: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
                ],
            ]
        );
        $this->add_control(
            'blog_btn_color',
            [
                'label' => __( 'Text Color', 'renev' ),
                'type' => Controls_Manager::COLOR,
                'selectors' => [
                    '{{WRAPPER}} .vl-blog-1-item .vl-blog-1-content .vl-blog-1-icon a' => 'color: {{VALUE}}',
                    '{{WRAPPER}} .vl-blog-1-item .vl-blog-1-content .vl-blog-1-icon a i' => 'color: {{VALUE}}',
                ],
            ]
        );     
        $this->add_control(
            'blog_btn_hover_color',
            [
                'label' => __( 'Text Hover Color', 'renev' ),
                'type' => Controls_Manager::COLOR,
                'selectors' => [
                    '{{WRAPPER}} .vl-blog-1-item .vl-blog-1-content .vl-blog-1-icon a:hover' => 'color: {{VALUE}}',
                    '{{WRAPPER}} .vl-blog-1-item .vl-blog-1-content .vl-blog-1-icon a i:hover' => 'color: {{VALUE}}',
                ],
            ]
        );     
        $this->add_group_control(
            Group_Control_Typography::get_type(),
            [
                'name' => 'blog_btn_typography',
                'selector' => '{{WRAPPER}} .vl-blog-1-item .vl-blog-1-content .vl-blog-1-icon a',
            ]
        ); 
        $this->end_controls_section();


        // Pagination style
        $this->start_controls_section(
            'pagination_style',
            [
                'label' => __( 'Pagination', 'renev' ),
                'tab'   => Controls_Manager::TAB_STYLE,
                'condition' => [
                    'blog_layout' => 'layout-1',
                ]
            ]
        );
        $this->add_control(
            'pagination_color',
            [
                'label' => __( 'Color', 'renev' ),
                'type' => Controls_Manager::COLOR,
                'selectors' => [
                    '{{WRAPPER}} .pagination-area ul li a, .pagination-area ul li span' => 'color: {{VALUE}}',
                ],
            ]
        );     
        $this->add_control(
            'pagination_hover_color',
            [
                'label' => __( 'Hover Color', 'renev' ),
                'type' => Controls_Manager::COLOR,
                'selectors' => [
                    '{{WRAPPER}} .pagination-area ul li a.active, .pagination-area ul li span.active, .pagination-area ul li a.focus, .pagination-area ul li span.focus, .page-link:focus, .pagination-area ul li a:hover, .pagination-area ul li span:hover' => 'color: {{VALUE}}',
                ],
            ]
        );     
        $this->add_control(
            'pagination_bg_color',
            [
                'label' => __( 'Background Color', 'renev' ),
                'type' => Controls_Manager::COLOR,
                'selectors' => [
                    '{{WRAPPER}} .pagination-area ul li a, .pagination-area ul li span' => 'background-color: {{VALUE}}',
                ],
            ]
        ); 
        $this->add_control(
            'pagination_bg_hover_color',
            [
                'label' => __( 'Background Hover Color', 'renev' ),
                'type' => Controls_Manager::COLOR,
                'selectors' => [
                    '{{WRAPPER}} .pagination-area ul li a.active, .pagination-area ul li span.active, .pagination-area ul li a.focus, .pagination-area ul li span.focus, .page-link:focus, .pagination-area ul li a:hover, .pagination-area ul li span:hover' => 'background-color: {{VALUE}}',
                ],
            ]
        ); 
        $this->add_group_control(
            Group_Control_Typography::get_type(),
            [
                'name' => 'pagination_typography',
                'selector' => '{{WRAPPER}} .pagination-area ul li a, .pagination-area ul li span',
            ]
        ); 
        $this->add_responsive_control(
            'pagination_margin',
            [
                'label' => __( 'Margin', 'renev' ),
                'type' => Controls_Manager::DIMENSIONS,
                'size_units' => [ 'px', 'em', '%' ],
                'selectors' => [
                    '{{WRAPPER}} .pagination-area ul li a, .pagination-area ul li span' => 'margin: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
                ],
            ]
        );
        $this->add_responsive_control(
            'pagination_size',
            [
                'label'          => __('Size', 'renev'),
                'type'           => Controls_Manager::SLIDER,
                'size_units'     => ['%', 'px','vw'],
                'range'          => [
                    '%'  => [
                        'min' => 1,
                        'max' => 100,
                    ],
                    'px' => [
                        'min' => 1,
                        'max' => 1000,
                    ],
                    'vw' => [
                        'min' => 1,
                        'max' => 100,
                    ],
                ],
                'selectors' => [
                    '{{WRAPPER}} .pagination-area ul li a, .pagination-area ul li span' => 'width: {{SIZE}}{{UNIT}}; height: {{SIZE}}{{UNIT}};',
                    
                ],
            ]
        );
        $this->add_group_control(
            Group_Control_Border::get_type(),
            [
                'name' => 'pagination_border',
                'selector' => '{{WRAPPER}} .pagination-area ul li a, .pagination-area ul li span',
            ]
        );
        $this->add_control(
            'pagination_border_radius',
            [
                'label' => esc_html__( 'Border Radius', 'renev' ),
                'type' => Controls_Manager::DIMENSIONS,
                'size_units' => [ 'px', '%', 'em', 'rem', 'custom' ],
                'selectors' => [
                    '{{WRAPPER}} .pagination-area ul li a, .pagination-area ul li span' => 'border-radius: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
                ],
            ]
        );
        $this->end_controls_section();


    }

    private function get_blog_categories() {
        $categories = get_terms([
            'taxonomy'   => 'blog_category',
            'hide_empty' => true,
        ]);
    
        $options = ['' => __('All Categories', 'renev')];
        if (!empty($categories) && !is_wp_error($categories)) {
            foreach ($categories as $category) {
                $options[$category->slug] = $category->name;
            }
        }
        return $options;
    }

    // Render
	protected function render() {
        $settings = $this->get_settings_for_display();
        $layout = $settings['blog_layout'];

        ?>

        <?php
            // Query
            $numabr_of_post = !empty($settings['blog_per_page']) ? $settings['blog_per_page'] : -1;
            $paged = (get_query_var('paged')) ? get_query_var('paged') : 1;

            $query_args = [
                'post_type'           => 'post',
                'orderby'             => $settings['orderby'],
                'order'               => $settings['order'],
                'posts_per_page'      => $numabr_of_post,
                'post_status'         => 'publish',
                'ignore_sticky_posts' => 1,
                'paged'               => $paged,
            ];

            // get_type
            if ( 'selected' === $settings['post_by'] ) {
                $query_args['post__in'] = (array)$settings['post__in'];
            }

            $the_query = new \WP_Query($query_args);

		?>
            <?php
                if ( $layout) {
                    include('blog/'.$layout.'.php');
                }
            ?>
        <?php
    
    }
    

}
$widgets_manager->register( new \Renev_Blog() );