<?php
use \Elementor\Widget_Base;
use \Elementor\Controls_Manager;
use \Elementor\Group_Control_Typography;
use \Elementor\Group_Control_Border;
use \Elementor\Group_Control_Box_Shadow;
use \Elementor\Repeater;
use \Elementor\Utils;

/**
 *
 * Circle Animation Widget.
 *
 */
class Renev_Circle_Animation extends Widget_Base {

	public function get_name() {
		return 'renev_circle_animation';
	}

	public function get_title() {
		return __( 'Renev Circle Animation', 'renev' );
	}

	public function get_icon() {
		return 'eicon-code';
	}

	public function get_categories() {
		return [ 'renev' ];
	}

	// Register controls
	protected function register_controls() {

		// Content Controls
		$this->start_controls_section(
			'content_section',
			[
				'label' => __( 'Content', 'renev' ),
				'tab'   => Controls_Manager::TAB_CONTENT,
			]
		);
        $this->add_control(
            'circle_layout',
            [
                'label' => esc_html__('Select Layout', 'renev'),
                'type' => Controls_Manager::SELECT,
                'options' => [
                    'layout-1' => esc_html__('Layout 1', 'renev'),
                    'layout-2' => esc_html__('Layout 2', 'renev'),
                ],
                'default' => 'layout-1',
            ]
        );
		$this->add_control(
			'circle_icon_img',
			[
				'label'   => __( 'Circle Image', 'renev' ),
				'type'    => Controls_Manager::MEDIA,
				'default' => [
					'url' => Utils::get_placeholder_image_src(),
				],
			]
		);
        $this->add_control(
			'circle_arrow',
			[
				'label'   => __( 'Icon Arrow', 'renev' ),
				'type'    => Controls_Manager::MEDIA,
				'default' => [
					'url' => Utils::get_placeholder_image_src(),
				],
                'condition' => [
                    'circle_layout' => 'layout-1',
                ]
			]
		);
        $this->add_control(
            'arrow_link',
            [
                'label' => esc_html__('Button Url', 'renev'),
                'type' => Controls_Manager::URL,
                'default' => [
                    'url' => '#',
                ],
                'label_block' => true,
                'condition' => [
                    'circle_layout' => 'layout-1',
                ]
            ]
        );
		$this->end_controls_section();

        //circle style
        $this->start_controls_section(
            'circle_style',
            [
                'label' => __( 'Circle Section', 'renev' ),
                'tab'   => Controls_Manager::TAB_STYLE,
            ]
        );
        $this->add_responsive_control(
            'circle_width',
            [
                'label'          => __('Width', 'renev'),
                'type'           => Controls_Manager::SLIDER,
                'size_units'     => ['%', 'px','vw'],
                'range'          => [
                    '%'  => [
                        'min' => 1,
                        'max' => 100,
                    ],
                    'px' => [
                        'min' => 1,
                        'max' => 1000,
                    ],
                    'vw' => [
                        'min' => 1,
                        'max' => 100,
                    ],
                ],
                'selectors'      => [
                    '{{WRAPPER}} .hero1-section-area .imges-header .arrow a' => 'width: {{SIZE}}{{UNIT}};',
                    '{{WRAPPER}} about-images-area img' => 'width: {{SIZE}}{{UNIT}};',
                ],
            ]
        );
        $this->add_control(
            'circle_background',
            [
                'label' => __( 'Background', 'renev' ),
                'type' => Controls_Manager::COLOR,
                'selectors' => [
                    '{{WRAPPER}} .hero1-section-area .imges-header .arrow a' => 'background: {{VALUE}}',
                ],
                'condition' => [
                    'circle_layout!' => 'layout-2',
                ]
            ]
        );
        $this->end_controls_section();
	}

	// Render 
	protected function render() {
		$settings = $this->get_settings_for_display();
        $layout = $settings['circle_layout'];
		?>
            <?php
                if ( $layout) {
                    include('circle/'.$layout.'.php');
                }
            ?> 
		<?php
	}
}

// Register widget
$widgets_manager->register( new \Renev_Circle_Animation() );
