<div class="slider2-section-area">
    <div class="marquee-wrap">
        <div class="marquee-text">
            <?php foreach ( $slider_lists as $item ): ?>
                <?php if ( $counter >= $max_items ) break; ?>
                <div class="brand-single-box">
                    <h3>
                        <a href="<?php echo esc_url($item['slider_link']['url']); ?>">
                            <img src="<?php echo esc_url( $item['slider_icon']['url'] ); ?>" alt="">
                            <span><i class="fa-solid fa-arrow-right"></i></span>
                            <?php echo esc_html( $item['slider_text'] ); ?>
                        </a>
                    </h3>
                </div>
                <?php $counter++; ?>
            <?php endforeach; ?>
        </div>
    </div>
</div>
