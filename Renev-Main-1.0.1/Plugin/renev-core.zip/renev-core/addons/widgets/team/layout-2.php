<div class="row">
    <?php foreach ( $team_lists as $item ): ?>
        <div class="col-lg-3 col-md-6">
            <div class="team2-boxarea">
                <div class="img1">
                    <img src="<?php echo esc_url( $item['team-author_box']['url'] ); ?>" alt="" class="elements16">
                    <img src="<?php echo esc_url( $item['team-main_image']['url'] ); ?>" alt="">
                </div>
                <ul>
                    <?php if ( ! empty( $item['social_icon_one']['value'] ) && ! empty( $item['icon_url_one']['url'] ) ) : ?>
                        <li>
                            <a href="<?php echo esc_url( $item['icon_url_one']['url'] ); ?>">
                                <?php \Elementor\Icons_Manager::render_icon( $item['social_icon_one'], [ 'aria-hidden' => 'true' ] ); ?>
                            </a>
                        </li>
                    <?php endif; ?>
                    <?php if ( ! empty( $item['social_icon_two']['value'] ) && ! empty( $item['icon_url_one']['url'] ) ) : ?>
                        <li>
                            <a href="<?php echo esc_url( $item['icon_url_two']['url'] ); ?>">
                                <?php \Elementor\Icons_Manager::render_icon( $item['social_icon_two'], [ 'aria-hidden' => 'true' ] ); ?>
                            </a>
                        </li>
                    <?php endif; ?>
                    <?php if ( ! empty( $item['social_icon_three']['value'] ) && ! empty( $item['icon_url_one']['url'] ) ) : ?>
                        <li>
                            <a href="<?php echo esc_url( $item['icon_url_three']['url'] ); ?>">
                                <?php \Elementor\Icons_Manager::render_icon( $item['social_icon_three'], [ 'aria-hidden' => 'true' ] ); ?>
                            </a>
                        </li>
                    <?php endif; ?>
                    <?php if ( ! empty( $item['social_icon_four']['value'] ) && ! empty( $item['icon_url_one']['url'] ) ) : ?>
                        <li>
                            <a href="<?php echo esc_url( $item['icon_url_four']['url'] ); ?>">
                                <?php \Elementor\Icons_Manager::render_icon( $item['social_icon_four'], [ 'aria-hidden' => 'true' ] ); ?>
                            </a>
                        </li>
                    <?php endif; ?>
                </ul>
                <div class="content-area">
                    <a>
                        <?php echo esc_html($item['author_name']); ?>
                    </a>
                    <p>
                        <?php echo esc_html($item['author_Profession']); ?>
                    </p>
                </div>
            </div>
        </div>
    <?php endforeach; ?>
</div>