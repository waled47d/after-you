<?php
use \Elementor\Widget_Base;
use \Elementor\Controls_Manager;
use \Elementor\Icons_Manager;
use \Elementor\Group_Control_Typography;
use \Elementor\Group_Control_Border;
use \Elementor\Group_Control_Box_Shadow;
use \Elementor\Repeater;
use \Elementor\Utils;
/**
 *
 * Cta Widget .
 *
 */
class Renev_Cta extends Widget_Base {

	public function get_name() {
		return 'renev_cta';
	}

	public function get_title() {
		return __( 'Renev Cta Button', 'renev' );
	}

	public function get_icon() {
		return 'eicon-code';
    }

	public function get_categories() {
		return [ 'renev' ];
	}

	protected function register_controls() {

    $this->start_controls_section(
            'cta_section',
        [
            'label' => __('Cta Section', 'renev'),
            'tab'   => Controls_Manager::TAB_CONTENT,
        ]
    );
    $this->add_control(
        'cta_text',
        [
            'label'   => esc_html__( 'Text', 'renev' ),
            'type'    => Controls_Manager::TEXT,
            'default' => esc_html__( 'Get In touch', 'renev' ),
            'label_block' => true,
        ]
    );
    $this->add_control(
        'cta_text_url',
        [
            'label' => __( 'Text Url', 'renev' ),
            'type' => Controls_Manager::URL,
        ]
    );
    $this->end_controls_section();

    // Text style
    $this->start_controls_section(
        'cta_text_style',
        [
            'label' => __( 'Text', 'renev' ),
            'tab'   => Controls_Manager::TAB_STYLE,
        ]
    );
    $this->add_control(
        'cta_text_color',
        [
            'label' => __( 'Color', 'renev' ),
            'type' => Controls_Manager::COLOR,
            'selectors' => [
                '{{WRAPPER}} .cta-btn-area6 .btn-area a' => 'color: {{VALUE}}',
            ],
        ]
    );
    $this->add_control(
        'text_hover_color',
        [
            'label' => __( 'Hover Color', 'renev' ),
            'type' => Controls_Manager::COLOR,
            'selectors' => [
                '{{WRAPPER}} .cta-btn-area6 .btn-area a:hover' => 'color: {{VALUE}}',
            ],
        ]
    );
    $this->add_group_control(
        Group_Control_Typography::get_type(),
        [
            'name' => 'text_typography',
            'selector' => '{{WRAPPER}} .cta-btn-area6 .btn-area a',
        ]
    ); 
    $this->end_controls_section();


    }

    // Render
	protected function render() {
        $settings = $this->get_settings_for_display();

        ?>
        <div class="cta-btn-area6">
            <div class="container">
                <div class="row">
                <div class="col-lg-12">
                    <div class="btn-area">
                        <a href="<?php echo esc_url($settings['cta_text_url']['url']); ?>" class="cta-btn1">
                            <?php echo esc_html( $settings[ 'cta_text' ]  ); ?>
                        </a>
                    </div>
                </div>
                </div>
            </div>
        </div>
        <?php
    
    }

}
$widgets_manager->register( new \Renev_Cta() );