<?php
use \Elementor\Widget_Base;
use \Elementor\Controls_Manager;
use \Elementor\Group_Control_Typography;
use \Elementor\Group_Control_Border;
use \Elementor\Utils;
use \Elementor\Group_Control_Background;
use \Elementor\Repeater;
use \Elementor\Group_Control_Box_Shadow;

/**
 *
 * Contact Widget .
 *
 */
class Renev_Contact_Box extends Widget_Base {

    public function get_name() {
        return 'contact_box';
    }

    public function get_title() {
        return __( 'Contact Box', 'renev' );
    }

    public function get_icon() {
        return 'eicon-code';
    }

    public function get_categories() {
        return [ 'renev' ];
    }

    protected function register_controls() {
        $this->start_controls_section(
            'content_section',
            [
                'label' 	=> __( 'Content', 'renev' ),
                'tab' 		=> Controls_Manager::TAB_CONTENT,
            ] 
        );

        // Repeater for Testimonial items
        $repeater = new Repeater();

        $repeater->add_control(
            'Contact_icon',
            [
                'label'   => __( 'Contact Icon', 'renev' ),
                'type'    => Controls_Manager::MEDIA,
                'default' => [
                ],
            ]
        );
        $repeater->add_control(
            'contact_url',
            [
                'label' => __( 'Contact URL', 'renev' ),
                'type' => Controls_Manager::URL,
            ]
        );

        $repeater->add_control(
            'contact_title',
            [
                'label'   => esc_html__( 'Contact Title', 'renev' ),
                'type'    => Controls_Manager::TEXT,
                'default' => esc_html__( 'Our Email', 'renev' ),
                'label_block' => true,
            ]
        );
        $repeater->add_control(
            'contact_text',
            [
                'label'   => esc_html__( 'Contact Text', 'renev' ),
                'type'    => Controls_Manager::TEXT,
                'default' => esc_html__( 'renevweb@gmail.com', 'renev' ),
                'label_block' => true,
            ]
        );
        $this->add_control(
            'contact_items',
            [
                'label'       => __( 'Contact Items', 'renev' ),
                'type'        => Controls_Manager::REPEATER,
                'fields'      => $repeater->get_controls(),
                'default'     => [],
            ]
        );
        
        $this->end_controls_section();

        //Contact Box Style
        $this->start_controls_section(
            'contact_box_style',
            [
                'label' => __( 'Contact Box Style', 'renev' ),
                'tab' => \Elementor\Controls_Manager::TAB_STYLE,
            ]
        );
        $this->add_control(
            'contact_box_bg',
            [
                'label' => __( 'Background Color', 'renev' ),
                'type' => \Elementor\Controls_Manager::COLOR,
                'selectors' => [
                    '{{WRAPPER}} .contact-inner-area .widget-contactbox' => 'background-color: {{VALUE}};',
                ],
            ]
        );
        $this->add_control(
            'contact_box_bg_hover',
            [
                'label' => __( 'Background Hover', 'renev' ),
                'type' => \Elementor\Controls_Manager::COLOR,
                'selectors' => [
                    '{{WRAPPER}} .contact-inner-area .widget-contactbox::after' => 'background-color: {{VALUE}};',
                ],
            ]
        );
        $this->add_responsive_control(
            'contact_box_padding',
            [
                'label' => __( 'Padding', 'renev' ),
                'type' => \Elementor\Controls_Manager::DIMENSIONS,
                'selectors' => [
                    '{{WRAPPER}} .contact-inner-area .widget-contactbox' => 'padding: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
                ],
            ]
        );
        $this->add_responsive_control(
            'contact_box_radius',
            [
                'label' => __( 'Border Radius', 'renev' ),
                'type' => \Elementor\Controls_Manager::DIMENSIONS,
                'selectors' => [
                    '{{WRAPPER}} .contact-inner-area .widget-contactbox' => 'border-radius: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
                ],
            ]
        );
        $this->end_controls_section();

        //Contact Content Titile Style
       $this->start_controls_section(
            'contact_box_content_style',
            [
                'label' => __( 'Contact Contern', 'renev' ),
                'tab' => \Elementor\Controls_Manager::TAB_STYLE,
            ]
        );
        $this->add_control(
            'contact_content_color',
            [
                'label' => __( 'Title Color', 'renev' ),
                'type' => \Elementor\Controls_Manager::COLOR,
                'selectors' => [
                    '{{WRAPPER}} .contact-inner-area .widget-contactbox .content h4' => 'color: {{VALUE}};',
                ],
            ]
        );
        $this->add_control(
            'contact_content_hover_color',
            [
                'label' => __( 'Title Hover Color', 'renev' ),
                'type' => \Elementor\Controls_Manager::COLOR,
                'selectors' => [
                    '{{WRAPPER}} .contact-inner-area .widget-contactbox:hover .content h4' => 'color: {{VALUE}};',
                ],
            ]
        );
        $this->add_group_control(
            \Elementor\Group_Control_Typography::get_type(),
            [
                'name' => 'contact_content_typography',
                'selector' => '{{WRAPPER}} .contact-inner-area .widget-contactbox .content h4',
            ]
        );
        $this->add_responsive_control(
            'contact_content_margin',
            [
                'label' => __( 'Margin', 'renev' ),
                'type' => Controls_Manager::DIMENSIONS,
                'size_units' => [ 'px', 'em', '%' ],
                'selectors' => [
                    '{{WRAPPER}} .contact-inner-area .widget-contactbox .content h4' => 'margin: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
                ],
            ]
        );     

       //Contact Text Style
        $this->add_control(
            'contact_text_color',
            [
                'label' => __( 'Text Color', 'renev' ),
                'type' => \Elementor\Controls_Manager::COLOR,
                'selectors' => [
                    '{{WRAPPER}} .contact-inner-area .widget-contactbox .content a' => 'color: {{VALUE}};',
                ],
            ]
        );
        $this->add_control(
            'contact_text_hover_color',
            [
                'label' => __( 'Text Hover Color', 'renev' ),
                'type' => \Elementor\Controls_Manager::COLOR,
                'selectors' => [
                    '{{WRAPPER}} .contact-inner-area .widget-contactbox:hover .content a' => 'color: {{VALUE}};',
                ],
            ]
        );
        $this->add_group_control(
            \Elementor\Group_Control_Typography::get_type(),
            [
                'name' => 'contact_text_typography',
                'selector' => '{{WRAPPER}} .contact-inner-area .widget-contactbox .content a',
            ]
        );
        $this->add_responsive_control(
            'contact_text_margin',
            [
                'label' => __( 'Text Margin', 'renev' ),
                'type' => Controls_Manager::DIMENSIONS,
                'size_units' => [ 'px', 'em', '%' ],
                'selectors' => [
                    '{{WRAPPER}} .contact-inner-area .widget-contactbox .content a' => 'margin: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
                ],
            ]
        );  
        $this->end_controls_section();

        //Icon Style
        $this->start_controls_section(
            'contact_icon_style',
            [
                'label' => __( 'Icon Style', 'renev' ),
                'tab' => \Elementor\Controls_Manager::TAB_STYLE,
            ]
        );
        
        // Icon Width
        $this->add_responsive_control(
            'iconbox_width',
            [
                'label' => __( 'Iconbox Width', 'renev' ),
                'type' => \Elementor\Controls_Manager::SLIDER,
                'range' => [
                    'px' => ['min' => 10, 'max' => 300],
                ],
                'selectors' => [
                    '{{WRAPPER}} .contact-inner-area .widget-contactbox .icons' => 'width: {{SIZE}}{{UNIT}};',
                ],
            ]
        );
        $this->add_responsive_control(
            'iconbox_height',
            [
                'label' => __( 'Iconbox Height', 'renev' ),
                'type' => \Elementor\Controls_Manager::SLIDER,
                'range' => [
                    'px' => ['min' => 10, 'max' => 300],
                ],
                'selectors' => [
                    '{{WRAPPER}} .contact-inner-area .widget-contactbox .icons' => 'height: {{SIZE}}{{UNIT}};',
                ],
            ]
        );
        $this->add_control(
            'iconbox_bg',
            [
                'label' => __( 'Iconbox Background', 'renev' ),
                'type' => \Elementor\Controls_Manager::COLOR,
                'selectors' => [
                    '{{WRAPPER}} .contact-inner-area .widget-contactbox .icons' => 'background-color: {{VALUE}};',
                ],
            ]
        );
        $this->add_control(
            'iconbox_bg_hover',
            [
                'label' => __( 'Iconbox Hover Background', 'renev' ),
                'type' => \Elementor\Controls_Manager::COLOR,
                'selectors' => [
                    '{{WRAPPER}} .contact-inner-area .widget-contactbox:hover .icons' => 'background-color: {{VALUE}};',
                ],
            ]
        );
        $this->add_responsive_control(
            'iconbox_border_radius',
            [
                'label' => __( 'Icon Border Radius', 'renev' ),
                'type' => \Elementor\Controls_Manager::DIMENSIONS,
                'selectors' => [
                    '{{WRAPPER}} .contact-inner-area .widget-contactbox .icons' => 'border-radius: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
                ],
            ]
        );
        $this->add_responsive_control(
            'icon_size',
            [
                'label' => __( 'Icon Size', 'renev' ),
                'type' => \Elementor\Controls_Manager::SLIDER,
                'range' => [
                    'px' => [
                        'min' => 20,
                        'max' => 200,
                    ],
                ],
                'selectors' => [
                    '{{WRAPPER}} .contact-inner-area .widget-contactbox .icons img' => 'width: {{SIZE}}{{UNIT}}; height: {{SIZE}}{{UNIT}};',
                ],
            ]
        );
        $this->end_controls_section();
    }

    protected function render() {
        $settings = $this->get_settings_for_display();
        $contact_items = $settings['contact_items'];
        ?>
        <div class="contact-inner-area">
            <div class="container">
                <div class="row">
                    <?php foreach ( $contact_items as $item ): ?>
                        <div class="col-lg-4 col-md-6">
                            <div class="widget-contactbox">
                                <div class="icons">
                                    <img src="<?php echo esc_url( $item['Contact_icon']['url'] ); ?>" alt="">
                                </div>
                                <div class="content">
                                    <h4><?php echo esc_html( $item['contact_title'] ); ?></h4>
                                    <a href="<?php echo esc_url($item['contact_url']['url']); ?>">
                                        <?php echo esc_html( $item['contact_text'] ); ?>
                                    </a>
                                </div>
                            </div>
                            <div class="space30 d-lg-none d-block"></div>
                         </div> 
                    <?php endforeach; ?>
                 </div>
             </div>
        </div>
        <?php
    }
}

$widgets_manager->register( new \Renev_Contact_Box() );
