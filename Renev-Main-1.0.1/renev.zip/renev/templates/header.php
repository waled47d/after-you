<?php
/**
 * @Packge     : Renev
 * @Version    : 1.0
 * @Author     : Mthemeus
 * @Author URI : https://www.mthemeus.com/
 *
 */

    // Block direct access
    if( ! defined( 'ABSPATH' ) ){
        exit();
    }

    if( class_exists( 'ReduxFramework' ) && defined('ELEMENTOR_VERSION') ) {
        if( is_page() || is_page_template('template-builder.php') ) {
            $renev_post_id = get_the_ID();

            // Get the page settings manager
            $renev_page_settings_manager = \Elementor\Core\Settings\Manager::get_settings_managers( 'page' );

            // Get the settings model for current post
            $renev_page_settings_model = $renev_page_settings_manager->get_model( $renev_post_id );

            // Retrieve the color we added before
            $renev_header_style = $renev_page_settings_model->get_settings( 'renev_header_style' );
            $renev_header_builder_option = $renev_page_settings_model->get_settings( 'renev_header_builder_option' );

            if( $renev_header_style == 'header_builder'  ) {

                if( !empty( $renev_header_builder_option ) ) {
                    $renevheader = get_post( $renev_header_builder_option );
                    echo '<header class="header">';
                        echo \Elementor\Plugin::instance()->frontend->get_builder_content_for_display( $renevheader->ID );
                    echo '</header>';
                }
            } else {
                // global options
                $renev_header_builder_trigger = renev_opt('renev_header_options');
                if( $renev_header_builder_trigger == '2' ) {
                    echo '<header>';
                    $renev_global_header_select = get_post( renev_opt( 'renev_header_select_options' ) );
                    $header_post = get_post( $renev_global_header_select );
                    echo \Elementor\Plugin::instance()->frontend->get_builder_content_for_display( $header_post->ID );
                    echo '</header>';
                } else {
                    // wordpress Header
                    renev_global_header_option();
                }
            }
        } else {
            $renev_header_options = renev_opt('renev_header_options');
            if( $renev_header_options == '1' ) {
                renev_global_header_option();
            } else {
                $renev_header_select_options = renev_opt('renev_header_select_options');
                $renevheader = get_post( $renev_header_select_options );
                echo '<header class="header">';
                    echo \Elementor\Plugin::instance()->frontend->get_builder_content_for_display( $renevheader->ID );
                echo '</header>';
            }
        }
    } else {
        renev_global_header_option();
    }