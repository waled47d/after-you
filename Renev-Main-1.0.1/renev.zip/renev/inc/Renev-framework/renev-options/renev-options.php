<?php
    /**
     * ReduxFramework Sample Config File
     * For full documentation, please visit: http://docs.reduxframework.com/
     */

    if ( ! class_exists( 'Redux' ) ) {
        return;
    }

    // This is your option name where all the Redux data is stored.
    $opt_name = "renev_opt";

    // This line is only for altering the demo. Can be easily removed.
    $opt_name = apply_filters( 'redux_demo/opt_name', $opt_name );

    /*
     *
     * --> Used within different fields. Simply examples. Search for ACTUAL DECLARATION for field examples
     *
     */

    $sampleHTML = '';
    if ( file_exists( dirname( __FILE__ ) . '/info-html.html' ) ) {
        Redux_Functions::initWpFilesystem();

        global $wp_filesystem;

        $sampleHTML = $wp_filesystem->get_contents( dirname( __FILE__ ) . '/info-html.html' );
    }


    $alowhtml = array(
        'p' => array(
            'class' => array()
        ),
        'span' => array()
    );


    // Background Patterns Reader
    $sample_patterns_path = ReduxFramework::$_dir . '../sample/patterns/';
    $sample_patterns_url  = ReduxFramework::$_url . '../sample/patterns/';
    $sample_patterns      = array();

    if ( is_dir( $sample_patterns_path ) ) {

        if ( $sample_patterns_dir = opendir( $sample_patterns_path ) ) {
            $sample_patterns = array();

            while ( ( $sample_patterns_file = readdir( $sample_patterns_dir ) ) !== false ) {

                if ( stristr( $sample_patterns_file, '.png' ) !== false || stristr( $sample_patterns_file, '.jpg' ) !== false ) {
                    $name              = explode( '.', $sample_patterns_file );
                    $name              = str_replace( '.' . end( $name ), '', $sample_patterns_file );
                    $sample_patterns[] = array(
                        'alt' => $name,
                        'img' => $sample_patterns_url . $sample_patterns_file
                    );
                }
            }
        }
    }

    /**
     * ---> SET ARGUMENTS
     * All the possible arguments for Redux.
     * For full documentation on arguments, please refer to: https://github.com/ReduxFramework/ReduxFramework/wiki/Arguments
     * */

    $theme = wp_get_theme(); // For use with some settings. Not necessary.

    $args = array(
        // TYPICAL -> Change these values as you need/desire
        'opt_name'             => $opt_name,
        // This is where your data is stored in the database and also becomes your global variable name.
        'display_name'         => $theme->get( 'Name' ),
        // Name that appears at the top of your panel
        'display_version'      => $theme->get( 'Version' ),
        // Version that appears at the top of your panel
        'menu_type'            => 'menu',
        //Specify if the admin menu should appear or not. Options: menu or submenu (Under appearance only)
        'allow_sub_menu'       => true,
        // Show the sections below the admin menu item or not
        'menu_title'           => esc_html__( 'Renev Options', 'renev' ),
        'page_title'           => esc_html__( 'Renev Options', 'renev' ),
        // You will need to generate a Google API key to use this feature.
        // Please visit: https://developers.google.com/fonts/docs/developer_api#Auth
        'google_api_key'       => '',
        // Set it you want google fonts to update weekly. A google_api_key value is required.
        'google_update_weekly' => false,
        // Must be defined to add google fonts to the typography module
        'async_typography'     => false,
        // Use a asynchronous font on the front end or font string
        //'disable_google_fonts_link' => true,                    // Disable this in case you want to create your own google fonts loader
        'admin_bar'            => true,
        // Show the panel pages on the admin bar
        'admin_bar_icon'       => 'dashicons-portfolio',
        // Choose an icon for the admin bar menu
        'admin_bar_priority'   => 50,
        // Choose an priority for the admin bar menu
        'global_variable'      => '',
        // Set a different name for your global variable other than the opt_name
        'dev_mode'             => false,
        // Show the time the page took to load, etc
        'update_notice'        => true,
        // If dev_mode is enabled, will notify developer of updated versions available in the GitHub Repo
        'customizer'           => true,
        // Enable basic customizer support
        //'open_expanded'     => true,                    // Allow you to start the panel in an expanded way initially.
        //'disable_save_warn' => true,                    // Disable the save warning when a user changes a field

        // OPTIONAL -> Give you extra features
        'page_priority'        => null,
        // Order where the menu appears in the admin area. If there is any conflict, something will not show. Warning.
        'page_parent'          => 'themes.php',
        // For a full list of options, visit: http://codex.wordpress.org/Function_Reference/add_submenu_page#Parameters
        'page_permissions'     => 'manage_options',
        // Permissions needed to access the options panel.
        'menu_icon'            => '',
        // Specify a custom URL to an icon
        'last_tab'             => '',
        // Force your panel to always open to a specific tab (by id)
        'page_icon'            => 'icon-themes',
        // Icon displayed in the admin panel next to your menu_title
        'page_slug'            => '',
        // Page slug used to denote the panel, will be based off page title then menu title then opt_name if not provided
        'save_defaults'        => true,
        // On load save the defaults to DB before user clicks save or not
        'default_show'         => false,
        // If true, shows the default value next to each field that is not the default value.
        'default_mark'         => '',
        // What to print by the field's title if the value shown is default. Suggested: *
        'show_import_export'   => true,
        // Shows the Import/Export panel when not used as a field.

        // CAREFUL -> These options are for advanced use only
        'transient_time'       => 60 * MINUTE_IN_SECONDS,
        'output'               => true,
        // Global shut-off for dynamic CSS output by the framework. Will also disable google fonts output
        'output_tag'           => true,
        // Allows dynamic CSS to be generated for customizer and google fonts, but stops the dynamic CSS from going to the head
        // 'footer_credit'     => '',                   // Disable the footer credit of Redux. Please leave if you can help it.

        // FUTURE -> Not in use yet, but reserved or partially implemented. Use at your own risk.
        'database'             => '',
        // possible: options, theme_mods, theme_mods_expanded, transient. Not fully functional, warning!
        'use_cdn'              => true,
        // If you prefer not to use the CDN for Select2, Ace Editor, and others, you may download the Redux Vendor Support plugin yourself and run locally or embed it in your code.

        // HINTS
        'hints'                => array(
            'icon'          => 'el el-question-sign',
            'icon_position' => 'right',
            'icon_color'    => 'lightgray',
            'icon_size'     => 'normal',
            'tip_style'     => array(
                'color'   => 'red',
                'shadow'  => true,
                'rounded' => false,
                'style'   => '',
            ),
            'tip_position'  => array(
                'my' => 'top left',
                'at' => 'bottom right',
            ),
            'tip_effect'    => array(
                'show' => array(
                    'effect'   => 'slide',
                    'duration' => '500',
                    'event'    => 'mouseover',
                ),
                'hide' => array(
                    'effect'   => 'slide',
                    'duration' => '500',
                    'event'    => 'click mouseleave',
                ),
            ),
        )
    );


    Redux::setArgs( $opt_name, $args );

    /*
     * ---> END ARGUMENTS
     */


    /*
     * ---> START HELP TABS
     */

    $tabs = array(
        array(
            'id'      => 'redux-help-tab-1',
            'title'   => esc_html__( 'Theme Information 1', 'renev' ),
            'content' => esc_html__( '<p>This is the tab content, HTML is allowed.</p>', 'renev' )
        ),
        array(
            'id'      => 'redux-help-tab-2',
            'title'   => esc_html__( 'Theme Information 2', 'renev' ),
            'content' => esc_html__( '<p>This is the tab content, HTML is allowed.</p>', 'renev' )
        )
    );
    Redux::set_help_tab( $opt_name, $tabs );

    // Set the help sidebar
    $content = esc_html__( '<p>This is the sidebar content, HTML is allowed.</p>', 'renev' );
    Redux::set_help_sidebar( $opt_name, $content );



    // -> START General Fields

    Redux::setSection( $opt_name, array(
        'icon'             => 'el el-refresh',
        'title'            => esc_html__( 'Preloader', 'renev' ),
        'id'               => 'renev_preloader',
        'subsection'       => false,
        'fields'           => array(
            array(
                'id'       => 'renev_display_preloader',
                'type'     => 'switch',
                'title'    => esc_html__( 'Preloader', 'renev' ),
                'subtitle' => esc_html__( 'Switch Enabled to Display Preloader.', 'renev' ),
                'default'  => true,
                'on'       => esc_html__('Enabled','renev'),
                'off'      => esc_html__('Disabled','renev'),
            ),
        )
    ));

    Redux::setSection( $opt_name, array(
        'icon'             => 'fas fa-mouse-pointer',
        'title'            => esc_html__( 'Cursor', 'renev' ),
        'id'               => 'renev_cursor',
        'subsection'       => false,
        'fields'           => array(
            array(
                'id'       => 'renev_display_cursor',
                'type'     => 'switch',
                'title'    => esc_html__( 'Cursor', 'renev' ),
                'subtitle' => esc_html__( 'Switch Enabled to Display Cursor.', 'renev' ),
                'default'  => true,
                'on'       => esc_html__('Enabled','renev'),
                'off'      => esc_html__('Disabled','renev'),
            ),
            array(
                'id'       => 'renev_cursor_border_color',
                'type'     => 'color',
                'title'    => esc_html__( 'Border Color', 'renev' ),
                'subtitle' => esc_html__( 'Set border color', 'renev' ),
                'output'   => array(
                    'border-color' => '.procus-cursor',
                ),
                'required' => array( 'renev_display_cursor','equals','1'),
            ),
            array(
                'id'       => 'renev_cursor_bg_color',
                'type'     => 'color',
                'title'    => esc_html__( 'Color', 'renev' ),
                'subtitle' => esc_html__( 'Set color', 'renev' ),
                'output'   => array(
                    'background-color' => '.procus-cursor2',
                ),
                'required' => array( 'renev_display_cursor','equals','1'),
            ),                        
        )
    ));

    Redux::setSection( $opt_name, array(
        'icon'             => 'el  el-foursquare',
        'title'            => esc_html__( 'Logo', 'renev' ),
        'id'               => 'logo_settings',
        'customizer_width' => '450px',
        'fields'           => array(
            array(
                'id'       => 'logo',
                'type'     => 'media',
                'title'    => esc_html__( 'Logo', 'renev' ),
                'subtitle' => esc_html__( 'Choose the site Dark logo', 'renev' ),
                'default'  => array(
                    'url' => 'https://wp.framerpeak.com/renev/wp-content/uploads/2025/09/site-logo.svg',
                ),
            ),
            array(
                'id'       => 'white_logo',
                'type'     => 'media',
                'title'    => esc_html__( 'White Logo', 'renev' ),
                'subtitle' => esc_html__( 'Choose the site White logo', 'renev' ),
                'default'  => array(
                    'url' => 'https://wp.framerpeak.com/renev/wp-content/uploads/2025/09/white-logo.svg',
                ),
            ),
    
        ),
    ) );


    // -> START Basic Fields
    Redux::setSection( $opt_name, array(
        'title'            => esc_html__( 'Header', 'renev' ),
        'id'               => 'renev_header',
        'customizer_width' => '400px',
        'icon'             => 'el el-credit-card',
        'fields'           => array(
            array(
                'id'       => 'renev_header_options',
                'type'     => 'button_set',
                'default'  => '1',
                'options'  => array(
                    "1"   => esc_html__('Prebuilt','renev'),
                    "2"      => esc_html__('Header Builder','renev'),
                ),
                'title'    => esc_html__( 'Header Options', 'renev' ),
                'subtitle' => esc_html__( 'Select header options.', 'renev' ),
            ),
            array(
                'id'       => 'renev_header_select_options',
                'type'     => 'select',
                'data'     => 'posts',
                'args'     => array(
                    'post_type'     => 'renev_header'
                ),
                'title'    => esc_html__( 'Header', 'renev' ),
                'subtitle' => esc_html__( 'Select header.', 'renev' ),
                'required' => array( 'renev_header_options', 'equals', '2' )
            ),

        ),
    ) );
    // -> START Header Logo
    Redux::setSection( $opt_name, array(
        'title'            => esc_html__( 'Header Logo', 'renev' ),
        'id'               => 'renev_header_logo_option',
        'subsection'       => true,
        'fields'           => array(
            array(
                'id'       => 'renev_site_logo',
                'type'     => 'media',
                'url'      => true,
                'title'    => esc_html__( 'Site Logo', 'renev' ),
                'compiler' => 'true',
                'subtitle' => esc_html__( 'Upload your site logo for header ( recommendation png format ).', 'renev' ),
            ),
            array(
                'id'       => 'renev_site_logo_dimensions',
                'type'     => 'dimensions',
                'units'    => array('px'),
                'title'    => esc_html__('Logo Dimensions (Width/Height).', 'renev'),
                'output'   => array('.logo-box-one a img'),
                'subtitle' => esc_html__('Set logo dimensions to choose width, height, and unit.', 'renev'),
            ),
            array(
                'id'       => 'renev_site_logomargin_dimensions',
                'type'     => 'spacing',
                'mode'     => 'margin',
                'output'   => array('.logo-box-one a img'),
                'units_extended' => 'false',
                'units'    => array('px'),
                'title'    => esc_html__('Logo Top and Bottom Margin.', 'renev'),
                'left'     => false,
                'right'    => false,
                'subtitle' => esc_html__('Set logo top and bottom margin.', 'renev'),
                'default'            => array(
                    'units'           => 'px'
                )
            ),
            array(
                'id'       => 'renev_text_title',
                'type'     => 'text',
                'validate' => 'html',
                'title'    => esc_html__( 'Text Logo', 'renev' ),
                'subtitle' => esc_html__( 'Write your logo text use as logo ( You can use span tag for text color ).', 'renev' ),
            )
        )
    ) );
    // -> End Header Logo

    // -> START Header Menu
    Redux::setSection( $opt_name, array(
        'title'            => esc_html__( 'Header Menu', 'renev' ),
        'id'               => 'renev_header_menu_option',
        'subsection'       => true,
        'fields'           => array(
            array(
                'id'       => 'renev_header_menu_color',
                'type'     => 'color',
                'title'    => esc_html__( 'Menu Color', 'renev' ),
                'subtitle' => esc_html__( 'Set Menu Color', 'renev' ),
                'output'   => array( 'color'    =>  '.menu-style1 > ul > li > a, .navbar-wrap ul li a' ),
            ),
            array(
                'id'       => 'renev_header_menu_hover_color',
                'type'     => 'color',
                'title'    => esc_html__( 'Menu Hover Color', 'renev' ),
                'subtitle' => esc_html__( 'Set Menu Hover Color', 'renev' ),
                'output'   => array( 'color'    =>  '.menu-style1 > ul > li > a:hover, .navbar-wrap>ul>li.active>a, .navbar-wrap>ul>li:hover>a' ),
            ),
            array(
                'id'       => 'renev_header_submenu_color',
                'type'     => 'color',
                'title'    => esc_html__( 'Submenu Color', 'renev' ),
                'subtitle' => esc_html__( 'Set Submenu Color', 'renev' ),
                'output'   => array( 'color'    =>  '.main-menu ul li ul.sub-menu li a, .navbar-wrap ul li .sub-menu li a' ),
            ),
            array(
                'id'       => 'renev_header_submenu_hover_color',
                'type'     => 'color',
                'title'    => esc_html__( 'Submenu Hover Color', 'renev' ),
                'subtitle' => esc_html__( 'Set Submenu Hover Color', 'renev' ),
                'output'   => array( 'color'    =>  '.main-menu ul li ul.sub-menu li a:hover, .navbar-wrap ul li .sub-menu li a:hover' ),
            ),
            array(
                'id'       => 'renev_header_submenu_hover_bg_color',
                'type'     => 'color',
                'title'    => esc_html__( 'Submenu Hover Bg Color', 'renev' ),
                'subtitle' => esc_html__( 'Set Submenu Hover Bg Color', 'renev' ),
                'output'   => array( 'background-color'    =>  '.navbar-wrap ul li .sub-menu li a:hover' ),
            ),
        )
    ) );
    // -> End Header Menu

     

    // -> START Blog Page
    Redux::setSection( $opt_name, array(
        'title'      => esc_html__( 'Blog', 'renev' ),
        'id'         => 'renev_blog_page',
        'icon'  => 'el el-blogger',
        'fields'     => array(

            array(
                'id'       => 'renev_blog_sidebar',
                'type'     => 'image_select',
                'title'    => esc_html__( 'Layout', 'renev' ),
                'subtitle' => esc_html__( 'Choose blog layout from here. If you use this option then you will able to change three type of blog layout ( Default Left Sidebar Layour ). ', 'renev' ),
                'options'  => array(
                    '1' => array(
                        'alt' => esc_attr__('1 Column','renev'),
                        'img' => esc_url( get_template_directory_uri(). '/assets/img/no-sideber.png')
                    ),
                    '2' => array(
                        'alt' => esc_attr__('2 Column Left','renev'),
                        'img' => esc_url( get_template_directory_uri() .'/assets/img/left-sideber.png')
                    ),
                    '3' => array(
                        'alt' => esc_attr__('2 Column Right','renev'),
                        'img' => esc_url(  get_template_directory_uri() .'/assets/img/right-sideber.png' )
                    ),

                ),
                'default'  => '3'
            ),
            array(
                'id'       => 'renev_blog_grid',
                'type'     => 'image_select',
                'title'    => esc_html__( 'Post Column', 'renev' ),
                'subtitle' => esc_html__( 'Select your blog post column from here. If you use this option then you will able to select three type of blog post layout ( Default Two Column ).', 'renev' ),
                //Must provide key => value(array:title|img) pairs for radio options
                'options'  => array(
                    '1' => array(
                        'alt' => esc_attr__('1 Column','renev'),
                        'img' => esc_url( get_template_directory_uri(). '/assets/img/1column.png')
                    ),
                    '2' => array(
                        'alt' => esc_attr__('2 Column Left','renev'),
                        'img' => esc_url( get_template_directory_uri() .'/assets/img/2column.png')
                    ),
                    '3' => array(
                        'alt' => esc_attr__('2 Column Right','renev'),
                        'img' => esc_url(  get_template_directory_uri() .'/assets/img/3column.png' )
                    ),

                ),
                'default'  => '1'
            ),

            array(
                'id'      => 'renev_blog_style',
                'type'     => 'select',
                'options'  => array(
                    'blog_style_one' => esc_html__('Blog Style One','renev'),
                    'blog_style_two' => esc_html__('Blog Style Two','renev'),
                ),
                'default'  => 'blog_style_two',
                'title'   => esc_html__('Blog Style', 'renev'),
            ),

            array(
                'id'       => 'renev_blog_page_title_switcher',
                'type'     => 'switch',
                'default'  => 1,
                'on'       => esc_html__('Show','renev'),
                'off'      => esc_html__('Hide','renev'),
                'title'    => esc_html__('Blog Page Title', 'renev'),
                'subtitle' => esc_html__('Control blog page title show / hide. If you use this option then you will able to show / hide your blog page title ( Default Setting Show ).', 'renev'),
            ),
            array(
                'id'       => 'renev_blog_page_title_setting',
                'type'     => 'button_set',
                'title'    => esc_html__('Blog Page Title Setting', 'renev'),
                'subtitle' => esc_html__('Control blog page title setting. If you use this option then you can able to show default or custom blog page title ( Default Blog ).', 'renev'),
                'options'  => array(
                    "predefine"   => esc_html__('Default','renev'),
                    "custom"      => esc_html__('Custom','renev'),
                ),
                'default'  => 'predefine',
                'required' => array("renev_blog_page_title_switcher","equals","1")
            ),
            array(
                'id'       => 'renev_blog_page_custom_title',
                'type'     => 'text',
                'title'    => esc_html__('Blog Custom Title', 'renev'),
                'subtitle' => esc_html__('Set blog page custom title form here. If you use this option then you will able to set your won title text.', 'renev'),
                'required' => array('renev_blog_page_title_setting','equals','custom')
            ),
            array(
                'id'            => 'renev_blog_postExcerpt',
                'type'          => 'slider',
                'title'         => esc_html__('Blog Posts Excerpt', 'renev'),
                'subtitle'      => esc_html__('Control the number of characters you want to show in the blog page for each post.. If you use this option then you can able to control your blog post characters from here ( Default show 10 ).', 'renev'),
                "default"       => 46,
                "min"           => 0,
                "step"          => 1,
                "max"           => 100,
                'resolution'    => 1,
                'display_value' => 'text',
            ),
            array(
                'id'       => 'renev_blog_readmore_setting',
                'type'     => 'button_set',
                'title'    => esc_html__( 'Read More Text Setting', 'renev' ),
                'subtitle' => esc_html__( 'Control read more text from here.', 'renev' ),
                'options'  => array(
                    "default"   => esc_html__('Default','renev'),
                    "custom"    => esc_html__('Custom','renev'),
                ),
                'default'  => 'default',
            ),
            array(
                'id'       => 'renev_blog_bg',
                'type'     => 'background',
                'title'    => esc_html__( 'Background', 'renev' ),
                'subtitle' => esc_html__( 'Set the blog background. You can control background color, image, repeat, size, attachment, and position.', 'renev' ),
                'output'   => array( '.vl-blog-1-area' ),
            ),            
            array(
                'id'       => 'renev_blog_custom_readmore',
                'type'     => 'text',
                'title'    => esc_html__('Read More Text', 'renev'),
                'subtitle' => esc_html__('Set read moer text here. If you use this option then you will able to set your won text.', 'renev'),
                'required' => array('renev_blog_readmore_setting','equals','custom')
            ),
            array(
                'id'       => 'renev_blog_title_color',
                'output'   => array( '.fav-blog .blog-title a'),
                'type'     => 'color',
                'title'    => esc_html__( 'Blog Title Color', 'renev' ),
                'subtitle' => esc_html__( 'Set Blog Title Color.', 'renev' ),
            ),
            array(
                'id'       => 'renev_blog_title_hover_color',
                'output'   => array( '.fav-blog .blog-title a:hover'),
                'type'     => 'color',
                'title'    => esc_html__( 'Blog Title Hover Color', 'renev' ),
                'subtitle' => esc_html__( 'Set Blog Title Hover Color.', 'renev' ),
            ),
            array(
                'id'       => 'renev_blog_contant_color',
                'output'   => array( '.blog-standard-page__single-content .blog-text'),
                'type'     => 'color',
                'title'    => esc_html__( 'Blog Excerpt / Content Color', 'renev' ),
                'subtitle' => esc_html__( 'Set Blog Excerpt / Content Color.', 'renev' ),
            ),
            array(
                'id'       => 'renev_blog_read_more_button_color',
                'output'   => array( '.blog-standard-page__single-content .btn-box .thm-btn'),
                'type'     => 'color',
                'title'    => esc_html__( 'Read More Button Color', 'renev' ),
                'subtitle' => esc_html__( 'Set Read More Button Color.', 'renev' ),
            ),
            array(
                'id'       => 'renev_blog_read_more_button_hover_color',
                'output'   => array( '.blog-standard-page__single-content .btn-box .thm-btn:hover'),
                'type'     => 'color',
                'title'    => esc_html__( 'Read More Button Hover Color', 'renev' ),
                'subtitle' => esc_html__( 'Set Read More Button Hover Color.', 'renev' ),
            ),
            array(
                'id'       => 'renev_blog_read_more_button_bg_color',
                'type'     => 'color',
                'title'    => esc_html__( 'Read More Button Bg Color', 'renev' ),
                'subtitle' => esc_html__( 'Set Read More Button Bg Color', 'renev' ),
                'output'   => array( 'background-color'    =>  '.thm-btn:after' ),
            ),
            array(
                'id'       => 'renev_blog_read_more_button_hover_bg_color',
                'type'     => 'color',
                'title'    => esc_html__( 'Read More Button Hover Bg Color', 'renev' ),
                'subtitle' => esc_html__( 'Set Read More Button Hover Bg Color', 'renev' ),
                'output'   => array( 'background-color'    =>  '.blog-standard-page__single-content .btn-box .thm-btn::before' ),
            ),
            array(
                'id'       => 'renev_blog_pagination_color',
                'output'   => array( '.pagination-area ul li a, .pagination-area ul li span'),
                'type'     => 'color',
                'title'    => esc_html__( 'Blog Pagination Color', 'renev' ),
                'subtitle' => esc_html__( 'Set Blog Pagination Color.', 'renev' ),
            ),
            array(
                'id'       => 'renev_blog_pagination_active_color',
                'output'   => array( '.pagination-area ul li a.active, .pagination-area ul li span.active, .pagination-area ul li a.focus, .pagination-area ul li span.focus, .page-link:focus, .pagination-area ul li a:hover, .pagination-area ul li span:hover'),
                'type'     => 'color',
                'title'    => esc_html__( 'Blog Pagination Active & Hover Color', 'renev' ),
                'subtitle' => esc_html__( 'Set Blog Pagination Active & Hover Color.', 'renev' ),
            ),
            array(
                'id'       => 'renev_blog_pagination_bg_color',
                'output'   => array( 'background-color'    =>  '.pagination-area ul li a, .pagination-area ul li span' ),
                'type'     => 'color',
                'title'    => esc_html__('Blog Pagination Background Color', 'renev'),
                'subtitle' => esc_html__('Set Blog Pagination Background Color.', 'renev'),
            ),
            array(
                'id'       => 'renev_blog_pagination_bg_active_color',
                'output'   => array( 'background-color'    =>  '.pagination-area ul li a.active, .pagination-area ul li span.active, .pagination-area ul li a.focus, .pagination-area ul li span.focus, .page-link:focus, .pagination-area ul li a:hover, .pagination-area ul li span:hover' ),
                'type'     => 'color',
                'title'    => esc_html__('Blog Pagination Background Active & Hover Color', 'renev'),
                'subtitle' => esc_html__('Set Blog Pagination Background Active & Hover Color.', 'renev'),
            ),
        ),
    ) );

    Redux::setSection( $opt_name, array(
        'title'      => esc_html__( 'Single Blog Page', 'renev' ),
        'id'         => 'renev_post_detail_styles',
        'subsection' => true,
        'fields'     => array(

            array(
                'id'       => 'renev_blog_single_sidebar',
                'type'     => 'image_select',
                'title'    => esc_html__( 'Layout', 'renev' ),
                'subtitle' => esc_html__( 'Choose blog single page layout from here. If you use this option then you will able to change three type of blog single page layout ( Default Left Sidebar Layour ). ', 'renev' ),
                'options'  => array(
                    '1' => array(
                        'alt' => esc_attr__('1 Column','renev'),
                        'img' => esc_url( get_template_directory_uri(). '/assets/img/no-sideber.png')
                    ),
                    '2' => array(
                        'alt' => esc_attr__('2 Column Left','renev'),
                        'img' => esc_url( get_template_directory_uri() .'/assets/img/left-sideber.png')
                    ),
                    '3' => array(
                        'alt' => esc_attr__('2 Column Right','renev'),
                        'img' => esc_url(  get_template_directory_uri() .'/assets/img/right-sideber.png' )
                    ),

                ),
                'default'  => '3'
            ),
            array(
                'id'       => 'renev_post_details_title_position',
                'type'     => 'button_set',
                'default'  => 'header',
                'options'  => array(
                    'header'        => esc_html__('On Header','renev'),
                    'below'         => esc_html__('Below Thumbnail','renev'),
                ),
                'title'    => esc_html__('Blog Post Title Position', 'renev'),
                'subtitle' => esc_html__('Control blog post title position from here.', 'renev'),
            ),
            array(
                'id'       => 'renev_post_details_custom_title',
                'type'     => 'text',
                'title'    => esc_html__('Blog Details Custom Title', 'renev'),
                'subtitle' => esc_html__('This title will show in Breadcrumb title.', 'renev'),
                'required' => array('renev_post_details_title_position','equals','below')
            ),
            array(
                'id'       => 'renev_post_details_share_options',
                'type'     => 'switch',
                'title'    => esc_html__('Share Options', 'renev'),
                'subtitle' => esc_html__('Control post share options from here. If you use this option then you will able to show or hide post share options.', 'renev'),
                'on'        => esc_html__('Show','renev'),
                'off'       => esc_html__('Hide','renev'),
                'default'   => '0',
            ),
            array(
                'id'       => 'renev_post_details_related_post',
                'type'     => 'switch',
                'title'    => esc_html__('Related Post', 'renev'),
                'subtitle' => esc_html__('Control related post from here. If you use this option then you will able to show or hide related post ( Default setting Show ).', 'renev'),
                'on'        => esc_html__('Show','renev'),
                'off'       => esc_html__('Hide','renev'),
                'default'   => false,
            ),
            array(
                'id'       => 'renev_blog_related_post_bg',
                'type'     => 'background',
                'title'    => esc_html__( 'Background', 'renev' ),
                'subtitle' => esc_html__( 'Set the blog Related Post background. You can control background color, image, repeat, size, attachment, and position.', 'renev' ),
                'output'   => array( '.vl-blog-1-area.related-post' ),
                'required' => array("renev_post_details_related_post","equals","1")
            ),  
        )
    ));

    Redux::setSection( $opt_name, array(
        'title'      => esc_html__( 'Meta Data', 'renev' ),
        'id'         => 'renev_common_meta_data',
        'subsection' => true,
        'fields'     => array(
            array(
                'id'       => 'renev_blog_meta_icon_color',
                'output'   => array( '.blog-standard-page__single-content .meta-box li a i'),
                'type'     => 'color',
                'title'    => esc_html__('Blog Meta Icon Color', 'renev'),
                'subtitle' => esc_html__('Set Blog Meta Icon Color.', 'renev'),
            ),
            array(
                'id'       => 'renev_blog_meta_text_color',
                'output'   => array( '.blog-standard-page__single-content .meta-box li a'),
                'type'     => 'color',
                'title'    => esc_html__( 'Blog Meta Text Color', 'renev' ),
                'subtitle' => esc_html__( 'Set Blog Meta Text Color.', 'renev' ),
            ),
            array(
                'id'       => 'renev_blog_meta_text_hover_color',
                'output'   => array( '.blog-standard-page__single-content .meta-box li a:hover'),
                'type'     => 'color',
                'title'    => esc_html__( 'Blog Meta Hover Text Color', 'renev' ),
                'subtitle' => esc_html__( 'Set Blog Meta Hover Text Color.', 'renev' ),
            ),
            array(
                'id'       => 'renev_display_post_date',
                'type'     => 'switch',
                'title'    => esc_html__( 'Post Date', 'renev' ),
                'subtitle' => esc_html__( 'Switch On to Display Post Date.', 'renev' ),
                'default'  => true,
                'on'        => esc_html__('Enabled','renev'),
                'off'       => esc_html__('Disabled','renev'),
            ),
            array(
                'id'       => 'renev_display_post_author',
                'type'     => 'switch',
                'title'    => esc_html__( 'Post Author', 'renev' ),
                'subtitle' => esc_html__( 'Switch On to Display Post Author.', 'renev' ),
                'default'  => true,
                'on'        => esc_html__('Enabled','renev'),
                'off'       => esc_html__('Disabled','renev'),
            ),
            array(
                'id'       => 'renev_display_post_category',
                'type'     => 'switch',
                'title'    => esc_html__( 'Category', 'renev' ),
                'subtitle' => esc_html__( 'Switch On to Display Category.', 'renev' ),
                'default'  => true,
                'on'        => esc_html__('Enabled','renev'),
                'off'       => esc_html__('Disabled','renev'),
            ),
            array(
                'id'       => 'renev_display_post_tag',
                'type'     => 'switch',
                'title'    => esc_html__( 'tag', 'renev' ),
                'subtitle' => esc_html__( 'Switch On to Display Tag.', 'renev' ),
                'default'  => true,
                'on'        => esc_html__('Enabled','renev'),
                'off'       => esc_html__('Disabled','renev'),
            ),
        )
    ));

    /* Sidebar Start */
    Redux::setSection( $opt_name, array(
        'title'      => esc_html__( 'Sidebar Options', 'renev' ),
        'id'         => 'renev_sidebar_options',
        'subsection' => true,
        'fields'     => array(
            array(
                'id'      => 'renev_sidebar_bg_color',
                'type'    => 'color',
                'title'   => esc_html__('Widgets Background Color', 'renev'),
                'output'  => array('background-color'   => '.sidebar .widget')
            ),
            array(
                'id'      => 'renev_sidebar_padding_margin_box_shadow_trigger',
                'type'    => 'switch',
                'title'   => esc_html__('Widgets Custom Box Shadow/Padding/Margin/border', 'renev'),
                'on'      => esc_html__('Show','renev'),
                'off'     => esc_html__('Hide','renev'),
                'default' => false
            ),
            array(
                'id'      => 'box-shadow',
                'type'    => 'box_shadow',
                'title'   => esc_html__('Box Shadow', 'renev'),
                'units'   => array( 'px', 'em', 'rem' ),
                'output'  => ( '.sidebar .widget' ),
                'opacity' => true,
                'rgba'    => true,
                'required'=> array( 'renev_sidebar_padding_margin_box_shadow_trigger', 'equals' , '1' )
            ),
            array(
                'id'      => 'renev_sidebar_widget_margin',
                'type'    => 'spacing',
                'title'   => esc_html__('Widget Margin', 'renev'),
                'units'   => array('em', 'px'),
                'output'  => ( '.sidebar .widget+.widget' ),
                'mode'    => 'margin',
                'required'=> array( 'renev_sidebar_padding_margin_box_shadow_trigger', 'equals' , '1' )
            ),
            array(
                'id'      => 'renev_sidebar_widget_padding',
                'type'    => 'spacing',
                'title'   => esc_html__('Widget Padding', 'renev'),
                'units'   => array('em', 'px'),
                'output'  => ( '.sidebar .widget' ),
                'mode'    => 'padding',
                'required'=> array( 'renev_sidebar_padding_margin_box_shadow_trigger', 'equals' , '1' )
            ),
            array(
                'id'      => 'renev_sidebar_widget_border',
                'type'    => 'border',
                'title'   => esc_html__('Widget Border', 'renev'),
                'units'   => array('em', 'px'),
                'output'  => ( '.sidebar .widget' ),
                'all'     => false,
                'required'=> array( 'renev_sidebar_padding_margin_box_shadow_trigger', 'equals' , '1' )
            ),
            array(
                'id'      => 'renev_sidebar_widget_title_margin',
                'type'    => 'spacing',
                'title'   => esc_html__('Widget Title Margin', 'renev'),
                'mode'    => 'margin',
                'output'  => array('.sidebar .widget .widget_title, .widget .wp-block-search__label, .wp-block-heading'),
                'units'   => array('em', 'px'),
            ),
            array(
                'id'      => 'renev_sidebar_widget_title_padding',
                'type'    => 'spacing',
                'title'   => esc_html__('Widget Title Padding', 'renev'),
                'mode'    => 'padding',
                'output'  => array('.sidebar .widget .widget_title, .widget .wp-block-search__label, .wp-block-heading'),
                'units'   => array('em', 'px'),
            ),
            array(
                'id'       => 'renev_sidebar_widget_title_color',
                'output'   =>  array('.sidebar .widget .widget_title, .widget .wp-block-search__label, .wp-block-heading'),
                'type'     => 'color',
                'title'    => esc_html__('Widget Title Color', 'renev'),
                'subtitle' => esc_html__('Set Widget Title Color.', 'renev'),
            ),
            array(
                'id'       => 'renev_sidebar_widget_text_color',
                'output'   => array('.sidebar .widget'),
                'type'     => 'color',
                'title'    => esc_html__('Widget Text Color', 'renev'),
                'subtitle' => esc_html__('Set Widget Text Color.', 'renev'),
            ),
            array(
                'id'       => 'renev_sidebar_widget_anchor_color',
                'type'     => 'color',
                'output'   => array('.sidebar .widget a'),
                'title'    => esc_html__('Widget Anchor Color', 'renev'),
                'subtitle' => esc_html__('Set Widget Anchor Color.', 'renev'),
            ),
            array(
                'id'       => 'renev_sidebar_widget_anchor_hover_color',
                'type'     => 'color',
                'output'   => array('.sidebar .widget a:hover'),
                'title'    => esc_html__('Widget Hover Color', 'renev'),
                'subtitle' => esc_html__('Set Widget Anchor Hover Color.', 'renev'),
            )
        )
    ));
    /* Sidebar End */

    /* End blog Page */

    // -> START Page Option
    Redux::setSection( $opt_name, array(
        'title'      => esc_html__( 'Page', 'renev' ),
        'id'         => 'renev_page_page',
        'icon'  => 'el el-file',
        'fields'     => array(
            array(
                'id'       => 'renev_page_sidebar',
                'type'     => 'image_select',
                'title'    => esc_html__( 'Select layout', 'renev' ),
                'subtitle' => esc_html__( 'Choose your page layout. If you use this option then you will able to choose three type of page layout ( Default no sidebar ). ', 'renev' ),
                //Must provide key => value(array:title|img) pairs for radio options
                'options'  => array(
                    '1' => array(
                        'alt' => esc_attr__('1 Column','renev'),
                        'img' => esc_url( get_template_directory_uri(). '/assets/img/no-sideber.png')
                    ),
                    '2' => array(
                        'alt' => esc_attr__('2 Column Left','renev'),
                        'img' => esc_url( get_template_directory_uri() .'/assets/img/left-sideber.png')
                    ),
                    '3' => array(
                        'alt' => esc_attr__('2 Column Right','renev'),
                        'img' => esc_url(  get_template_directory_uri() .'/assets/img/right-sideber.png' )
                    ),

                ),
                'default'  => '1'
            ),
            array(
                'id'       => 'renev_page_layoutopt',
                'type'     => 'button_set',
                'title'    => esc_html__('Sidebar Settings', 'renev'),
                'subtitle' => esc_html__('Set page sidebar. If you use this option then you will able to set three type of sidebar ( Default no sidebar ).', 'renev'),
                //Must provide key => value pairs for options
                'options' => array(
                    '1' => esc_html__( 'Page Sidebar', 'renev' ),
                    '2' => esc_html__( 'Blog Sidebar', 'renev' )
                 ),
                'default' => '1',
                'required'  => array('renev_page_sidebar','!=','1')
            ),
            array(
                'id'       => 'renev_page_title_switcher',
                'type'     => 'switch',
                'title'    => esc_html__('Title', 'renev'),
                'subtitle' => esc_html__('Switch enabled to display page title. Fot this option you will able to show / hide page title.  Default setting Enabled', 'renev'),
                'default'  => '1',
                'on'        => esc_html__('Enabled','renev'),
                'off'       => esc_html__('Disabled','renev'),
            ),
            array(
                'id'       => 'renev_page_title_tag',
                'type'     => 'select',
                'options'  => array(
                    'h1'        => esc_html__('H1','renev'),
                    'h2'        => esc_html__('H2','renev'),
                    'h3'        => esc_html__('H3','renev'),
                    'h4'        => esc_html__('H4','renev'),
                    'h5'        => esc_html__('H5','renev'),
                    'h6'        => esc_html__('H6','renev'),
                ),
                'default'  => 'h1',
                'title'    => esc_html__( 'Title Tag', 'renev' ),
                'subtitle' => esc_html__( 'Select page title tag. If you use this option then you can able to change title tag H1 - H6 ( Default tag H1 )', 'renev' ),
                'required' => array("renev_page_title_switcher","equals","1")
            ),
            array(
                'id'       => 'renev_allHeader_title_color',
                'type'     => 'color',
                'title'    => esc_html__( 'Title Color', 'renev' ),
                'subtitle' => esc_html__( 'Set Title Color', 'renev' ),
                'output'   => array( 'color' => '.inner-section-area .hero-header-area h1' ),
            ),
            array(
                'id'       => 'renev_allHeader_bg',
                'type'     => 'background',
                'title'    => esc_html__( 'Background', 'renev' ),
                'output'   => array('.inner-section-area'),
                'subtitle' => esc_html__( 'Setting page header background. If you use this option then you will able to set Background Color, Background Image, Background Repeat, Background Size, Background Attachment, Background Position.', 'renev' ),
            ),
            array(
                'id'       => 'renev_enable_breadcrumb',
                'type'     => 'switch',
                'title'    => esc_html__( 'Breadcrumb Hide/Show', 'renev' ),
                'subtitle' => esc_html__( 'Hide / Show breadcrumb from all pages and posts ( Default settings hide ).', 'renev' ),
                'default'  => '1',
                'on'       => 'Show',
                'off'      => 'Hide',
            ),
            array(
                'id'         => 'renev_breadcrumb_padding',
                'type'       => 'spacing',
                'title'      => esc_html__('Breadcrumb Padding', 'renev'),
                'units'      => array('em', 'px'),
                'output'     => array('.inner-section-area'),
                'mode'       => 'padding',
                'responsive' => true, // Enables responsive settings
            ),                      
            array(
                'id'       => 'renev_allHeader_breadcrumbtextcolor',
                'type'     => 'color',
                'title'    => esc_html__( 'Breadcrumb Text Color', 'renev' ),
                'subtitle' => esc_html__( 'Choose page header breadcrumb text color here.If you user this option then you will able to set page breadcrumb color.', 'renev' ),
                'required' => array("renev_page_title_switcher","equals","1"),
                'output'   => array( 'color' => '.inner-section-area .hero-header-area h4 a' ),
            ),
            array(
                'id'       => 'renev_allHeader_dividercolor',
                'type'     => 'color',
                'output'   => array( 'color'=>'.inner-section-area .hero-header-area h4 i' ),
                'title'    => esc_html__( 'Breadcrumb Divider Color', 'renev' ),
                'subtitle' => esc_html__( 'Choose breadcrumb divider color.', 'renev' ),
            ),
            array(
                'id'       => 'renev_enable_breadcrumb_right_image',
                'type'     => 'switch',
                'title'    => esc_html__( 'Breadcrumb Image Hide/Show', 'renev' ),
                'subtitle' => esc_html__( 'Hide / Show breadcrumb image from all pages and posts.', 'renev' ),
                'default'  => '1',
                'on'       => 'Show',
                'off'      => 'Hide',
            ),
            array(
                'id'       => 'renev_breadcrumb_main_image',
                'type'     => 'media',
                'title'    => esc_html__( 'Breadcrumb Main Image', 'renev' ),
                'url'      => true,
                'desc'     => esc_html__( 'Upload or select an image for the Breadcrumb Main.', 'renev' ),
                'required' => array("renev_enable_breadcrumb_right_image","equals","1"),
            ),
            array(
                'id'       => 'renev_breadcrumb_image_two',
                'type'     => 'media',
                'title'    => esc_html__( 'Breadcrumb Image Two', 'renev' ),
                'url'      => true,
                'desc'     => esc_html__( 'Upload or select an image for the Breadcrumb Two.', 'renev' ),
                'required' => array("renev_enable_breadcrumb_right_image","equals","1"),
            ),
            array(
                'id'       => 'renev_breadcrumb_image_three',
                'type'     => 'media',
                'title'    => esc_html__( 'Breadcrumb Image Three', 'renev' ),
                'url'      => true,
                'desc'     => esc_html__( 'Upload or select an image for the Breadcrumb Three.', 'renev' ),
                'required' => array("renev_enable_breadcrumb_right_image","equals","1"),
            ),
            array(
                'id'       => 'renev_breadcrumb_image_link',
                'type'     => 'text',
                'title'    => esc_html__( 'Breadcrumb Image Link', 'renev' ),
                'default'  => '#',
                'required' => array("renev_enable_breadcrumb_right_image","equals","1"),
            ),            
        ),
    ) );
    /* End Page option */

    // -> START 404 Page

    Redux::setSection( $opt_name, array(
        'title'      => esc_html__( '404 Page', 'renev' ),
        'id'         => 'renev_404_page',
        'icon'       => 'el el-ban-circle',
        'fields'     => array(

            array(
                'title'     => esc_html__( '404 Page Background', 'renev' ),
                'subtitle'  => esc_html__( 'Add Your 404 Page Background Image', 'renev' ),
                'id'        => 'renev_error_bg',
                'type'      => 'background',
                'output'   => array( '.page-header__bg::after' ),
            ),
            array(
                'id'       => 'renev_fof_text_color',
                'type'     => 'color',
                'output'   => array( '.page-header__inner .breadcumb-title' ),
                'title'    => esc_html__( 'Title Color', 'renev' ),
                'subtitle' => esc_html__( 'Pick a title color', 'renev' ),
                'validate' => 'color'
            ),
        ),
    ) );

    /* End 404 Page */


    

    // -> START Footer Media
    Redux::setSection( $opt_name , array(
       'title'            => esc_html__( 'Footer', 'renev' ),
       'id'               => 'renev_footer',
       'desc'             => esc_html__( 'renev Footer', 'renev' ),
       'customizer_width' => '400px',
       'icon'              => 'el el-photo',
   ) );

   Redux::setSection( $opt_name, array(
       'title'      => esc_html__( 'Pre-built Footer / Footer Builder', 'renev' ),
       'id'         => 'renev_footer_section',
       'subsection' => true,
       'fields'     => array(
            array(
               'id'       => 'renev_footer_builder_trigger',
               'type'     => 'button_set',
               'default'  => 'prebuilt',
               'options'  => array(
                   'footer_builder'        => esc_html__('Footer Builder','renev'),
                   'prebuilt'              => esc_html__('Pre-built Footer','renev'),
               ),
               'title'    => esc_html__( 'Footer Builder', 'renev' ),
            ),
            array(
               'id'       => 'renev_footer_builder_select',
               'type'     => 'select',
               'required' => array( 'renev_footer_builder_trigger','equals','footer_builder'),
               'data'     => 'posts',
               'args'     => array(
                   'post_type'     => 'renev_footer'
               ),
               'on'       => esc_html__( 'Enabled', 'renev' ),
               'off'      => esc_html__( 'Disable', 'renev' ),
               'title'    => esc_html__( 'Select Footer', 'renev' ),
               'subtitle' => esc_html__( 'First make your footer from footer custom types then select it from here.', 'renev' ),
            ),
           array(
               'id'       => 'renev_disable_footer_bottom',
               'type'     => 'switch',
               'title'    => esc_html__( 'Footer Bottom?', 'renev' ),
               'default'  => 1,
               'on'       => esc_html__('Enabled','renev'),
               'off'      => esc_html__('Disable','renev'),
               'required' => array('renev_footer_builder_trigger','equals','prebuilt'),
            ),
            array(
               'id'       => 'renev_footer_bottom_background',
               'type'     => 'color',
               'title'    => esc_html__( 'Footer Bottom Background Color', 'renev' ),
               'required' => array( 'renev_disable_footer_bottom','=','1' ),
               'output'   => array( 'background-color'   =>   '.footer-copyright' ),
            ),
            array(
               'id'       => 'renev_copyright_text',
               'type'     => 'text',
               'title'    => esc_html__( 'Copyright hello Text', 'renev' ),
               'subtitle' => esc_html__( 'Add Copyright Text', 'renev' ),
               'default'  => sprintf( 'Copyright <i class="fas fa-copyright"></i> %s <a  href="%s">%s</a> All afa Rights Reserved by <a  href="%s">%s</a>',date('Y'),esc_url('#'),__( 'Renev.','renev' ),esc_url('#'),__( 'Mthemeus', 'renev' ) ),
               'required' => array( 'renev_disable_footer_bottom','equals','1' ),
            ),
            array(
               'id'       => 'renev_footer_copyright_color',
               'type'     => 'color',
               'title'    => esc_html__( 'Footer Copyright Text Color', 'renev' ),
               'subtitle' => esc_html__( 'Set footer copyright text color', 'renev' ),
               'required' => array( 'renev_disable_footer_bottom','equals','1'),
               'output'   => array( '.footer-copyright p' ),
            ),
            array(
               'id'       => 'renev_footer_copyright_acolor',
               'type'     => 'color',
               'title'    => esc_html__( 'Footer Copyright Ancor Color', 'renev' ),
               'subtitle' => esc_html__( 'Set footer copyright ancor color', 'renev' ),
               'required' => array( 'renev_disable_footer_bottom','equals','1'),
               'output'   => array( '.footer-copyright p a' ),
            ),
            array(
               'id'       => 'renev_footer_copyright_a_hover_color',
               'type'     => 'color',
               'title'    => esc_html__( 'Footer Copyright Ancor Hover Color', 'renev' ),
               'subtitle' => esc_html__( 'Set footer copyright ancor Hover color', 'renev' ),
               'required' => array( 'renev_disable_footer_bottom','equals','1'),
               'output'   => array( '.footer-copyright p a:hover' ),
            ),

       ),
   ) );

    Redux::setSection( $opt_name, array(
        'icon'             => 'fas fa-arrow-up',
        'title'            => esc_html__( 'Back to top', 'renev' ),
        'id'               => 'renev_back_to_top',
        'subsection'       => false,
        'fields'           => array(
            array(
                'id'       => 'renev_display_back_to_top',
                'type'     => 'switch',
                'title'    => esc_html__( 'Back to top', 'renev' ),
                'subtitle' => esc_html__( 'Switch Enabled to Display Back to top.', 'renev' ),
                'default'  => true,
                'on'       => esc_html__('Enabled','renev'),
                'off'      => esc_html__('Disabled','renev'),
            ),
            array(
                'id'       => 'renev_scroll_icon_color',
                'type'     => 'color',
                'title'    => esc_html__( 'Icon Color', 'renev' ),
                'subtitle' => esc_html__( 'Set Icon Color', 'renev' ),
                'output'   => array( 'color'    =>  '.progress-wrap::after' ),
                'required' => array( 'renev_display_back_to_top','equals','1'),
            ),
            array(
                'id'       => 'renev_scroll_icon_border_color',
                'type'     => 'color',
                'title'    => esc_html__( 'Border Color', 'renev' ),
                'subtitle' => esc_html__( 'Set Border Color', 'renev' ),
                'output'   => array( 'stroke'    =>  '.progress-wrap svg.progress-circle path' ),
                'required' => array( 'renev_display_back_to_top','equals','1'),
            ),
        )
    ));

    // -> START Gallary Gallery Widget
    Redux::setSection( $opt_name, array(
        'title'      => esc_html__( 'Gallary Widget', 'renev' ),
        'id'         => 'renev_gallery_media',
        'icon'      => 'el el-camera',
        'desc'      => esc_html__( 'Gallary Widget', 'renev' ),
        'fields'     => array(
            array(
                'id'          => 'renev_gallery_image_widget',
                'type'        => 'slides',
                'title'       => esc_html__('Gallery Images', 'renev'),
                'show'        => array(
                    'title'          => false,
                    'description'    => false,
                    'progress'       => false,
                    'facts-number'   => false,
                    'facts-title1'   => false,  
                    'facts-title2'   => false,
                    'facts-number-2' => false,
                    'facts-title3'   => false,
                    'facts-number-3' => false,
                    'url'            => true,
                    'project-button' => false,
                    'image_upload'   => true,
                ),
            ),
        ),
    ) );


    /* End Footer Media */

    // -> START Custom Css
    Redux::setSection( $opt_name, array(
        'title'      => esc_html__( 'Custom Css', 'renev' ),
        'id'         => 'renev_custom_css_section',
        'icon'  => 'el el-css',
        'fields'     => array(
            array(
                'id'       => 'renev_css_editor',
                'type'     => 'ace_editor',
                'title'    => esc_html__('CSS Code', 'renev'),
                'subtitle' => esc_html__('Paste your CSS code here.', 'renev'),
                'mode'     => 'css',
                'theme'    => 'monokai',
            )
        ),
    ) );

    /* End custom css */



    if ( file_exists( dirname( __FILE__ ) . '/../README.md' ) ) {
        $section = array(
            'icon'   => 'el el-list-alt',
            'title'  => __( 'Documentation', 'renev' ),
            'fields' => array(
                array(
                    'id'       => '17',
                    'type'     => 'raw',
                    'markdown' => true,
                    'content_path' => dirname( __FILE__ ) . '/../README.md', // FULL PATH, not relative please
                    //'content' => 'Raw content here',
                ),
            ),
        );
        Redux::setSection( $opt_name, $section );
    }
    /*
     * <--- END SECTIONS
     */


    /*
     *
     * YOU MUST PREFIX THE FUNCTIONS BELOW AND ACTION FUNCTION CALLS OR ANY OTHER CONFIG MAY OVERRIDE YOUR CODE.
     *
     */

    /**
     * This is a test function that will let you see when the compiler hook occurs.
     * It only runs if a field    set with compiler=>true is changed.
     * */
    if ( ! function_exists( 'compiler_action' ) ) {
        function compiler_action( $options, $css, $changed_values ) {
            echo '<h1>The compiler hook has run!</h1>';
            echo "<pre>";
            print_r( $changed_values ); // Values that have changed since the last save
            echo "</pre>";
            //print_r($options); //Option values
            //print_r($css); // Compiler selector CSS values  compiler => array( CSS SELECTORS )
        }
    }

    /**
     * Custom function for the callback validation referenced above
     * */
    if ( ! function_exists( 'redux_validate_callback_function' ) ) {
        function redux_validate_callback_function( $field, $value, $existing_value ) {
            $error   = false;
            $warning = false;

            //do your validation
            if ( $value == 1 ) {
                $error = true;
                $value = $existing_value;
            } elseif ( $value == 2 ) {
                $warning = true;
                $value   = $existing_value;
            }

            $return['value'] = $value;

            if ( $error == true ) {
                $field['msg']    = 'your custom error message';
                $return['error'] = $field;
            }

            if ( $warning == true ) {
                $field['msg']      = 'your custom warning message';
                $return['warning'] = $field;
            }

            return $return;
        }
    }

    /**
     * Custom function for the callback referenced above
     */
    if ( ! function_exists( 'redux_my_custom_field' ) ) {
        function redux_my_custom_field( $field, $value ) {
            print_r( $field );
            echo '<br/>';
            print_r( $value );
        }
    }

    /**
     * Custom function for filtering the sections array. Good for child themes to override or add to the sections.
     * Simply include this function in the child themes functions.php file.
     * NOTE: the defined constants for URLs, and directories will NOT be available at this point in a child theme,
     * so you must use get_template_directory_uri() if you want to use any of the built in icons
     * */
    if ( ! function_exists( 'dynamic_section' ) ) {
        function dynamic_section( $sections ) {
            //$sections = array();
            $sections[] = array(
                'title'  => __( 'Section via hook', 'renev' ),
                'desc'   => __( '<p class="description">This is a section created by adding a filter to the sections array. Can be used by child themes to add/remove sections from the options.</p>', 'renev' ),
                'icon'   => 'el el-paper-clip',
                // Leave this as a blank section, no options just some intro text set above.
                'fields' => array()
            );

            return $sections;
        }
    }

    /**
     * Filter hook for filtering the args. Good for child themes to override or add to the args array. Can also be used in other functions.
     * */
    if ( ! function_exists( 'change_arguments' ) ) {
        function change_arguments( $args ) {
            //$args['dev_mode'] = true;

            return $args;
        }
    }

    /**
     * Filter hook for filtering the default value of any given field. Very useful in development mode.
     * */
    if ( ! function_exists( 'change_defaults' ) ) {
        function change_defaults( $defaults ) {
            $defaults['str_replace'] = 'Testing filter hook!';

            return $defaults;
        }
    }