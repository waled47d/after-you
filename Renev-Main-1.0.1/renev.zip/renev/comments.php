<?php
/**
 * @Packge     : Renev
 * @Version    : 1.0
 * @Author     : Mthemeus
 * @Author URI : https://www.mthemeus.com/
 *
 */

    // Block direct access
    if( ! defined( 'ABSPATH' ) ){
        exit();
    }

    if ( post_password_required() ) {
        return;
    }


    if( have_comments() ) :
?>
<!-- Comments -->
<div class="comments-wrap mt-60">
    <?php 
        $comments_number = get_comments_number();

        if ( $comments_number == 1 ) {
            $comment_text = __( 'Blog Comment', 'renev' );
        } else {
            $comment_text = __( 'Blog Comments', 'renev' );
        }
    ?>
    <h3>
        <?php echo esc_html($comment_text); ?> 
        (<?php printf( '%02d', number_format_i18n( $comments_number ) ); ?>)
    </h3>


    <div class="latest-comments">
        <ul class="list-wrap">
            <?php
                the_comments_navigation();
                    wp_list_comments( array(
                        'style'       => 'ul',
                        'short_ping'  => true,
                        'avatar_size' => 100,
                        'callback'    => 'renev_comment_callback'
                    ) );
                the_comments_navigation();
            ?>
        </ul>
    </div>

</div>

<!-- End of Comments -->
<?php
    endif;
?>

<?php
    $commenter = wp_get_current_commenter();
	$req = get_option( 'require_name_email' );
    $aria_req = ( $req ? "required" : '' );

    $consent = empty( $commenter['comment_author_email'] ) ? '' : ' checked="checked"';
    
	$fields =  array(
        'author'                => '<div class="row"><div class="col-lg-6"><div class="input-area"><input type="text" name="author" placeholder="'. esc_attr__( 'Your Name', 'renev' ) .'" value="'. esc_attr( $commenter['comment_author'] ).'" '.esc_attr( $aria_req ).'></div></div>',
        'email'                 => '<div class="col-lg-6"><div class="input-area"><input type="email" name="email"  value="' . esc_attr(  $commenter['comment_author_email'] ) .'" placeholder="'. esc_attr__( 'Email Address', 'renev' ) .'" '.esc_attr( $aria_req ).'></div></div></div>',
        'url'                   => '',
        'cookies'               => '<div class="row"><div class="col-12"><div class="custom-checkbox notice"><input id="wp-comment-cookies-consent" name="wp-comment-cookies-consent" type="checkbox" value="yes"' . esc_attr( $consent ) . ' />' . '<label for="wp-comment-cookies-consent">'  . esc_html__( ' Save my name, email, and website in this browser for the next time I comment.','renev' ) .  '<span class="checkmark"></span> </label> </div></div></div>'
    );

	$args = array(
    	'comment_field'         => '<div class="row"><div class="col-lg-12"><div class="input-area"><textarea name="comment" placeholder="' . esc_attr__( 'Your Message', 'renev' ) . '" ' . esc_attr( $aria_req ) . '></textarea></div></div></div>',
        'class_form'            => 'contact-boxarea',
    	'title_reply'           => esc_html__( 'Leave A Reply Now', 'renev' ),
    	'title_reply_before'    => '<h3 class="title-reply">',
        'title_reply_after'     => '</h3>',
        'comment_notes_before'  => '<h3>'.esc_html__('Send Us A Message','renev').'</h3><p class="comment-notes"><span>'.esc_html__('Your email address will not be published. Required fields are marked *','renev').'</span></p>',
        'logged_in_as'          => '<p class="logged-in-as">' . sprintf( __( 'Logged in as <a href="%1$s">%2$s</a>. <a href="%3$s" title="Log out of this account">Log out?</a>','renev' ), admin_url( 'profile.php' ), esc_attr( $user_identity ), wp_logout_url( apply_filters( 'the_permalink', get_permalink( ) ) ) ) . '</p>',
        'class_submit'          => 'fav-btn style1',
        'submit_field'          => '<div class="row"><div class="col-lg-12"><div class="input-area">%1$s %2$s</div></div></div>',
    	'submit_button'         => '<button type="submit" name="%1$s" id="%2$s" class="vl-btn1">'.esc_html__('Leave A Reply Now','renev').'</button>',
    	'fields'                => $fields,
	);

    if(  comments_open() ) {
        echo '<!-- Comment Form -->';
            comment_form( $args );
        echo '<!-- End of Comment Form -->';
    }
