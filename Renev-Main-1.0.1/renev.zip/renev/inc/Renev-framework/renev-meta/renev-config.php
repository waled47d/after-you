<?php

/**
 * Include and setup custom metaboxes and fields. (make sure you copy this file to outside the CMB2 directory)
 *
 * Be sure to replace all instances of 'yourprefix_' with your project's prefix.
 * http://nacin.com/2010/05/11/in-wordpress-prefix-everything/
 *
 * @category YourThemeOrPlugin
 * @package  Demo_CMB2
 * @license  http://www.opensource.org/licenses/gpl-license.php GPL v2.0 (or later)
 * @link     https://github.com/WebDevStudios/CMB2
 */

 /**
 * Only return default value if we don't have a post ID (in the 'post' query variable)
 *
 * @param  bool  $default On/Off (true/false)
 * @return mixed          Returns true or '', the blank default
 */
function renev_set_checkbox_default_for_new_post( $default ) {
	return isset( $_GET['post'] ) ? '' : ( $default ? (string) $default : '' );
}

add_action( 'cmb2_admin_init', 'renev_register_metabox' );

/**
 * Hook in and add a demo metabox. Can only happen on the 'cmb2_admin_init' or 'cmb2_init' hook.
 */

function renev_register_metabox() {

	$prefix = '_renev_';

	$prefixpage = '_renevpage_';

	$renev_service_meta = new_cmb2_box( array(
		'id'            => $prefixpage . 'service_page_control',
		'title'         => esc_html__( 'Service Page Controller', 'renev' ),
		'object_types'  => array( 'renev_service' ), // Post type
		'closed'        => true
	) );
	

	$renev_post_meta = new_cmb2_box( array(
		'id'            => $prefixpage . 'blog_post_control',
		'title'         => esc_html__( 'Post Thumb Controller', 'renev' ),
		'object_types'  => array( 'post' ), // Post type
		'closed'        => true
	) );
	$renev_post_meta->add_field( array(
		'name' => esc_html__( 'Post Format Video', 'renev' ),
		'desc' => esc_html__( 'Use This Field When Post Format Video', 'renev' ),
		'id'   => $prefix . 'post_format_video',
        'type' => 'text_url',
    ) );
	$renev_post_meta->add_field( array(
		'name' => esc_html__( 'Post Format Audio', 'renev' ),
		'desc' => esc_html__( 'Use This Field When Post Format Audio', 'renev' ),
		'id'   => $prefix . 'post_format_audio',
        'type' => 'oembed',
    ) );
	$renev_post_meta->add_field( array(
		'name' => esc_html__( 'Post Thumbnail For Slider', 'renev' ),
		'desc' => esc_html__( 'Use This Field When You Want A Slider In Post Thumbnail', 'renev' ),
		'id'   => $prefix . 'post_format_slider',
        'type' => 'file_list',
    ) );

	$renev_page_meta = new_cmb2_box( array(
		'id'            => $prefixpage . 'page_meta_section',
		'title'         => esc_html__( 'Page Meta', 'renev' ),
		'object_types'  => array( 'page' ), // Post type
        'closed'        => true
    ) );

    $renev_page_meta->add_field( array(
		'name' => esc_html__( 'Page Breadcrumb Area', 'renev' ),
		'desc' => esc_html__( 'check to display page breadcrumb area.', 'renev' ),
		'id'   => $prefix . 'page_breadcrumb_area',
        'type' => 'select',
        'default' => '1',
        'options'   => array(
            '1'   => esc_html__('Show','renev'),
            '2'     => esc_html__('Hide','renev'),
        )
    ) );


    $renev_page_meta->add_field( array(
		'name' => esc_html__( 'Page Breadcrumb Settings', 'renev' ),
		'id'   => $prefix . 'page_breadcrumb_settings',
        'type' => 'select',
        'default'   => 'global',
        'options'   => array(
            'global'   => esc_html__( 'Global Settings', 'renev' ),
            'page'     => esc_html__( 'Page Settings', 'renev' ),
        )
	) );

	$renev_page_meta->add_field( array(
	    'name'    => esc_html__( 'Breadcumb Right Image', 'renev' ),
	    'desc'    => esc_html__( 'Upload an image or enter an URL.', 'renev' ),
	    'id'      => $prefix . 'breadcumb_image',
	    'type'    => 'file',
	    // Optional:
	    'options' => array(
	        'url' => false, // Hide the text input for the url
	    ),
	    'text'    => array(
	        'add_upload_file_text' => __( 'Add File', 'renev' ) // Change upload button text. Default: "Add or Upload File"
	    ),
	    'preview_size' => 'large', // Image size to use when previewing in the admin.
	) );

    $renev_page_meta->add_field( array(
		'name' => esc_html__( 'Page Title', 'renev' ),
		'desc' => esc_html__( 'check to display Page Title.', 'renev' ),
		'id'   => $prefix . 'page_title',
        'type' => 'select',
        'default' => '1',
        'options'   => array(
            '1'   	=> esc_html__( 'Show','renev'),
            '2'     => esc_html__( 'Hide','renev'),
        )
	) );

    $renev_page_meta->add_field( array(
		'name' => esc_html__( 'Page Title Settings', 'renev' ),
		'id'   => $prefix . 'page_title_settings',
        'type' => 'select',
        'options'   => array(
            'default'  => esc_html__('Default Title','renev'),
            'custom'  => esc_html__('Custom Title','renev'),
        ),
        'default'   => 'default'
    ) );

    $renev_page_meta->add_field( array(
		'name' => esc_html__( 'Custom Page Title', 'renev' ),
		'id'   => $prefix . 'custom_page_title',
        'type' => 'text'
    ) );

    $renev_page_meta->add_field( array(
		'name' => esc_html__( 'Breadcrumb', 'renev' ),
		'desc' => esc_html__( 'Select Show to display breadcrumb area', 'renev' ),
		'id'   => $prefix . 'page_breadcrumb_trigger',
        'type' => 'switch_btn',
        'default' => renev_set_checkbox_default_for_new_post( true ),
    ) );

    $renev_layout_meta = new_cmb2_box( array(
		'id'            => $prefixpage . 'page_layout_section',
		'title'         => esc_html__( 'Page Layout', 'renev' ),
        'context' 		=> 'side',
        'priority' 		=> 'high',
        'object_types'  => array( 'page' ), // Post type
        'closed'        => true
	) );

	$renev_layout_meta->add_field( array(
		'desc'       => esc_html__( 'Set page layout container,container fluid,fullwidth or both. It\'s work only in template builder page.', 'renev' ),
		'id'         => $prefix . 'custom_page_layout',
		'type'       => 'radio',
        'options' => array(
            '1' => esc_html__( 'Container', 'renev' ),
            '2' => esc_html__( 'Container Fluid', 'renev' ),
            '3' => esc_html__( 'Fullwidth', 'renev' ),
        ),
	) );

	$renev_product_meta = new_cmb2_box( array(
		'id'            => $prefixpage . 'product_meta_section',
		'title'         => esc_html__( 'Swap Image', 'renev' ),
		'object_types'  => array( 'product' ), // Post type
		'closed'        => true,
		'context'		=> 'side',
		'priority'		=> 'default'
	) );

	$renev_product_meta->add_field( array(
		'name' 		=> esc_html__( 'Product Swap Image', 'renev' ),
		'desc' 		=> esc_html__( 'Set Product Swap Image', 'renev' ),
		'id'   		=> $prefix.'product_swap_image',
		'type'    	=> 'file',
		// Optional:
		'options' 	=> array(
			'url' 		=> false, // Hide the text input for the url
		),
		'text'    	=> array(
			'add_upload_file_text' => __( 'Add Swap Image', 'renev' ) // Change upload button text. Default: "Add or Upload File"
		),
	) );
}

add_action( 'cmb2_admin_init', 'renev_register_taxonomy_metabox' );
/**
 * Hook in and add a metabox to add fields to taxonomy terms
 */
function renev_register_taxonomy_metabox() {

    $prefix = '_renev_';
	/**
	 * Metabox to add fields to categories and tags
	 */
	$renev_term_meta = new_cmb2_box( array(
		'id'               => $prefix.'term_edit',
		'title'            => esc_html__( 'Category Metabox', 'renev' ),
		'object_types'     => array( 'term' ),
		'taxonomies'       => array( 'category'),
	) );
	$renev_term_meta->add_field( array(
		'name'     => esc_html__( 'Extra Info', 'renev' ),
		'id'       => $prefix.'term_extra_info',
		'type'     => 'title',
		'on_front' => false,
	) );
	$renev_term_meta->add_field( array(
		'name' => esc_html__( 'Category Image', 'renev' ),
		'desc' => esc_html__( 'Set Category Image', 'renev' ),
		'id'   => $prefix.'term_avatar',
        'type' => 'file',
        'text'    => array(
			'add_upload_file_text' => esc_html__('Add Image','renev') // Change upload button text. Default: "Add or Upload File"
		),
	) );



	/**
	 * Metabox to add fields to events
	 */
	$renev_term_events = new_cmb2_box( array(
		'id'               => $prefix.'events',
		'title'            => esc_html__( 'Events Metabox', 'renev' ),
		'object_types'     => array( 'renev_event' ),
	) );
	$renev_term_events->add_field( array(
		'name'     => esc_html__( 'Event Date', 'renev' ),
		'id'       => $prefix.'event_date',
		'type'     => 'text_date_timestamp',
	) );
	$renev_term_events->add_field( array(
		'name'     => esc_html__( 'Event Time', 'renev' ),
		'id'       => $prefix.'event_time',
		'type'     => 'text',
		'default'  => esc_html__( '8:00 AM - 5:00 PM','renev' ),
	) );
	$renev_term_events->add_field( array(
		'name'     => esc_html__( 'Event Type', 'renev' ),
		'id'       => $prefix.'event_type',
		'type'     => 'text',
		'default'  => esc_html__( 'Online','renev' ),
	) );
	$renev_term_events->add_field( array(
		'name'     => esc_html__( 'Event Speaker', 'renev' ),
		'id'       => $prefix.'event_speaker',
		'type'     => 'text',
		'default'  => esc_html__( '20 Speaker','renev' ),
	) );

	

	/**
	 * Metabox to add fields to class widget
	 */
	
	 $renev_term_class = new_cmb2_box( array(
		'id'               => $prefix.'class',
		'title'            => esc_html__( 'class Metabox', 'renev' ),
		'object_types'     => array( 'renev_class' ),
	) );

	$renev_term_class->add_field( array(
		'name'     => esc_html__( 'Class Info', 'renev' ),
		'id'       => $prefix.'class_list',
		'type'     => 'wysiwyg',
		'default'  => esc_html__( '11 - 13 Years','renev' ),
	) );


	$renev_term_class->add_field( array(
		'name'     => esc_html__( 'Price', 'renev' ),
		'id'       => $prefix.'class_price',
		'type'     => 'text',
		'default'  => esc_html__( '$29','renev' ),
	) );
	
	$renev_term_class->add_field( array(
		'name'     => esc_html__( 'Duration', 'renev' ),
		'id'       => $prefix.'class_duration',
		'type'     => 'text',
		'default'  => esc_html__( '/ month','renev' ),
	) );


	/**
	 * Metabox to add fields to Teachers widget
	 */
	
	 $renev_term_teachers = new_cmb2_box( array(
		'id'               => $prefix.'teachers',
		'title'            => esc_html__( 'Teachers Metabox', 'renev' ),
		'object_types'     => array( 'renev_teacher' ),
	) );

	$renev_term_teachers->add_field( array(
		'name'     => esc_html__( 'Designation', 'renev' ),
		'id'       => $prefix.'teachers_designation',
		'type'     => 'text',
		'default'  => esc_html__( 'Principal and Manager','renev' ),
	) );

	$renev_term_teachers->add_field( array(
		'name'     => esc_html__( 'Phone Number', 'renev' ),
		'id'       => $prefix.'teachers_number',
		'type'     => 'text',
		'default'  => esc_html__( '+44 (0) 207 689 7888','renev' ),
	) );

	$profiles_group = $renev_term_teachers->add_field( array(
        'id'          => $prefix . 'profiles',
        'type'        => 'group',
        'description' => __( 'Add social profiles', 'renev' ),
        'options'     => array(
            'group_title'   => __( 'Profile {#}', 'renev' ),
            'add_button'    => __( 'Add Another Profile', 'renev' ),
            'remove_button' => __( 'Remove Profile', 'renev' ),
            'sortable'      => true,
        ),
    ) );

    // Add fields to the repeatable group
    $renev_term_teachers->add_group_field( $profiles_group, array(
        'name' => __( 'Social Network', 'renev' ),
        'id'   => 'network',
        'type' => 'text',
    ) );

    $renev_term_teachers->add_group_field( $profiles_group, array(
        'name' => __( 'Profile URL', 'renev' ),
        'id'   => 'url',
        'type' => 'text_url',
    ) );

}
