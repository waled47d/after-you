<div class="images-area">
    <img src="<?php echo esc_url( $settings['shape-img']['url'] ); ?>" alt="" class="elements17 keyframe6">
    <img src="<?php echo esc_url( $settings['circle-img']['url'] ); ?>" alt="" class="elements18 keyframe5">
    <div class="img1 reveal">
        <img src="<?php echo esc_url( $settings['image_one']['url'] ); ?>" alt="">
    </div>
</div>