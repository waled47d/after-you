<?php
use \Elementor\Widget_Base;
use \Elementor\Controls_Manager;
use \Elementor\Group_Control_Background;
use \Elementor\Icons_Manager;
use \Elementor\Group_Control_Typography;
use \Elementor\Group_Control_Border;
use \Elementor\Group_Control_Box_Shadow;
use \Elementor\Repeater;
use \Elementor\Utils;
/**
 *
 * Text Slider Widget .
 *
 */
class Renev_Text_Slider extends Widget_Base {

	public function get_name() {
		return 'renev_text_slider';
	}

	public function get_title() {
		return __( 'Renev Text Slider', 'renev' );
	}

	public function get_icon() {
		return 'eicon-code';
    }

	public function get_categories() {
		return [ 'renev' ];
	}

	protected function register_controls() {

        // Text Slider
        $this->start_controls_section('slider_section',
            [
                'label' => __('Text Slider', 'renev'),
                'tab'   => Controls_Manager::TAB_CONTENT,
            ]
        );
        $this->add_control(
            'textslider_layout',
            [
                'label' => esc_html__('Select Layout', 'renev'),
                'type' => Controls_Manager::SELECT,
                'options' => [
                    'layout-1' => esc_html__('Layout 1', 'renev'),
                    'layout-2' => esc_html__('Layout 2', 'renev'),
                ],
                'default' => 'layout-1',
            ]
        );
        $this->add_control(
            'number_of_items',
            [
                'label' => __( 'Number of Items to Show', 'renev' ),
                'type' => \Elementor\Controls_Manager::NUMBER,
                'min' => 1,
                'max' => 50,
            ]
        );
        
        $repeater = new \Elementor\Repeater();

        $repeater->add_control(
			'slider_text',
			[
				'label'   => esc_html__( 'Text', 'renev' ),
				'type'    => Controls_Manager::TEXT,
				'default' => esc_html__( 'SEO marketing', 'renev' ),
                'label_block' => true,
			]
		);
        $repeater->add_control(
            'slider_icon',
            [
                'label' => __('Icon', 'renev'),
                'type'  => Controls_Manager::MEDIA,
            ]
        );
        $repeater->add_control(
            'slider_link',
            [
                'label' => esc_html__('Slider Url', 'renev'),
                'type' => Controls_Manager::URL,
                'default' => [
                    'url' => '#',
                ],
                'label_block' => true,
                'description' => 'Layout 2',
            ]
        );
        $this->add_control(
            'slider_lists',
            [
                'label' => __('Slider Lists', 'renev'),
                'type' => \Elementor\Controls_Manager::REPEATER,
                'fields' => $repeater->get_controls(),
            ]
            
        );
        $this->end_controls_section();

        // Text Slider Style Controls
        $this->start_controls_section(
            'text_slider_style',
            [
                'label' => __( 'Text Slider', 'renev' ),
                'tab'   => Controls_Manager::TAB_STYLE,
            ]
        );
        $this->add_group_control(
            Group_Control_Background::get_type(),
            [
                'name' => 'text_slider_background',
                'label' => __( 'Slider Background', 'renev' ),
                'types' => [ 'classic', 'gradient', 'video' ],
                'selector' => '{{WRAPPER}} .slider1-section-area .marquee-wrap, {{WRAPPER}} .slider2-section-area .marquee-wrap .marquee-text .brand-single-box h3 a',
            ]
        );
        $this->add_control(
            'text_slider_hover_background',
            [
                'label' => __( 'Slider Hover Background', 'renev' ),
                'type' => Controls_Manager::COLOR,
                'selectors' => [
                    '{{WRAPPER}} .slider2-section-area .marquee-wrap .marquee-text .brand-single-box h3 a:hover' => 'background: {{VALUE}}',
                    
                ],
                'condition' => [
                    'textslider_layout' => 'layout-2',
                ] 
            ]
        );
        $this->add_responsive_control(
            'text_slider_padding',
            [
                'label' => __( 'Slider Section Padding', 'renev' ),
                'type' => Controls_Manager::DIMENSIONS,
                'size_units' => [ 'px', 'em', '%' ],
                'selectors' => [
                    '{{WRAPPER}} .slider1-section-area .marquee-wrap .marquee-text' => 'padding: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
                    '{{WRAPPER}} .slider2-section-area .marquee-wrap .marquee-text .brand-single-box h3 a' => 'padding: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
                ],
            ]
        );
        $this->add_control(
            'text_slider_color',
            [
                'label' => __( 'Text Color', 'renev' ),
                'type' => Controls_Manager::COLOR,
                'selectors' => [
                    '{{WRAPPER}} .slider1-section-area .marquee-wrap .marquee-text .brand-single-box h3' => 'color: {{VALUE}} !important',
                    '{{WRAPPER}} .slider2-section-area .marquee-wrap .marquee-text .brand-single-box h3 a' => 'color: {{VALUE}} !important',
                ],
            ]
        );
        $this->add_control(
            'text_slider_hover_color',
            [
                'label' => __( 'Text Hover Color', 'renev' ),
                'type' => Controls_Manager::COLOR,
                'selectors' => [
                    '{{WRAPPER}}  .slider2-section-area .marquee-wrap .marquee-text .brand-single-box h3 a:hover' => 'color: {{VALUE}} !important',
                ],
                'condition' => [
                    'textslider_layout' => 'layout-2',
                ] 
            ]
        );
        $this->add_group_control(
            Group_Control_Typography::get_type(),
            [
                'name' => 'text_slider_typography',
                'label' => __( 'Typography', 'renev' ),
                'selector' => '{{WRAPPER}} .slider1-section-area .marquee-wrap .marquee-text .brand-single-box h3, {{WRAPPER}} .slider2-section-area .marquee-wrap .marquee-text .brand-single-box h3 a',
            ]
        );
        $this->add_responsive_control(
            'slider_icon_margin',
            [
                'label' => __( 'Slider Icon Margin', 'renev' ),
                'type' => Controls_Manager::DIMENSIONS,
                'size_units' => [ 'px', 'em', '%' ],
                'selectors' => [
                    '{{WRAPPER}} .slider1-section-area .marquee-wrap .marquee-text .brand-single-box h3 img' => 'margin: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
                    '{{WRAPPER}} .slider2-section-area .marquee-wrap .marquee-text .brand-single-box h3 a img' => 'margin: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
                ],
            ]
        );
		$this->end_controls_section();

        //Arrow slider style 
        $this->start_controls_section(
            'arrow_slider_style',
            [
                'label' => __( 'Arrow Box', 'renev' ),
                'tab'   => Controls_Manager::TAB_STYLE,
                'condition' => [
                    'textslider_layout' => 'layout-2',
                ] 
            ]
        );
        $this->add_control(
            'arrow_slider_background',
            [
                'label' => __( 'Arrow Background', 'renev' ),
                'type' => Controls_Manager::COLOR,
                'selectors' => [
                    '{{WRAPPER}} .slider2-section-area .marquee-wrap .marquee-text .brand-single-box h3 a span' => 'background: {{VALUE}}',
                ],
                
            ]
        );
        $this->add_control(
            'arrow_slider_color',
            [
                'label' => __( 'Arrow Color', 'renev' ),
                'type' => Controls_Manager::COLOR,
                'selectors' => [
                    '{{WRAPPER}} .slider2-section-area .marquee-wrap .marquee-text .brand-single-box h3 a span' => 'color: {{VALUE}};',
                ],
            ]
        );
        $this->add_responsive_control(
			'arrow_slider_width',
			[
				'label' => esc_html__( 'Icon Width', 'renev' ),
				'type' => Controls_Manager::SLIDER,
				'size_units' => [ 'px', '%', 'em', 'rem', 'custom' ],
				'range' => [
					'px' => [
						'min' => 0,
						'max' => 1000,
						'step' => 1,
					],
					'%' => [
						'min' => 0,
						'max' => 100,
					],
				],
				'selectors' => [
					'{{WRAPPER}} .slider2-section-area .marquee-wrap .marquee-text .brand-single-box h3 a span' => 'width: {{SIZE}}{{UNIT}};',
				],
			]
		);
        $this->add_responsive_control(
			'arrow_slider_height',
			[
				'label' => esc_html__( 'Icon Height', 'renev' ),
				'type' => Controls_Manager::SLIDER,
				'size_units' => [ 'px', '%', 'em', 'rem', 'custom' ],
				'range' => [
					'px' => [
						'min' => 0,
						'max' => 1000,
						'step' => 1,
					],
					'%' => [
						'min' => 0,
						'max' => 100,
					],
				],
				'selectors' => [
					'{{WRAPPER}} .slider2-section-area .marquee-wrap .marquee-text .brand-single-box h3 a span' => 'height: {{SIZE}}{{UNIT}};',
				],
			]
		);
        $this->add_responsive_control(
            'arrow_slider_radius',
            [
                'label'         => __( 'arrow Border Radius', 'renev' ),
                'type'          => Controls_Manager::DIMENSIONS,
                'size_units'    => [ 'px', '%', 'em' ],
                'selectors'     => [
                    '{{WRAPPER}} .slider2-section-area .marquee-wrap .marquee-text .brand-single-box h3 a span' => 'border-radius: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
                ],
            ]
        );
        $this->end_controls_section();
    }

    // Render
	protected function render() {
        $settings = $this->get_settings_for_display(); 
        $layout = $settings['textslider_layout'];
        $slider_lists = $settings['slider_lists'];
        $max_items = !empty($settings['number_of_items']) ? intval($settings['number_of_items']) : count($slider_lists);
        $counter = 0;
    
        if ( $layout ) {
            include('textslider/' . $layout . '.php');
        }
    }
}
$widgets_manager->register( new \Renev_Text_Slider() );