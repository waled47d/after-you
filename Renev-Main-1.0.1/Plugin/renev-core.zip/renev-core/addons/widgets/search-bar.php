<?php
use \Elementor\Widget_Base;
use \Elementor\Controls_Manager;
use \Elementor\Group_Control_Typography;
use \Elementor\Group_Control_Text_Shadow;
use \Elementor\Group_Control_Border;
use \Elementor\Group_Control_Box_Shadow;
use \Elementor\Repeater;
use \Elementor\Utils;
/**
 *
 * Renev Search Widget .
 *
 */
class Renev_Search_Bar extends Widget_Base {

	public function get_name() {
		return 'renev_search_bar';
	}

	public function get_title() {
		return __( 'Renev Search Bar', 'renev' );
	}

	public function get_icon() {
		return 'eicon-code';
    }

	public function get_categories() {
		return [ 'renev' ];
	}

	protected function register_controls() {

        $this->start_controls_section(
            'content_section',
            [
                'label' => __('Content', 'renev'),
                'tab'   => Controls_Manager::TAB_CONTENT,
            ]
        );
        $this->add_control(
            'search_name',
            [
                'label'       => __( 'Search Name', 'renev' ),
                'type'        => Controls_Manager::TEXT,
                'default'     => __( 'Search', 'renev' ),
                'label_block' => true,
            ]
        );
       
        $this->end_controls_section();

        //Search Box Style
        $this->start_controls_section(
            'search_box_section',
            [
                'label' => __( 'Search Box', 'renev' ),
                'tab' => Controls_Manager::TAB_STYLE,
            ]
        );
        $this->add_control(
            'search_box_padding',
            [
                'label'      => __( 'Padding', 'renev' ),
                'type'       => Controls_Manager::DIMENSIONS,
                'size_units' => [ 'px', '%', 'em' ],
                'selectors'  => [
                    '{{WRAPPER}} .service-details-section .service-details-side .search-area' => 'padding: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
                ],
            ]
        );
        $this->add_responsive_control(
            'search_box_radius',
            [
                'label'         => __( 'Border Radius', 'renev' ),
                'type'          => Controls_Manager::DIMENSIONS,
                'size_units'    => [ 'px', '%', 'em' ],
                'selectors'     => [
                    '{{WRAPPER}} .service-details-section .service-details-side .search-area' => 'border-radius: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
                ],
            ]
        );
        $this->add_control(
            'search_box_background',
            [
                'label' => __( 'Background', 'renev' ),
                'type' => Controls_Manager::COLOR,
                'selectors' => [
                    '{{WRAPPER}} .service-details-section .service-details-side .search-area' => 'background: {{VALUE}}',
                ],
            ]
        );
        $this->end_controls_section();

        //Search Style
        $this->start_controls_section(
            'search_name_section',
            [
                'label' => __( 'Search Name', 'renev' ),
                'tab' => Controls_Manager::TAB_STYLE,
            ]
        );
       $this->add_control(
            'search_name_color',
            [
                'label' => __( 'Search Color', 'renev' ),
                'type' => Controls_Manager::COLOR,
                'selectors' => [
                    '{{WRAPPER}} .service-details-section .service-details-side h3' => 'color: {{VALUE}} !important',
                ],
            ]
        );
        $this->add_group_control(
            Group_Control_Typography::get_type(),
            [
                'name' => 'search_name_typography',
                'label' => __( 'Typography', 'renev' ),
                'selector' => '{{WRAPPER}} .service-details-section .service-details-side h3',
            ]
        );
        $this->add_control(
            'search_name_margin',
            [
                'label'      => __( 'Search Margin', 'renev' ),
                'type'       => Controls_Manager::DIMENSIONS,
                'size_units' => [ 'px', '%', 'em' ],
                'selectors'  => [
                    '{{WRAPPER}} .service-details-section .service-details-side h3' => 'margin: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
                ],
            ]
        );    
        $this->end_controls_section();

        //Search placeholder Style
        $this->start_controls_section(
            'search_placeholder_section',
            [
                'label' => __( 'Search Placeholder', 'renev' ),
                'tab' => Controls_Manager::TAB_STYLE,
            ]
        );
        $this->add_control(
            'search_placeholder_padding',
            [
                'label'      => __( 'Padding', 'renev' ),
                'type'       => Controls_Manager::DIMENSIONS,
                'size_units' => [ 'px', '%', 'em' ],
                'selectors'  => [
                    '{{WRAPPER}} .service-details-section .service-details-side .search-area form input' => 'padding: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
                ],
            ]
        );
        $this->add_responsive_control(
            'search_placeholder_radius',
            [
                'label'         => __( 'Border Radius', 'renev' ),
                'type'          => Controls_Manager::DIMENSIONS,
                'size_units'    => [ 'px', '%', 'em' ],
                'selectors'     => [
                    '{{WRAPPER}} .service-details-section .service-details-side .search-area form input' => 'border-radius: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
                ],
            ]
        );
        $this->add_control(
            'search_placeholder_background',
            [
                'label' => __( 'Background', 'renev' ),
                'type' => Controls_Manager::COLOR,
                'selectors' => [
                    '{{WRAPPER}} .service-details-section .service-details-side .search-area form input' => 'background: {{VALUE}}',
                ],
            ]
        );
        $this->add_control(
            'search_placeholder_color',
            [
                'label' => __( 'placeholder Color', 'renev' ),
                'type' => Controls_Manager::COLOR,
                'selectors' => [
                    '{{WRAPPER}} .service-details-section .service-details-side .search-area form input' => 'color: {{VALUE}} !important',
                ],
            ]
        );
        $this->add_group_control(
            Group_Control_Typography::get_type(),
            [
                'name' => 'search_placeholder_typography',
                'label' => __( 'Typography', 'renev' ),
                'selector' => '{{WRAPPER}} .service-details-section .service-details-side .search-area form input',
            ]
        );
        $this->add_responsive_control(
            'search_placeholder_width',
            [
                'label'          => __('Placeholder Width', 'renev'),
                'type'           => Controls_Manager::SLIDER,
                'size_units'     => ['%', 'px','vw'],
                'range'          => [
                    '%'  => [
                        'min' => 1,
                        'max' => 100,
                    ],
                    'px' => [
                        'min' => 1,
                        'max' => 1000,
                    ],
                    'vw' => [
                        'min' => 1,
                        'max' => 100,
                    ],
                ],
                'selectors'      => [
                    '{{WRAPPER}} .service-details-section .service-details-side .search-area form input' => 'width: {{SIZE}}{{UNIT}};',
                ],
            ]
        );
        $this->add_control(
            'search_placeholder_icon_color',
            [
                'label' => __( 'Icon Color', 'renev' ),
                'type' => Controls_Manager::COLOR,
                'selectors' => [
                    '{{WRAPPER}} .service-details-section .service-details-side .search-area form button' => 'color: {{VALUE}} !important',
                ],
            ]
        );
        $this->end_controls_section();


        }

    // Render
	protected function render() {
        $settings = $this->get_settings_for_display();
        
        ?>
            <div class="service-details-section">
                <div class="service-details-side">
                    <div class="search-area">
                        <h3><?php echo esc_html( $settings[ 'search_name' ]  ); ?></h3>
                        <form>
                            <input type="text" placeholder="Search...">
                            <button type="submit"><i class="fa-solid fa-magnifying-glass"></i></button>
                        </form>
                    </div>
                </div>
            </div>
        <?php
    }

}
$widgets_manager->register( new \Renev_Search_Bar() );