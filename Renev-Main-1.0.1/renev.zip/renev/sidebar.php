<?php

/**
 * @Packge     : Renev
 * @Version    : 1.0
 * @Author     : Mthemeus
 * @Author URI : https://www.mthemeus.com/
 *
 */


// Block direct access
if( !defined( 'ABSPATH' ) ){
    exit;
}

if ( ! is_active_sidebar( 'renev-blog-sidebar' ) ) {
    return;
}
?>

<div class="col-lg-4">
    <div class="blog-details-side">
        <?php dynamic_sidebar( 'renev-blog-sidebar' ); ?>
</div>
</div>