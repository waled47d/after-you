<div class="portfolio1-section-area sp6">
    <div class="container">
        <div class="row">
            <div class="col-lg-7">
                <div class="portfolio-header heading1">
                    <?php if (!empty($settings['sub_title'])): ?>
                        <h5>
                            <img src="<?php echo esc_url( $settings['heading_image']['url'] ); ?>" alt="">
                            <?php echo esc_html( $settings[ 'sub_title' ]  ); ?>
                        </h5>
                    <?php endif; ?>
                    <?php if (!empty($settings['title_content'])): ?>
                        <h2 class="text-anime-style-3">
                            <?php echo esc_html( $settings[ 'title_content' ]  ); ?>
                        </h2>
                    <?php endif; ?>
                </div>
            </div>
        </div>
        <div class="row">
            <div class="col-lg-12">
                <div class="portfolio-slider-area owl-carousel">
                    <?php 
                        // Set up the query to fetch posts
                        $number_of_post = !empty($settings['post_per_page']) ? $settings['post_per_page'] : -1;

                        $query_args = [
                            'post_type'      => 'renev_project',
                            'order'          => $settings['order'],
                            'posts_per_page' => $number_of_post,
                            'post_status'    => 'publish',
                        ];
        
                        if (!empty($settings['project_category'])) {
                            $query_args['tax_query'] = [
                                [
                                    'taxonomy' => 'project_category',
                                    'field'    => 'slug',
                                    'terms'    => $settings['project_category'],
                                ],
                            ];
                        }
        
                        if ('selected' === $settings['post_by'] && !empty($settings['post__in'])) {
                            $query_args['post__in'] = (array) $settings['post__in'];
                        }
                        

                        // Create a new WP_Query
                        $args = new \WP_Query($query_args);

                        if ($args->have_posts()):
                            while ($args->have_posts()): $args->the_post(); 
                            $categories = get_the_terms(get_the_ID(), 'project_category');
                        ?>
                        <div class="portfolio-boxarea border-nane">
                            <?php if( has_post_thumbnail() ): ?>
                                <div class="img1">
                                    <?php the_post_thumbnail('full');?>
                                </div>
                            <?php endif; ?>
                            <div class="arrow-content">
                                <div class="arrow">
                                    <a href="<?php the_permalink(); ?>">
                                        <span>
                                            <i class="fa-solid fa-arrow-right"></i>
                                        </span>
                                    </a>
                                </div>
                                <div class="content-area">
                                    <?php the_excerpt(); ?>
                                    <a href="<?php the_permalink(); ?>">
                                        <?php the_title(); ?>
                                    </a>
                                </div>
                            </div>
                        </div>
                        <?php 
                            endwhile; 
                            wp_reset_postdata();
                            endif; 
                        ?>
                </div>
            </div>
        </div>
    </div>
</div>