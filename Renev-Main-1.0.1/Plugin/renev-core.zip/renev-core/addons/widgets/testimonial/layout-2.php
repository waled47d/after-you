<div class="testimonial-review-area owl-carousel">
    <?php foreach ( $testimonial_items as $item ): ?>
        <div class="testimonial-boxarea">
         <?php \Elementor\Icons_Manager::render_icon( $item['quote_icon'], [ 'aria-hidden' => 'true' ] ); ?>
            <ul>
                <li><i class="fa-solid fa-star"></i></li>
                <li><i class="fa-solid fa-star"></i></li>
                <li><i class="fa-solid fa-star"></i></li>
                <li><i class="fa-solid fa-star"></i></li>
                <li><i class="fa-solid fa-star"></i></li>
            </ul>
            <p>
                <?php echo esc_html( $item['testimonial_description'] ); ?>
            </p>
            <div class="man-img-area">
                <div class="img1">
                    <img src="<?php echo esc_url( $item['testimonial_author_img']['url'] ); ?>" alt="">
                </div>
                <div class="content-area">
                    <a>
                        <?php echo esc_html( $item['testimonial_author_name'] ); ?>
                    </a>
                    <p><?php echo esc_html( $item['testimonial_card_desig'] ); ?></p>
                </div>
            </div>
        </div>
    <?php endforeach; ?>
</div>