<div class="service-images">
    <div class="img1">
        <img src="<?php echo esc_url( $settings['image_one']['url'] ); ?>" alt="">
    </div>
    <img src="<?php echo esc_url( $settings['shape-img']['url'] ); ?>" alt="" class="elements33 aniamtion-key-1">
    <img src="<?php echo esc_url( $settings['image_two']['url'] ); ?>" alt="" class="elements34 aniamtion-key-2">
    <img src="<?php echo esc_url( $settings['image_three']['url'] ); ?>" alt="" class="elements35">
    <img src="<?php echo esc_url( $settings['circle-img']['url'] ); ?>" alt="" class="elements36">
</div>