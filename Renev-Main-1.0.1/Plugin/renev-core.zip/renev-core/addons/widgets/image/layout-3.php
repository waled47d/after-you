
    <div class="about-images-area">
        <img src="<?php echo esc_url( $settings['shape-img']['url'] ); ?>" alt="" class="elements12">
        <img src="<?php echo esc_url( $settings['circle-img']['url'] ); ?>" alt="" class="elements13 keyframe5">
        <div class="row">
            <div class="col-lg-6 col-md-6">
                <?php if ( !empty( $settings['image_one']['url']) ) : ?>
                    <div class="img1 reveal">
                        <img src="<?php echo esc_url( $settings['image_one']['url'] ); ?>" alt="">
                    </div>
                <?php endif; ?>
            </div>
            <div class="col-lg-6 col-md-6">
                <?php if ( !empty( $settings['image_one']['url']) ) : ?>
                    <div class="img1 reveal margin">
                        <img src="<?php echo esc_url( $settings['image_two']['url'] ); ?>" alt="">
                    </div>
                <?php endif; ?>
            </div>
        </div>
    </div>