
<div class="row gap">
    <?php foreach ( $settings['skills'] as $skill ) : 
            $skill_name  = esc_html( $skill['skill_name'] );
            $skill_value = isset( $skill['skill_value']['size'] ) ? intval( $skill['skill_value']['size'] ) : 0;
        ?>
        <div class="col-lg-<?php echo esc_attr($settings['progress_column']); ?> col-md-6">
            <div class="progresbar">
                <div class="progressbar">
                    <div class="circle" data-percent="<?php echo $skill_value; ?>">
                        <canvas width="80" height="80"></canvas>
                        <div class="count td-work-progress-counter">
                            <span 
                                data-purecounter-duration="1" 
                                data-purecounter-end="<?php echo $skill_value; ?>" 
                                class="purecounter">
                                <?php echo $skill_value; ?>
                            </span>
                        </div>
                    </div>
                </div>
                <div class="content-area">
                    <h4><?php echo $skill_name; ?></h4>
                </div>
            </div>
        </div>
    <?php endforeach; ?>
</div>
