<?php
/**
 * @Packge     : Renev
 * @Version    : 1.0
 * @Author     : Mthemeus
 * @Author URI : https://www.mthemeus.com/
 */

// Block direct access
if( !defined( 'ABSPATH' ) ){
    exit();
}

// Check if pagination is available
if( !empty( renev_pagination() ) ) :
?>
<!-- Post Pagination -->
<div class="col-lg-12">
    <div class="space20"></div>
    <div class="pagination-area">
        <nav aria-label="Page navigation example">
            <ul class="pagination">
                <?php 
                // Add classes to pagination links
                add_filter('next_posts_link_attributes', function() {
                    return 'class="next page-link"';
                });
                add_filter('previous_posts_link_attributes', function() {
                    return 'class="prev page-link"';
                });

                // Previous Link
                $prev = wp_kses(
                    __( '<i class="fa-solid fa-angle-left"></i>', 'renev' ),
                    array( 'i' => array( 'class' => array() ) )
                );
                if( get_previous_posts_link() ) {
                    echo '<li class="page-item">';
                    previous_posts_link( $prev );
                    echo '</li>';
                }

                // Display pagination
                echo renev_pagination();

                // Next Link
                $next = wp_kses(
                    __( '<i class="fa-solid fa-angle-right"></i>', 'renev' ),
                    array( 'i' => array( 'class' => array() ) )
                );
                if( get_next_posts_link() ) {
                    echo '<li class="page-item">';
                    next_posts_link( $next );
                    echo '</li>';
                }
                ?>
            </ul>
        </nav>
    </div>
</div>
<!-- End of Post Pagination -->
<?php 
endif;
?>
