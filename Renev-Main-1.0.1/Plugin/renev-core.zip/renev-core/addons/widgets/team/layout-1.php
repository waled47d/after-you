<div class="row">
    <?php foreach ( $team_lists as $item ): ?>
        <div class="col-lg-4 col-md-6">
            <div class="team-author-boxarea">
                <img src="<?php echo esc_url( $item['team-author_box']['url'] ); ?>" alt="" class="elements7 keyframe5">
                <div class="img1">
                    <img src="<?php echo esc_url( $item['team-main_image']['url'] ); ?>" alt="">
                </div>
                <div class="content-area">
                    <div class="content">
                       <h4>
                           <?php echo esc_html($item['author_name']); ?>
                       </h4>
                        <p>
                            <?php echo esc_html($item['author_Profession']); ?>
                        </p>
                    </div>
                    <div class="share">
                        <a href="<?php echo esc_url( $item['share_icon_link']['url'] ); ?>">
                            <img src="<?php echo esc_url( $item['share_icon']['url'] ); ?>" alt="">
                        </a>
                    </div>
                </div>
                <div class="list">
                    <ul>
                        <?php if ( ! empty( $item['social_icon_one']['value'] ) && ! empty( $item['icon_url_one']['url'] ) ) : ?>
                            <li>
                                <a href="<?php echo esc_url( $item['icon_url_one']['url'] ); ?>">
                                    <?php \Elementor\Icons_Manager::render_icon( $item['social_icon_one'], [ 'aria-hidden' => 'true' ] ); ?>
                                </a>
                           </li>
                        <?php endif; ?>
                        <?php if ( ! empty( $item['social_icon_two']['value'] ) && ! empty( $item['icon_url_one']['url'] ) ) : ?>
                            <li>
                                <a href="<?php echo esc_url( $item['icon_url_two']['url'] ); ?>">
                                    <?php \Elementor\Icons_Manager::render_icon( $item['social_icon_two'], [ 'aria-hidden' => 'true' ] ); ?>
                                </a>
                            </li>
                        <?php endif; ?>
                        <?php if ( ! empty( $item['social_icon_three']['value'] ) && ! empty( $item['icon_url_one']['url'] ) ) : ?>
                            <li>
                                <a href="<?php echo esc_url( $item['icon_url_three']['url'] ); ?>" class="m-0">
                                    <?php \Elementor\Icons_Manager::render_icon( $item['social_icon_three'], [ 'aria-hidden' => 'true' ] ); ?>
                                </a>
                            </li>
                        <?php endif; ?>
                    </ul>
                </div>
            </div>
        </div>
    <?php endforeach; ?>
</div>