<?php
use \Elementor\Widget_Base;
use \Elementor\Controls_Manager;
use \Elementor\Icons_Manager;
use \Elementor\Group_Control_Typography;
use \Elementor\Group_Control_Border;
use \Elementor\Group_Control_Box_Shadow;
use \Elementor\Repeater;
use \Elementor\Utils;
use \Elementor\Group_Control_Background;

/**
 *
 * About Area Widget .
 *
 */
class Renev_Hero_Section extends Widget_Base {

	public function get_name() {
		return 'renev_hero_section';
	}

	public function get_title() {
		return __( 'Renev Hero Section', 'renev' );
	}

	public function get_icon() {
		return 'eicon-code';
    }

	public function get_categories() {
		return [ 'renev' ];
	}

	protected function register_controls() {

       // Content Section
       $this->start_controls_section(
            'content_section',
            [
                'label' => __( 'Content', 'renev' ),
                'tab'   => Controls_Manager::TAB_CONTENT,
            ]
         );
         $this->add_control(
            'hero_layout',
            [
                'label' => esc_html__('Select Layout', 'renev'),
                'type' => Controls_Manager::SELECT,
                'options' => [
                    'layout-1' => esc_html__('Layout 1', 'renev'),
                    'layout-2' => esc_html__('Layout 2', 'renev'),
                    'layout-3' => esc_html__('Layout 3', 'renev'),
                ],
                'default' => 'layout-1',
            ]
        );
        //hero Two 
        $repeater = new \Elementor\Repeater();

        $repeater->add_control(
			'slider_text',
			[
				'label'   => esc_html__( 'Text', 'renev' ),
				'type'    => Controls_Manager::TEXT,
				'default' => esc_html__( 'SEO marketing', 'renev' ),
                'label_block' => true,
			]
		);
        $this->add_control(
            'slider_lists',
            [
                'label' => __('Slider Lists', 'renev'),
                'type' => \Elementor\Controls_Manager::REPEATER,
                'fields' => $repeater->get_controls(),
                'condition' => [
                    'hero_layout' => 'layout-2',
                ]
            ]
            
        );
         $this->add_control(
            'hero_bg_img',
            [
                'label' => __( 'Hero Background Img', 'renev' ),
                'type' => Controls_Manager::MEDIA,
                'default' => [
                    'url' => Utils::get_placeholder_image_src(),
                ],
                'condition' => [
                    'hero_layout!' => 'layout-1',
                ]
            ]
        );
         $this->add_control(
            'heading_image',
            [
                'label' => __( 'heading icon', 'renev' ),
                'type' => Controls_Manager::MEDIA,
                'default' => [
                    'url' => Utils::get_placeholder_image_src(),
                ],
                'condition' => [
                    'hero_layout!' => 'layout-2',
                ]
            ]
        );
        $this->add_control(
            'section_heading',
            [
                'label' => __( 'Heading', 'renev' ),
                'type' => Controls_Manager::TEXT,
                'default' => __( ' Designing the Future of Your Brand', 'renev' ),
                'label_block' => true,
            ]
        );
        $this->add_control(
            'section_subtitle',
            [
                'label'       => __( 'Section Subtitle', 'renev' ),
                'type'        => Controls_Manager::TEXT,
                'default'     => __( 'Digital Designs', 'renev' ),
                'label_block' => true,
            ]
        );
        $this->add_control(
            'section_subtitle2',
            [
                'label'       => __( 'Section Subtitle', 'renev' ),
                'type'        => Controls_Manager::TEXT,
                'default'     => __( 'That Deliver', 'renev' ),
                'label_block' => true,
                'condition' => [
                    'hero_layout!' => 'layout-2',
                ]
            ]
        );
        $this->add_control(
            'subtitle_shape1',
            [
                'label'   => __( 'Sub Title Shape1', 'renev' ),
                'type'    => Controls_Manager::MEDIA,
                'default' => [ 
                ],
                'condition' => [
                    'hero_layout!' => 'layout-2',
                ]
            ]
        );
        $this->add_control(
            'subtitle_shape2',
            [
                'label'   => __( 'Sub Title Shape2', 'renev' ),
                'type'    => Controls_Manager::MEDIA,
                'default' => [
                    
                ],
                'condition' => [
                    'hero_layout!' => 'layout-2',
                ]
            ]
        );
        $this->add_control(
			'circle_icon_img1',
			[
				'label'   => __( 'icon Img1', 'renev' ),
				'type'    => Controls_Manager::MEDIA,
				'default' => [
					'url' => Utils::get_placeholder_image_src(),
				],
                'condition' => [
                    'hero_layout!' => 'layout-3',
                ]
			]
		);
		$this->add_control(
			'circle_icon_img2',
			[
				'label'   => __( 'Icon Image2', 'renev' ),
				'type'    => Controls_Manager::MEDIA,
				'default' => [
					'url' => Utils::get_placeholder_image_src(),
				],
                'condition' => [
                    'hero_layout!' => 'layout-3',
                ]
			]
		);
        $this->add_control(
			'circle_icon_img3',
			[
				'label'   => __( 'Icon Image3', 'renev' ),
				'type'    => Controls_Manager::MEDIA,
				'default' => [
					'url' => Utils::get_placeholder_image_src(),
				],
                'condition' => [
                    'hero_layout!' => 'layout-3',
                ]
			]
		);
        //Hero Three
        $this->add_control(
			'hero_shape1',
			[
				'label'   => __( 'Hero Shape1', 'renev' ),
				'type'    => Controls_Manager::MEDIA,
				'default' => [
					'url' => Utils::get_placeholder_image_src(),
				],
                'condition' => [
                    'hero_layout' => 'layout-3',
                ]
			]
		);
        $this->add_control(
			'hero_shape2',
			[
				'label'   => __( 'Hero Shape2', 'renev' ),
				'type'    => Controls_Manager::MEDIA,
				'default' => [
					'url' => Utils::get_placeholder_image_src(),
				],
                'condition' => [
                    'hero_layout' => 'layout-3',
                ]
			]
		);
        $this->add_control(
			'hero_shape3',
			[
				'label'   => __( 'Hero Shape3', 'renev' ),
				'type'    => Controls_Manager::MEDIA,
				'default' => [
					'url' => Utils::get_placeholder_image_src(),
				],
                'condition' => [
                    'hero_layout' => 'layout-3',
                ]
			]
		);
        $this->add_control(
            'arrow_link',
            [
                'label' => esc_html__('Circle Button Url', 'renev'),
                'type' => Controls_Manager::URL,
                'default' => [
                    'url' => '#',
                ],
                'label_block' => true,
                'condition' => [
                    'hero_layout!' => 'layout-3',
                ]
            ]
        );
        $this->add_control(
            'hero_button_text',
            [
                'label'       => __( 'Hero Button Text', 'renev' ),
                'type'        => Controls_Manager::TEXT,
                'default'     => __( 'That Deliver', 'renev' ),
                'label_block' => true,
                'condition' => [
                    'hero_layout' => ['layout-2', 'layout-3'],
                ]
            ]
        );
        $this->add_control(
            'hero_btn_link',
            [
                'label' => esc_html__('Hero Button Url', 'renev'),
                'type' => Controls_Manager::URL,
                'default' => [
                    'url' => '#',
                ],
                'label_block' => true,
                'condition' => [
                    'hero_layout' => ['layout-2', 'layout-3'],
                ]
            ]
        );
        $this->end_controls_section();

        // hero Heading Section
        $this->start_controls_section(
            'heading_style_section',
            [
                'label' => __( 'Heading Section', 'renev' ),
                'tab' => Controls_Manager::TAB_STYLE,
            ]
        );
        $this->add_control(
            'heading_section_padding',
            [
                'label'      => __( 'Heading Section Padding', 'renev' ),
                'type'       => Controls_Manager::DIMENSIONS,
                'size_units' => [ 'px', '%', 'em' ],
                'selectors'  => [
                    '{{WRAPPER}} .hero1-section-area' => 'padding: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
                    '{{WRAPPER}} .hero2-section-area' => 'padding: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
                    '{{WRAPPER}} .hero4-section-area' => 'padding: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
                ],
            ]
        );
        $this->add_responsive_control(
			'heading_img_width',
			[
				'label' => esc_html__( 'Icon Width', 'renev' ),
				'type' => Controls_Manager::SLIDER,
				'size_units' => [ 'px', '%', 'em', 'rem', 'custom' ],
				'range' => [
					'px' => [
						'min' => 0,
						'max' => 1000,
						'step' => 1,
					],
					'%' => [
						'min' => 0,
						'max' => 100,
					],
				],
				'selectors' => [
					'{{WRAPPER}} .hero1-section-area .hero-header-area h5 img' => 'width: {{SIZE}}{{UNIT}};',
                    '{{WRAPPER}} .hero4-section-area .hero-header-area h5 img' => 'width: {{SIZE}}{{UNIT}};',
				],
                
                'condition' => [
                    'hero_layout!' => 'layout-2',
                ]
			]
		);
        $this->add_control(
            'heading_icon_margin',
            [
                'label'      => __( 'Heading icon Margin', 'renev' ),
                'type'       => Controls_Manager::DIMENSIONS,
                'size_units' => [ 'px', '%', 'em' ],
                'selectors'  => [
                    '{{WRAPPER}} .hero1-section-area .hero-header-area h5 img' => 'margin: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
                    '{{WRAPPER}} .hero4-section-area .hero-header-area h5 img' => 'margin: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
                ],
                'condition' => [
                    'hero_layout!' => 'layout-2',
                ]
            ]
        );
        $this->add_control(
            'heading_color',
            [
                'label' => __( 'Heading One Color', 'renev' ),
                'type' => Controls_Manager::COLOR,
                'selectors' => [
                    '{{WRAPPER}} .hero1-section-area .hero-header-area h5' => 'color: {{VALUE}};',
                    '{{WRAPPER}} .hero2-section-area .top-heading h3' => 'color: {{VALUE}};',
                    '{{WRAPPER}} .hero4-section-area .hero-header-area h5' => 'color: {{VALUE}};',
                ],
            ]
        );
        $this->add_group_control(
            Group_Control_Typography::get_type(),
            [
                'name' => 'heading_typography',
                'label' => __( 'Typography', 'renev' ),
                'selector' => '{{WRAPPER}} .hero1-section-area .hero-header-area h5, {{WRAPPER}} .top-heading h3, {{WRAPPER}} .hero4-section-area .hero-header-area h5',
            ]
        );
        $this->add_control(
            'heading_one_margin',
            [
                'label'      => __( 'Heading One Margin', 'renev' ),
                'type'       => Controls_Manager::DIMENSIONS,
                'size_units' => [ 'px', '%', 'em' ],
                'selectors'  => [
                    '{{WRAPPER}} .hero1-section-area .hero-header-area h5' => 'margin: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
                    '{{WRAPPER}} .hero4-section-area .hero-header-area h5' => 'margin: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
                ],
                'condition' => [
                    'hero_layout!' => 'layout-2',
                ]
            ]
        );   

        //Hero Subtitle
        $this->add_control(
            'heading_subtitle_color',
            [
                'label' => __( 'Heading SubTitle Color', 'renev' ),
                'type' => Controls_Manager::COLOR,
                'selectors' => [
                    '{{WRAPPER}} .hero1-section-area .hero-header-area h1' => 'color: {{VALUE}} !important',
                    '{{WRAPPER}} .hero4-section-area .hero-header-area h1' => 'color: {{VALUE}} !important',
                ],
                'condition' => [
                    'hero_layout!' => 'layout-2',
                ]
            ]
        );
        $this->add_group_control(
            Group_Control_Typography::get_type(),
            [
                'name' => 'heading_subtitle_typography',
                'label' => __( 'Typography', 'renev' ),
                'selector' => '{{WRAPPER}} .hero1-section-area .hero-header-area h1, {{WRAPPER}} .hero4-section-area .hero-header-area h1',
                'condition' => [
                    'hero_layout!' => 'layout-2',
                ]
            ]
        );
        $this->add_control(
            'heading_subtitle_margin',
            [
                'label'      => __( 'Heading Subtitle Margin', 'renev' ),
                'type'       => Controls_Manager::DIMENSIONS,
                'size_units' => [ 'px', '%', 'em' ],
                'selectors'  => [
                    '{{WRAPPER}} .hero1-section-area .hero-header-area h1' => 'margin: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
                    '{{WRAPPER}} .hero4-section-area .hero-header-area h1' => 'margin: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
                ],
                'condition' => [
                    'hero_layout!' => 'layout-2',
                ]
            ]
        );    
        $this->end_controls_section();

        //Subtitle Shape2 style
        $this->start_controls_section(
            'csubtitle_shape2_style',
            [
                'label' => __( 'Subtitle Shape2 Section', 'renev' ),
                'tab'   => Controls_Manager::TAB_STYLE,
                'condition' => [
                    'hero_layout!' => 'layout-2',
                ]
            ]
        );
        $this->add_responsive_control(
            'subtitle_shape2_width',
            [
                'label'          => __('Subtitle Shape2 Width', 'renev'),
                'type'           => Controls_Manager::SLIDER,
                'size_units'     => ['%', 'px','vw'],
                'range'          => [
                    '%'  => [
                        'min' => 1,
                        'max' => 100,
                    ],
                    'px' => [
                        'min' => 1,
                        'max' => 1000,
                    ],
                    'vw' => [
                        'min' => 1,
                        'max' => 100,
                    ],
                ],
                'selectors'      => [
                    '{{WRAPPER}} .hero1-section-area .hero-header-area h1 .others-img1' => 'width: {{SIZE}}{{UNIT}};',
                    '{{WRAPPER}} .hero4-section-area .hero-header-area h1 .others-img1' => 'width: {{SIZE}}{{UNIT}};',
                ],
                
            ]
        );
        $this->add_control(
            'subtitle_shape2_background',
            [
                'label' => __( 'Subtitle Shape2 Background', 'renev' ),
                'type' => Controls_Manager::COLOR,
                'selectors' => [
                    '{{WRAPPER}} .hero1-section-area .hero-header-area h1 .others-img1' => 'background: {{VALUE}}',
                    '{{WRAPPER}} .hero4-section-area .hero-header-area h1 .others-img1' => 'background: {{VALUE}}',
                ],
            ]
        );
        $this->add_responsive_control(
            'subtitle_shape2_padding',
            [
                'label' => __( 'Subtitle Shape2 Padding', 'renev' ),
                'type' => Controls_Manager::DIMENSIONS,
                'size_units' => [ 'px', 'em', '%' ],
                'selectors' => [
                    '{{WRAPPER}} .hero1-section-area .hero-header-area h1 .others-img1' => 'padding: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
                    '{{WRAPPER}} .hero4-section-area .hero-header-area h1 .others-img1' => 'padding: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
                ],
            ]
        );
        $this->add_responsive_control(
            'subtitle_shape2_margin',
            [
                'label' => __( 'Subtitle Shape2 Margin', 'renev' ),
                'type' => Controls_Manager::DIMENSIONS,
                'size_units' => [ 'px', 'em', '%' ],
                'selectors' => [
                    '{{WRAPPER}} .hero1-section-area .hero-header-area h1 .others-img1' => 'margin: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
                    '{{WRAPPER}} .hero4-section-area .hero-header-area h1 .others-img1' => 'margin: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
                ],
            ]
        );
        $this->add_group_control(
            Group_Control_Border::get_type(),
            [
                'name' => 'subtitle_shape2_border',
                'selector' => '{{WRAPPER}} .hero1-section-area .hero-header-area h1 .others-img1, {{WRAPPER}} .hero4-section-area .hero-header-area h1 .others-img1',
            ]
        );
        $this->add_responsive_control(
            'subtitle_shape2_radius',
            [
                'label'         => __( 'Subtitle Shape2 Border Radius', 'renev' ),
                'type'          => Controls_Manager::DIMENSIONS,
                'size_units'    => [ 'px', '%', 'em' ],
                'selectors'     => [
                    '{{WRAPPER}} .hero1-section-area .hero-header-area h1 .others-img1' => 'border-radius: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
                    '{{WRAPPER}} .hero4-section-area .hero-header-area h1 .others-img1' => 'border-radius: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
                ],
            ]
        );
        $this->end_controls_section();

         //circle style
         $this->start_controls_section(
            'circle_style',
            [
                'label' => __( 'Circle Section', 'renev' ),
                'tab'   => Controls_Manager::TAB_STYLE,
                'condition' => [
                    'hero_layout!' => 'layout-3',
                ]
            ]
        );
        $this->add_responsive_control(
            'circle_image_width',
            [
                'label'          => __('Circle Img Width', 'renev'),
                'type'           => Controls_Manager::SLIDER,
                'size_units'     => ['%', 'px','vw'],
                'range'          => [
                    '%'  => [
                        'min' => 1,
                        'max' => 100,
                    ],
                    'px' => [
                        'min' => 1,
                        'max' => 1000,
                    ],
                    'vw' => [
                        'min' => 1,
                        'max' => 100,
                    ],
                ],
                'selectors'      => [
                    '{{WRAPPER}} .hero1-section-area .imges-header .img1 img' => 'width: {{SIZE}}{{UNIT}};',
                    '{{WRAPPER}} .top-heading .arrow a' => 'width: {{SIZE}}{{UNIT}};',

                    
                ],
            ]
        );
        $this->add_responsive_control(
            'circle_width',
            [
                'label'          => __('Circle Width', 'renev'),
                'type'           => Controls_Manager::SLIDER,
                'size_units'     => ['%', 'px','vw'],
                'range'          => [
                    '%'  => [
                        'min' => 1,
                        'max' => 100,
                    ],
                    'px' => [
                        'min' => 1,
                        'max' => 1000,
                    ],
                    'vw' => [
                        'min' => 1,
                        'max' => 100,
                    ],
                ],
                'selectors'      => [
                    '{{WRAPPER}} .hero1-section-area .imges-header .arrow a' => 'width: {{SIZE}}{{UNIT}};',
                    '{{WRAPPER}} .top-heading .arrow a' => 'width: {{SIZE}}{{UNIT}};',
                ],
            ]
        );
        $this->add_control(
            'circle_background',
            [
                'label' => __( 'Circle Background', 'renev' ),
                'type' => Controls_Manager::COLOR,
                'selectors' => [
                    '{{WRAPPER}} .hero1-section-area .imges-header .arrow a' => 'background: {{VALUE}}',
                    '{{WRAPPER}} .top-heading .arrow a' => 'background: {{VALUE}}',
                ],
            ]
        );
        $this->add_responsive_control(
            'circle_padding',
            [
                'label' => __( 'Circle Padding', 'renev' ),
                'type' => Controls_Manager::DIMENSIONS,
                'size_units' => [ 'px', 'em', '%' ],
                'selectors' => [
                    '{{WRAPPER}} .hero1-section-area .imges-header .arrow a' => 'padding: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
                ],
                'condition' => [
                    'hero_layout!' => 'layout-2',
                ]
            ]
        );
        $this->add_group_control(
            Group_Control_Border::get_type(),
            [
                'name' => 'circle_border',
                'selector' => '{{WRAPPER}} .hero1-section-area .imges-header .arrow a, {{WRAPPER}} .top-heading .arrow a',
            ]
        );
        $this->add_responsive_control(
            'circle_border_radius',
            [
                'label'         => __( 'Circle Border Radius', 'renev' ),
                'type'          => Controls_Manager::DIMENSIONS,
                'size_units'    => [ 'px', '%', 'em' ],
                'selectors'     => [
                    '{{WRAPPER}} .hero1-section-area .imges-header .arrow a' => 'border-radius: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
                    '{{WRAPPER}} .top-heading .arrow a' => 'border-radius: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
                ],
            ]
        );
        $this->end_controls_section();

         // Hero Two Pragraph Title style
         $this->start_controls_section(
            'pragraph_subtitle_style',
            [
                'label' => __( 'Pragraph Title', 'renev' ),
                'tab'   => Controls_Manager::TAB_STYLE,
				'condition' => [
                    'hero_layout' => 'layout-2',
                ]
            ]
        );
        $this->add_control(
            'spragraph_subtitle_color',
            [
                'label' => __( 'Color', 'renev' ),
                'type' => Controls_Manager::COLOR,
                'selectors' => [
                    '{{WRAPPER}} .hero2-section-area .peragraph-area p' => 'color: {{VALUE}}',
                ],
            ]
        );
        $this->add_group_control(
			Group_Control_Typography::get_type(),
			[
				'name' => 'pragraph_subtitle_typography',
				'selector' => '{{WRAPPER}} .hero2-section-area .peragraph-area p',
			]
		);
		$this->add_responsive_control(
            'pragraph_subtitle_margin',
            [
                'label' => __( 'Margin', 'renev' ),
                'type' => Controls_Manager::DIMENSIONS,
                'size_units' => [ 'px', 'em', '%' ],
                'selectors' => [
                    '{{WRAPPER}} .hero2-section-area .peragraph-area p' => 'margin: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
                ],
            ]
        );
		$this->end_controls_section();

         //Hero Two/three Button style
         $this->start_controls_section(
            'hero_btn_style',
            [
                'label' => __( 'Hero Button', 'renev' ),
                'tab'   => Controls_Manager::TAB_STYLE,
                'condition' => [
                    'hero_layout!' => 'layout-1',
                ]
            ]
        );
        $this->add_control(
            'hero_btn_color',
            [
                'label' => __( 'Text Color', 'renev' ),
                'type' => Controls_Manager::COLOR,
                'selectors' => [
                    '{{WRAPPER}} .vl-btn2' => 'color: {{VALUE}}',
                    '{{WRAPPER}} .vl-btn3' => 'color: {{VALUE}}',
                ],
            ]
        );
        $this->add_control(
            'hero_btn_color_hover',
            [
                'label' => __( 'Text Hover Color', 'renev' ),
                'type' => Controls_Manager::COLOR,
                'selectors' => [
                    '{{WRAPPER}} .vl-btn2:hover' => 'color: {{VALUE}}',
                    '{{WRAPPER}} .vl-btn3:hover' => 'color: {{VALUE}}',
                ],
            ]
        );  
        $this->add_group_control(
            Group_Control_Background::get_type(),
            [
                'name' => 'hero_btn_bg_color',
                'label' => __( 'Background Color', 'renev' ),
                'types' => [ 'classic', 'gradient', 'video' ],
                'selector' => '{{WRAPPER}} .vl-btn2, {{WRAPPER}} .vl-btn3',
            ]
        );
        $this->add_control(
            'hero_btn_bg_hover_color',
            [
                'label' => __( 'Background Hover Color', 'renev' ),
                'type' => Controls_Manager::COLOR,
                'selectors' => [
                    '{{WRAPPER}} .vl-btn2::after' => 'background-color: {{VALUE}}',
                    '{{WRAPPER}} .vl-btn3::after' => 'background-color: {{VALUE}}',
                ],
            ]
        );
        $this->add_group_control(
			Group_Control_Typography::get_type(),
			[
				'name' => 'hero_btn_typography',
				'selector' => '{{WRAPPER}} .vl-btn2, {{WRAPPER}} .vl-btn3',
			]
		);
        $this->add_group_control(
			Group_Control_Border::get_type(),
			[
				'name' => 'hero_btn_border',
				'selector' => '{{WRAPPER}} .vl-btn2, {{WRAPPER}} .vl-btn3',
			]
		);
        $this->add_responsive_control(
			'hero_btn_radius',
			[
				'label'         => __( 'Border Radius', 'renev' ),
				'type'          => Controls_Manager::DIMENSIONS,
				'size_units'    => [ 'px', '%', 'em' ],
				'selectors'     => [
					'{{WRAPPER}} .vl-btn2' => 'border-radius: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
                    '{{WRAPPER}} .vl-btn3' => 'border-radius: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
                ],
			]
        );
        $this->add_responsive_control(
            'hero_btn_padding',
            [
                'label' => __( 'Padding', 'renev' ),
                'type' => Controls_Manager::DIMENSIONS,
                'size_units' => [ 'px', 'em', '%' ],
                'selectors' => [
                    '{{WRAPPER}} .vl-btn2' => 'padding: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
                    '{{WRAPPER}} .vl-btn3' => 'padding: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
                ],
            ]
        );
		$this->end_controls_section();

        // Hero Two Slider Title style
        $this->start_controls_section(
            'hero_slider_style',
            [
                'label' => __( 'Slider Title', 'renev' ),
                'tab'   => Controls_Manager::TAB_STYLE,
                'condition' => [
                    'hero_layout' => 'layout-2',
                ]
            ]
        );
        $this->add_group_control(
            Group_Control_Background::get_type(),
            [
                'name' => 'hero_slider_background',
                'types' => [ 'classic', 'gradient', 'video' ],
                'selector' => '{{WRAPPER}} .hero2-section-area .marquee-wrap .marquee-text .main-heading h1',
            ]
        );
        $this->add_control(
            'hero_slider_color',
            [
                'label' => __( 'Color', 'renev' ),
                'type' => \Elementor\Controls_Manager::COLOR,
                'selectors' => [
                    '{{WRAPPER}} .hero2-section-area .marquee-wrap .marquee-text .main-heading h1' => '-webkit-text-fill-color: {{VALUE}};',
                ],
            ]
        );        
        $this->add_group_control(
            Group_Control_Typography::get_type(),
            [
                'name' => 'hero_slider_typography',
                'selector' => '{{WRAPPER}} .hero2-section-area .marquee-wrap .marquee-text .main-heading h1',
            ]
        );
        $this->add_responsive_control(
            'hero_slider_margin',
            [
                'label' => __( 'Margin', 'renev' ),
                'type' => Controls_Manager::DIMENSIONS,
                'size_units' => [ 'px', 'em', '%' ],
                'selectors' => [
                    '{{WRAPPER}} .hero2-section-area .marquee-wrap .marquee-text .main-heading h1' => 'margin: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
                ],
            ]
        );
        $this->end_controls_section();


    }

    // Render
	protected function render() {
        $settings = $this->get_settings_for_display();
        $layout = $settings['hero_layout'];
        $slider_lists = $settings['slider_lists'];
        
        ?>
            <?php
                if ( $layout) {
                    include('hero/'.$layout.'.php');
                }
            ?> 
        <?php
    }
}
$widgets_manager->register( new \Renev_Hero_Section() );