<?php
// File Security Check
if (!defined('ABSPATH')) {
	exit;
}
class RenevCustomPosts{

    function __construct()
	{   
        /*----------  Service ----------*/
        add_action('init', array($this, 'renev_service'));


        /*----------  Team ----------*/
        add_action('init', array($this, 'renev_team'));

        /*----------  Project ----------*/
        add_action('init', array($this, 'renev_project'));
        add_action('init', array($this, 'renev_project_category'));
    }

    /*----------  Service ----------*/   
    public function renev_service() 
    {
        $labels = array(
            'name'               => esc_html__( 'Services', 'Service general name', 'renev' ),
            'singular_name'      => esc_html__( 'Service', 'Service singular name', 'renev' ),
            'menu_name'          => esc_html__( 'Services', 'admin menu', 'renev' ),
            'name_admin_bar'     => esc_html__( 'Service', 'add new on admin bar', 'renev' ),
            'add_new'            => esc_html__( 'Add New', 'Service', 'renev' ),
            'add_new_item'       => esc_html__( 'Add New Service', 'renev' ),
            'new_item'           => esc_html__( 'New Service', 'renev' ),
            'edit_item'          => esc_html__( 'Edit Service', 'renev' ),
            'view_item'          => esc_html__( 'View Service', 'renev' ),
            'all_items'          => esc_html__( 'All Service', 'renev' ),
            'search_items'       => esc_html__( 'Search Service', 'renev' ),
            'parent_item_colon'  => esc_html__( 'Parent Service:', 'renev' ),
            'not_found'          => esc_html__( 'No Service found.', 'renev' ),
            'not_found_in_trash' => esc_html__( 'No Service found in Trash.', 'renev' ),
        );
    
        $args = array(
            'labels'             => $labels,
            'description'        => esc_html__( 'Description.', 'renev' ),
            'public'             => true,
            'publicly_queryable' => true,
            'show_ui'            => true,
            'show_in_menu'       => true,
            'query_var'          => true,
            'has_archive'        => true,
            'hierarchical'       => false,
            'menu_position'      => null,
            'show_in_rest'       => true,
            'menu_icon'          => 'dashicons-edit-page',
            'supports'           => array( 'title','thumbnail','editor','excerpt','elementor' ),
            'rewrite'            => array( 'slug' => 'services' ),
        );
        register_post_type( 'renev_service', $args );
    }


    /*----------  Team ----------*/   
    public function renev_team() 
    {
        $labels = array(
            'name'               => esc_html__( 'Teams', 'Team general name', 'renev' ),
            'singular_name'      => esc_html__( 'Team', 'Team singular name', 'renev' ),
            'menu_name'          => esc_html__( 'Teams', 'admin menu', 'renev' ),
            'name_admin_bar'     => esc_html__( 'Team', 'add new on admin bar', 'renev' ),
            'add_new'            => esc_html__( 'Add New', 'Team', 'renev' ),
            'add_new_item'       => esc_html__( 'Add New Team', 'renev' ),
            'new_item'           => esc_html__( 'New Team', 'renev' ),
            'edit_item'          => esc_html__( 'Edit Team', 'renev' ),
            'view_item'          => esc_html__( 'View Team', 'renev' ),
            'all_items'          => esc_html__( 'All Team', 'renev' ),
            'search_items'       => esc_html__( 'Search Team', 'renev' ),
            'parent_item_colon'  => esc_html__( 'Parent Team:', 'renev' ),
            'not_found'          => esc_html__( 'No Team found.', 'renev' ),
            'not_found_in_trash' => esc_html__( 'No Team found in Trash.', 'renev' ),
        );
    
        $args = array(
            'labels'             => $labels,
            'description'        => esc_html__( 'Description.', 'renev' ),
            'public'             => true,
            'publicly_queryable' => true,
            'show_ui'            => true,
            'show_in_menu'       => true,
            'query_var'          => true,
            'has_archive'        => true,
            'hierarchical'       => false,
            'menu_position'      => null,
            'show_in_rest'       => true,
            'menu_icon'          => 'dashicons-id',
            'supports'           => array( 'title','thumbnail','editor','elementor' ),
            'rewrite'            => array( 'slug' => 'teams' ),
        );
        register_post_type( 'renev_team', $args );
    }


    /*----------  Project ----------*/   
    public function renev_project() 
    {
        $labels = array(
            'name'               => esc_html__( 'Projects', 'Project general name', 'renev' ),
            'singular_name'      => esc_html__( 'Project', 'Project singular name', 'renev' ),
            'menu_name'          => esc_html__( 'Projects', 'admin menu', 'renev' ),
            'name_admin_bar'     => esc_html__( 'Project', 'add new on admin bar', 'renev' ),
            'add_new'            => esc_html__( 'Add New', 'Project', 'renev' ),
            'add_new_item'       => esc_html__( 'Add New Project', 'renev' ),
            'new_item'           => esc_html__( 'New Project', 'renev' ),
            'edit_item'          => esc_html__( 'Edit Project', 'renev' ),
            'view_item'          => esc_html__( 'View Project', 'renev' ),
            'all_items'          => esc_html__( 'All Projects', 'renev' ),
            'search_items'       => esc_html__( 'Search Projects', 'renev' ),
            'parent_item_colon'  => esc_html__( 'Parent Projects:', 'renev' ),
            'not_found'          => esc_html__( 'No Projects found.', 'renev' ),
            'not_found_in_trash' => esc_html__( 'No Projects found in Trash.', 'renev' ),
        );
    
        $args = array(
            'labels'             => $labels,
            'description'        => esc_html__( 'Description.', 'renev' ),
            'public'             => true,
            'publicly_queryable' => true,
            'show_ui'            => true,
            'show_in_menu'       => true,
            'query_var'          => true,
            'has_archive'        => true,
            'hierarchical'       => false,
            'menu_position'      => null,
            'show_in_rest'       => true,
            'menu_icon'          => 'dashicons-portfolio',
            'supports'           => array( 'title','thumbnail','editor','excerpt','elementor' ),
            'rewrite'            => array( 'slug' => 'projects' ),
        );
        register_post_type( 'renev_project', $args );
    }

    // Project Category
    public function renev_project_category() {

        $labels = array(
            'name'                       => esc_html__( 'Categories', 'taxonomy general name', 'renev' ),
            'singular_name'              => esc_html__( 'Category', 'taxonomy singular name', 'renev' ),
            'search_items'               => esc_html__( 'Search Categorys', 'renev' ),
            'popular_items'              => esc_html__( 'Popular Categorys', 'renev' ),
            'all_items'                  => esc_html__( 'All Categorys', 'renev' ),
            'parent_item'                => null,
            'parent_item_colon'          => null,
            'edit_item'                  => esc_html__( 'Edit Category', 'renev' ),
            'update_item'                => esc_html__( 'Update Category', 'renev' ),
            'add_new_item'               => esc_html__( 'Add New Category', 'renev' ),
            'new_item_name'              => esc_html__( 'New Category Name', 'renev' ),
            'separate_items_with_commas' => esc_html__( 'Separate Categorys with commas', 'renev' ),
            'add_or_remove_items'        => esc_html__( 'Add or remove Categorys', 'renev' ),
            'choose_from_most_used'      => esc_html__( 'Choose from the most used Categorys', 'renev' ),
            'not_found'                  => esc_html__( 'No Categorys found.', 'renev' ),
            'menu_name'                  => esc_html__( 'Categories', 'renev' ),
        );
    
        $args = array(
            'hierarchical'          => true,
            'labels'                => $labels,
            'show_ui'               => true,
            'show_admin_column'     => true,
            'update_count_callback' => '_update_post_term_count',
            'query_var'             => true,
            'show_in_rest'          => true,
            'rewrite'               => array( 'slug' => 'project-cat' ),
        );
        register_taxonomy( 'project_category', 'renev_project', $args );
    }
    
}
$Renev_StydyInstance = new RenevCustomPosts;

