<div class="hero4-section-area" style="background-image: url(<?php echo esc_url( $settings['hero_bg_img']['url'] ); ?>) background-position: center top; background-repeat: no-repeat; background-size: cover;">
    <img src="<?php echo esc_url( $settings['hero_shape1']['url'] ); ?>" alt="" class="elements27 aniamtion-key-1">
    <img src="<?php echo esc_url( $settings['hero_shape2']['url'] ); ?>" alt="" class="elements28 aniamtion-key-3">
    <div class="container">
        <div class="row align-items-center">
            <div class="col-lg-8 m-auto">
                <div class="hero-header-area text-center">
                    <img src="<?php echo esc_url( $settings['hero_shape3']['url'] ); ?>" alt="" class="elements30 aniamtion-key-2">
                <h5>
                    <img src="<?php echo esc_url( $settings['heading_image']['url'] ); ?>" alt=""> 
                    <?php echo renev_kses( $settings['section_heading'] ); ?>
                </h5>
                <h1 class="text-anime-style-3">
                    <?php echo esc_html( $settings[ 'section_subtitle' ]  ); ?>
                    <img src="<?php echo esc_url( $settings['subtitle_shape1']['url'] ); ?>" alt="" class="elements1 keyframe5">
                </h1>
                <h1 class="text-anime-style-3">
                    <img src="<?php echo esc_url( $settings['subtitle_shape2']['url'] ); ?>" alt="" class="others-img1"> 
                    <?php echo esc_html( $settings[ 'section_subtitle2' ]  ); ?> 
                </h1>
                <div class="btn-area1">
                    <a href="<?php echo esc_url($settings['hero_btn_link']['url']); ?>"  class="vl-btn3"
                        <?php echo !empty($settings['btn_link']['is_external']) ? 'target="_blank"' : ''; ?>
                        <?php echo !empty($settings['btn_link']['nofollow']) ? 'rel="nofollow"' : ''; ?> style="overflow: hidden;">
                        <?php echo esc_html( $settings[ 'hero_button_text' ]  ); ?>
                    </a>
                </div>
                </div>
            </div>
        </div>
    </div>
</div>