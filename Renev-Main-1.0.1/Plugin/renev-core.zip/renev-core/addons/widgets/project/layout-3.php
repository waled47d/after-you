<?php 
$query_args = [
    'post_type'      => 'renev_project',
    'order'          => $settings['order'],
    'posts_per_page' => $number_of_post,
    'post_status'    => 'publish',
];

if (!empty($settings['project_category'])) {
    $query_args['tax_query'] = [[
        'taxonomy' => 'project_category',
        'field'    => 'slug',
        'terms'    => $settings['project_category'],
    ]];
}

if ('selected' === $settings['post_by'] && !empty($settings['post__in'])) {
    $query_args['post__in'] = (array) $settings['post__in'];
}

$args = new \WP_Query($query_args);

if ($args->have_posts()):
    $i = 0;
    while ($args->have_posts()): $args->the_post();
        $i++;

        // Determine which row and how many columns
        $col_class = '';
        if ($i <= $top_col_count) {
            // top row
            $col_class = 'col-lg-' . intval(12 / $top_col_count);
            if ($i === 1) echo '<div class="row top-row">';
        } else {
            // bottom row
            $bottom_index = $i - $top_col_count;
            $col_class = 'col-lg-' . intval(12 / $bottom_col_count);
            if ($bottom_index === 1) echo '<div class="row bottom-row">';
        }
        ?>

        <div class="<?php echo esc_attr($col_class); ?> col-md-6 mb-0">
            <div class="portfolio-boxarea">
                <?php if (has_post_thumbnail()): ?>
                    <div class="img1"><?php the_post_thumbnail('full'); ?></div>
                <?php endif; ?>
                <div class="btn-area">
                    <a href="<?php the_permalink(); ?>">
                        <?php echo renev_kses($settings['btn_area']); ?>
                    </a>
                </div>
            </div>
        </div>

        <?php 
        // Close top row
        if ($i === $top_col_count) echo '</div>';

        // Close bottom row
        if ($i === ($top_col_count + $bottom_col_count)) echo '</div>';

    endwhile;
    wp_reset_postdata();
endif;
?>
