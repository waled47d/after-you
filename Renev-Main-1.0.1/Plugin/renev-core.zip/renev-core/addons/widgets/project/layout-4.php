<div class="project-inner-section-area">
    <?php 
        $categories = get_terms([
            'taxonomy'   => 'project_category',
            'hide_empty' => true,
        ]); 
    ?>
    <?php if ('yes' === ($settings['show_category'] ?? '') ) : ?>
        <div class="tabs-area text-center space-margin60">
            <ul class="nav nav-pills" id="pills-tab" role="tablist">
                <?php

                if (empty($categories)) {
                    echo '<p>' . esc_html__('No categories found.', 'adina') . '</p>';
                    return;
                }

                $selected_categories = !empty($settings['project_category']) ? $settings['project_category'] : [];
                $active_tab_set = false;
                ?>
                
                <!-- Add All tab first -->
                <li class="nav-item" role="presentation">
                    <button class="nav-link <?php echo !$active_tab_set ? 'active' : ''; ?>" 
                            id="tab-all" 
                            data-bs-toggle="pill" 
                            data-bs-target="#pills-all" 
                            type="button" 
                            role="tab" 
                            aria-controls="pills-all" 
                            aria-selected="<?php echo !$active_tab_set ? 'true' : 'false'; ?>">
                        <?php echo esc_html__('All', 'adina'); ?>
                    </button>
                </li>
                <?php 
                $active_tab_set = true;

                foreach ($categories as $category) :
                    if (!empty($selected_categories) && !in_array($category->slug, $selected_categories)) {
                        continue;
                    }

                    // Check if category has posts before rendering tab
                    $test_query = new WP_Query([
                        'post_type'      => 'renev_project',
                        'posts_per_page' => 1,
                        'tax_query'      => [['taxonomy' => 'project_category', 'field' => 'term_id', 'terms' => $category->term_id]],
                    ]);

                    if (!$test_query->have_posts()) {
                        wp_reset_postdata();
                        continue;
                    }
                    wp_reset_postdata();
                ?>
                    <li class="nav-item" role="presentation">
                        <button class="nav-link" 
                                id="tab-<?php echo esc_attr($category->slug); ?>" 
                                data-bs-toggle="pill" 
                                data-bs-target="#pills-<?php echo esc_attr($category->slug); ?>" 
                                type="button" 
                                role="tab" 
                                aria-controls="pills-<?php echo esc_attr($category->slug); ?>" 
                                aria-selected="false">
                            <?php echo esc_html($category->name); ?>
                        </button>
                    </li>
                <?php endforeach; ?>
            </ul>
        </div>
    <?php endif; ?>


    <div class="tab-content" id="pills-tabContent">
        <?php
        $active_tab_set = false;

        // Calculate posts_per_page safely
        $posts_per_page = !empty($settings['post_per_page']) ? intval($settings['post_per_page']) : -1;

        // ALL tab content
        $all_args = [
            'post_type'      => 'renev_project',
            'posts_per_page' => $posts_per_page,
            'paged'          => max(1, get_query_var('paged')),
        ];

        if ('selected' === ($settings['post_by'] ?? '') && !empty($settings['post__in'])) {
            $all_args['post__in'] = (array) $settings['post__in'];
            $all_args['orderby'] = 'post__in';
        }

        $all_query = new WP_Query($all_args);
        if ($all_query->have_posts()) :
        ?>
            <div class="tab-pane fade <?php echo !$active_tab_set ? 'show active' : ''; ?>" 
                 id="pills-all" 
                 role="tabpanel" 
                 aria-labelledby="tab-all">
                <div class="all-project-area">
                    <div class="row">
                        <?php while ($all_query->have_posts()) : $all_query->the_post(); ?>
                            <div class="col-lg-6 col-md-6">
                                <div class="portfolio-boxarea">
                                    <?php if (has_post_thumbnail()) : ?>
                                        <div class="img1"><?php the_post_thumbnail('full'); ?></div>
                                    <?php endif; ?>
                                    <div class="arrow-content">
                                        <div class="arrow">
                                            <a href="<?php the_permalink(); ?>">
                                                <span><i class="fa-solid fa-arrow-right"></i></span>
                                            </a>
                                        </div>
                                        <div class="content-area">
                                        <?php 
                                            if (has_excerpt()) {
                                                the_excerpt();
                                            } 
                                        ?>
                                            <a href="<?php the_permalink(); ?>"><?php the_title(); ?></a>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        <?php endwhile; ?>
                    </div>
                    
                    <!-- Pagination Start -->
                    <?php if ('yes' === ($settings['show_pagination'] ?? '') && $all_query->max_num_pages > 1) : ?>
                        <div class="col-lg-12">
                            <div class="space50"></div>
                            <div class="pagination-area">
                                <nav aria-label="Page navigation example">
                                    <?php
                                    $big = 999999999;

                                    $pagination_links = paginate_links([
                                        'base'      => str_replace($big, '%#%', esc_url(get_pagenum_link($big))),
                                        'format'    => '?paged=%#%',
                                        'current'   => max(1, get_query_var('paged')),
                                        'total'     => $all_query->max_num_pages,
                                        'prev_text' => '<i class="fa-solid fa-angle-left"></i>',
                                        'next_text' => '<i class="fa-solid fa-angle-right"></i>',
                                        'type'      => 'array',
                                    ]);

                                    if (is_array($pagination_links)) {
                                        echo '<ul class="pagination justify-content-center">';
                                        foreach ($pagination_links as $link) {
                                            if (strpos($link, 'current') !== false) {
                                                echo '<li class="page-item"><a class="page-link active">' . strip_tags($link) . '</a></li>';
                                            } else {
                                                echo '<li class="page-item">' . str_replace('page-numbers', 'page-link', $link) . '</li>';
                                            }
                                        }
                                        echo '</ul>';
                                    }
                                    ?>
                                </nav>
                            </div>
                        </div>
                    <?php endif; ?>
                    <!-- Pagination End -->
                </div>
            </div>
        <?php 
            wp_reset_postdata();
            $active_tab_set = true;
        endif;

        // Other categories tabs content
        foreach ($categories as $category) :
            if (!empty($selected_categories) && !in_array($category->slug, $selected_categories)) {
                continue;
            }

            $args = [
                'post_type'      => 'renev_project',
                'posts_per_page' => $posts_per_page,
                'paged'          => max(1, get_query_var('paged')),
                'tax_query'      => [['taxonomy' => 'project_category', 'field' => 'term_id', 'terms' => $category->term_id]],
            ];

            if ('selected' === ($settings['post_by'] ?? '') && !empty($settings['post__in'])) {
                $args['post__in'] = (array) $settings['post__in'];
                $args['orderby'] = 'post__in';
            }

            $query = new WP_Query($args);
            if (!$query->have_posts()) {
                wp_reset_postdata();
                continue;
            }
        ?>
            <div class="tab-pane fade" 
                 id="pills-<?php echo esc_attr($category->slug); ?>" 
                 role="tabpanel" 
                 aria-labelledby="tab-<?php echo esc_attr($category->slug); ?>">
                <div class="all-project-area">
                    <div class="row">
                        <?php while ($query->have_posts()) : $query->the_post(); ?>
                            <div class="col-lg-6 col-md-6">
                                <div class="portfolio-boxarea">
                                    <?php if (has_post_thumbnail()) : ?>
                                        <div class="img1"><?php the_post_thumbnail('full'); ?></div>
                                    <?php endif; ?>
                                    <div class="arrow-content">
                                        <div class="arrow">
                                            <a href="<?php the_permalink(); ?>">
                                                <span><i class="fa-solid fa-arrow-right"></i></span>
                                            </a>
                                        </div>
                                        <div class="content-area">
                                            <?php 
                                                if (has_excerpt()) {
                                                    the_excerpt();
                                                } 
                                            ?>
                                            <a href="<?php the_permalink(); ?>"><?php the_title(); ?></a>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        <?php endwhile; ?>

                        <!-- Pagination Start -->
                        <?php if ('yes' === ($settings['show_pagination'] ?? '') && $query->max_num_pages > 1) : ?>
                            <div class="col-lg-12">
                                <div class="space50"></div>
                                <div class="pagination-area">
                                    <nav aria-label="Page navigation example">
                                        <?php
                                        $big = 999999999;

                                        $pagination_links = paginate_links([
                                            'base'      => str_replace($big, '%#%', esc_url(get_pagenum_link($big))),
                                            'format'    => '?paged=%#%',
                                            'current'   => max(1, get_query_var('paged')),
                                            'total'     => $query->max_num_pages,
                                            'prev_text' => '<i class="fa-solid fa-angle-left"></i>',
                                            'next_text' => '<i class="fa-solid fa-angle-right"></i>',
                                            'type'      => 'array',
                                        ]);

                                        if (is_array($pagination_links)) {
                                            echo '<ul class="pagination justify-content-center">';
                                            foreach ($pagination_links as $link) {
                                                if (strpos($link, 'current') !== false) {
                                                    echo '<li class="page-item"><a class="page-link active">' . strip_tags($link) . '</a></li>';
                                                } else {
                                                    echo '<li class="page-item">' . str_replace('page-numbers', 'page-link', $link) . '</li>';
                                                }
                                            }
                                            echo '</ul>';
                                        }
                                        ?>
                                    </nav>
                                </div>
                            </div>
                        <?php endif; ?>
                        <!-- Pagination End -->
                    </div>
                </div>
            </div>
            <?php 
            wp_reset_postdata();
        endforeach; 
        ?>
    </div>
</div>
