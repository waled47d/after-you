<div class="heading1">
    <div class="counter-boxarea">
        <?php foreach ($counter_list as $index => $counter) : ?>
            <div class="counter-box">
                <h2>
                    <span class="counter">
                        <?php echo renev_kses($counter['counter_number']); ?>
                    </span>
                    <?php echo renev_kses($counter['counter_suffix']); ?>
                </h2>
                <p>
                    <?php echo renev_kses($counter['counter_title']); ?>
                </p>
            </div>
            <?php if ($index < count($counter_list) - 1) : ?>
                <span class="border"> | </span>
            <?php endif; ?>
        <?php endforeach; ?>
    </div>
</div>
