<div class="row">
    <?php if ($the_query->have_posts()) {
        while ($the_query->have_posts()) {
            $the_query->the_post();
            $excerpt = (isset($settings['excerpt_limit']['size']) && $settings['excerpt_limit']['size']) 
                        ? wp_trim_words(get_the_excerpt(), $settings['excerpt_limit']['size'], '') 
                        : get_the_excerpt();
        ?>
        <div class="col-lg-4 col-md-6">
            <div class="blog1">
                <div class="vl-blog-1-item">
                    <?php if( $settings['show_image'] == 'yes' ): ?>
                        <?php if( has_post_thumbnail() ): ?>
                            <div class="vl-blog-1-thumb image-anime">
                                <?php the_post_thumbnail('full');?>
                            </div>
                        <?php endif; ?>
                    <?php endif; ?>
                    <div class="vl-blog-1-content">
                        <?php if( $settings['show_date'] == 'yes' ): ?>
                            <div class="vl-blog-meta">
                            <?php
                                $date_day = get_the_time('j'); // Day of the month (e.g., 20)
                                $date_month = get_the_time('F'); // Full month name (e.g., December)
                                $date_year = get_the_time('Y'); // Year (e.g., 2024)
                            ?>
                                <ul>
                                    <li>
                                        <a href="<?php the_permalink(); ?>">
                                            <img src="<?php echo esc_url( $settings['meta_img']['url'] ); ?>" alt="">
                                            <?php echo esc_html(strtoupper($date_day)); ?>
                                            <?php echo esc_html(strtoupper($date_month)); ?>
                                            <?php echo esc_html(strtoupper($date_year)); ?>
                                        </a>
                                    </li>
                                    <li>
                                        <a href="<?php echo get_author_posts_url(get_the_author_meta('ID')); ?>">
                                        <img src="<?php echo esc_url( $settings['meta_author_img']['url'] ); ?>" alt="">
                                            <?php the_author(); ?>
                                        </a>
                                    </li>
                                </ul>
                        
                            </div>
                        <?php endif; ?>
                        <h4 class="vl-blog-1-title">
                            <a href="<?php the_permalink(); ?>">
                                <?php the_title(); ?>
                            </a>
                        </h4>
                        <div class="vl-blog-1-icon">
                            <a href="<?php the_permalink(); ?>">
                                <?php echo esc_html( $settings['btn_text'] ); ?>
                                <i class="fa-solid fa-arrow-right"></i>
                            </a>
                        </div>
                    </div>
                </div>
            </div>
        </div>

        
        <?php
        }
        // Restore original Post Data.
        wp_reset_postdata();
        }
    ?>

    <!-- Pagination Start -->
    <?php if ('yes' === ($settings['show_pagination'] ?? '') && $the_query->max_num_pages > 1) : ?>
        <div class="col-lg-12">
            <div class="space50"></div>
            <div class="pagination-area">
                <nav aria-label="Page navigation example">
                    <?php
                    $big = 999999999;

                    $pagination_links = paginate_links([
                        'base'      => str_replace($big, '%#%', esc_url(get_pagenum_link($big))),
                        'format'    => '?paged=%#%',
                        'current'   => max(1, get_query_var('paged')),
                        'total'     => $the_query->max_num_pages,
                        'prev_text' => '<i class="fa-solid fa-angle-left"></i>',
                        'next_text' => '<i class="fa-solid fa-angle-right"></i>',
                        'type'      => 'array',
                    ]);

                    if (is_array($pagination_links)) {
                        echo '<ul class="pagination justify-content-center">';
                        foreach ($pagination_links as $link) {
                            if (strpos($link, 'current') !== false) {
                                echo '<li class="page-item"><a class="page-link active">' . strip_tags($link) . '</a></li>';
                            } else {
                                echo '<li class="page-item">' . str_replace('page-numbers', 'page-link', $link) . '</li>';
                            }
                        }
                        echo '</ul>';
                    }
                    ?>
                </nav>
            </div>
        </div>
    <?php endif; ?>
    <!-- Pagination End -->
</div>