<!doctype html>
<html <?php language_attributes(); ?>>
<head>
    <meta charset="<?php bloginfo('charset'); ?>">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <?php wp_head();?>
</head>
<body <?php body_class(); ?>>

<?php
    wp_body_open();

    /**
    *
    * Preloader
    *
    * Hook renev_preloader_wrap
    *
    * @Hooked renev_preloader_wrap_cb 10
    *
    */
    do_action( 'renev_preloader_wrap' );

    /**
    *
    * Cursor
    *
    * Hook renev_cursor_wrap
    *
    * @Hooked renev_cursor_wrap_cb 10
    *
    */
    do_action( 'renev_cursor_wrap' );

    /**
    *
    * Back to top
    *
    * Hook renev_back_to_top_wrap
    *
    * @Hooked renev_back_to_top_wrap_cb 10
    *
    */
    do_action( 'renev_back_to_top_wrap' );

    /**
    *
    * renev header
    *
    * Hook renev_header
    *
    * @Hooked renev_header_cb 10
    *
    */
    do_action( 'renev_header' );