<?php

use Elementor\Widget_Base;
use Elementor\Controls_Manager;
use Elementor\Group_Control_Typography;
use Elementor\Group_Control_Text_Shadow;
use Elementor\Core\Kits\Documents\Tabs\Global_Colors;
use Elementor\Core\Kits\Documents\Tabs\Global_Typography;

if ( !defined( 'ABSPATH' ) ) {
    exit;
}
/**
 * Elementor oEmbed Widget.
 *
 * Elementor widget that inserts an embbedable content into the page, from any given URL.
 *
 * @since 1.0.0
 */
class Post_Navigation extends \Elementor\Widget_Base
{
    /**
     * Get widget name.
     *
     * Retrieve oEmbed widget name.
     *
     * @since 1.0.0
     * @access public
     *
     * @return string Widget name.
     */
    public function get_name()
    {
        return 'renev-post-navigation';
    }
    /**
     * Get widget title.
     *
     * Retrieve oEmbed widget title.
     *
     * @since 1.0.0
     * @access public
     *
     * @return string Widget title.
     */
    public function get_title()
    {
        return __('Post Navigation', 'renev');
    }
    /**
     * Get widget icon.
     *
     * Retrieve oEmbed widget icon.
     *
     * @since 1.0.0
     * @access public
     *
     * @return string Widget icon.
     */
    public function get_icon()
    {
        return 'eicon-code';
    }
    /**
     * Get widget categories.
     *
     * Retrieve the list of categories the oEmbed widget belongs to.
     *
     * @since 1.0.0
     * @access public
     *
     * @return array Widget categories.
     */
    public function get_categories()
    {
        return ['renev'];
    }
    /**
     * Register oEmbed widget controls.
     *
     * Adds different input fields to allow the user to change and customize the widget settings.
     *
     * @since 1.0.0
     * @access protected
     */
    protected function register_controls() {
        /**
         * Style tab
         */
        $this->start_controls_section(
            'general',
            [
                'label' => __('Style', 'renev'),
                'tab' => \Elementor\Controls_Manager::TAB_STYLE,
            ]
        );
        $this->add_control(
            'title_color',
            [
                'label' => __( 'Color', 'renev' ),
                'type' => Controls_Manager::COLOR,
                'selectors' => [
                    '{{WRAPPER}} .inner__page-nav .text-wrap' => 'color: {{VALUE}}',
                ],
            ]
        );
        $this->add_control(
            'title_hover_color',
            [
                'label' => __( 'Hover Color', 'renev' ),
                'type' => Controls_Manager::COLOR,
                'selectors' => [
                    '{{WRAPPER}} .inner__page-nav .text-wrap:hover' => 'color: {{VALUE}}',
                ],
            ]
        );
        $this->add_group_control(
            Group_Control_Typography::get_type(),
            [
                'name' => 'title_typography',
                'selector' => '{{WRAPPER}} .inner__page-nav .text-wrap',
            ]
        ); 
        $this->add_responsive_control(
			'image_size',
			[
				'label' => __( 'Image Size', 'renev' ),
				'type' => Controls_Manager::SLIDER,
				'size_units' => [ 'px' ],
				'range' => [
					'px' => [
						'min' => 0,
						'max' => 1000,
						'step' => 1,
					]
				],
				'selectors' => [
					'{{WRAPPER}} .inner__page-nav .text-wrap .thumb img' => 'width: {{SIZE}}{{UNIT}}; height: {{SIZE}}{{UNIT}};',
				],
			]
		);
        $this->add_control(
            'image_border_radius',
            [
                'label' => __( 'Border Radius', 'renev' ),
                'type' => Controls_Manager::DIMENSIONS,  
                'size_units' => [ 'px', 'em', '%' ],  
                'selectors' => [
                    '{{WRAPPER}} .inner__page-nav .text-wrap .thumb img' => 'border-radius: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
                ],
            ]
        );
        $this->end_controls_section();

    }
    /**
     * Render oEmbed widget output on the frontend.
     *
     * Written in PHP and used to generate the final HTML.
     *
     * @since 1.0.0
     * @access protected
     */
    protected function render() {
        $settings = $this->get_settings_for_display();

        // Get previous and next posts
        $previous_post = get_previous_post();
        $next_post = get_next_post();

        ?>
            <div class="inner__page-nav">
                <?php if ($previous_post): ?>
                    <a href="<?php echo get_permalink(get_previous_post()->ID); ?>" class="nav-btn text-md-end">
                        <div class="text-wrap mb-0">
                            <?php if (has_post_thumbnail($previous_post->ID)): ?>
                                <div class="thumb">
                                    <?php echo get_the_post_thumbnail($previous_post->ID, 'thumbnail', ['alt' => get_the_title($previous_post->ID)]); ?>
                                </div> 
                            <?php endif; ?>
                            <span>
                                <?php echo esc_html(get_the_title($previous_post->ID)); ?>
                            </span>
                        </div>
                    </a> 
                <?php endif; ?>

                <?php if ($next_post): ?>
                    <a href="<?php echo get_permalink(get_next_post()->ID); ?>" class="nav-btn">
                        <div class="text-wrap mb-0">
                            <span>
                                <?php echo esc_html(get_the_title($next_post->ID)); ?>
                            </span>
                            <?php if (has_post_thumbnail($next_post->ID)): ?>
                                <div class="thumb">
                                    <?php echo get_the_post_thumbnail($next_post->ID, 'thumbnail', ['alt' => get_the_title($next_post->ID)]); ?>
                                </div> 
                            <?php endif; ?>
                        </div>
                    </a>
                <?php endif; ?>
            </div>   
        <?php
    }


}


$widgets_manager->register( new \Post_Navigation() );