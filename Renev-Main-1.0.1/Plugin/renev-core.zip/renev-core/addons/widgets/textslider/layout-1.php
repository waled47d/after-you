
<div class="slider1-section-area">
    <div class="marquee-wrap">
        <div class="marquee-text">
            <?php foreach ( $slider_lists as $item ): ?>
                <?php if ( $counter >= $max_items ) break; ?>
                    <div class="brand-single-box">
                        <h3>
                            <?php echo esc_html( $item['slider_text'] ); ?> 
                            <img src="<?php echo esc_url( $item['slider_icon']['url'] ); ?>" alt="">
                        </h3>
                    </div>
                <?php $counter++; ?>
            <?php endforeach; ?>
        </div>
    </div>
</div>
