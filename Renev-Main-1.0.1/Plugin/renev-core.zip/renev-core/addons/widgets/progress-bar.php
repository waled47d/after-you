<?php
use \Elementor\Widget_Base;
use \Elementor\Controls_Manager;
use \Elementor\Group_Control_Typography;
use \Elementor\Group_Control_Border;
use \Elementor\Group_Control_Box_Shadow;
use \Elementor\Repeater;
use \Elementor\Utils;
use \Elementor\Group_Control_Background;

/**
 * Renev Progress Bar Widget.
 */
class Renev_Progress_Bar extends Widget_Base {

	public function get_name() {
		return 'renev_progress_bar';
	}

	public function get_title() {
		return __( 'Renev Progress Bar', 'renev' );
	}

	public function get_icon() {
		return 'eicon-code';
	}

	public function get_categories() {
		return [ 'progress' ];
	}

	protected function register_controls() {
        // Content Section
        $this->start_controls_section(
            'skills_section',
            [
                'label' => __( 'Skills Content', 'renev' ),
                'tab'   => Controls_Manager::TAB_CONTENT,
            ]
        );
        $this->add_control(
            'progress_layout',
            [
                'label' => esc_html__('Select Layout', 'renev'),
                'type' => Controls_Manager::SELECT,
                'options' => [
                    'layout-1' => esc_html__('Layout 1', 'renev'),
                    'layout-2' => esc_html__('Layout 2', 'renev'),
                ],
                'default' => 'layout-1',
            ]
        );
        $this->add_control(
            'progress_column',
            [
                'label' => esc_html('Progress Column', 'renev'),
                'type' => Controls_Manager::SELECT,
                'options' => [
                    '6' => esc_html('Column 6', 'renev'),
                    '4' => esc_html__('Column 4', 'renev'),
                ],
                'default' => '6',
                'condition' => [
                    'progress_layout' => 'layout-2',
                ]
            ]
        );
        $repeater = new Repeater();

        $repeater->add_control(
            'skill_name',
            [
                'label'       => __( 'Skill Name', 'renev' ),
                'type'        => Controls_Manager::TEXT,
                'default'     => __( 'User Interface Designer ', 'renev' ),
                'label_block' => true,
            ]
        );
        $repeater->add_control(
            'skill_value',
            [
                'label'       => __( 'Skill Percentage', 'renev' ),
                'type'        => Controls_Manager::SLIDER,
                'default'     => [
                    'size' => 50,
                ],
                'range'       => [
                    'px' => [
                        'min' => 0,
                        'max' => 100,
                    ],
                ],
            ]
        );
        $this->add_control(
            'skills',
            [
                'label'       => __( 'Skills List', 'renev' ),
                'type'        => Controls_Manager::REPEATER,
                'fields'      => $repeater->get_controls(),
                'default'     => [
            
                ],
                'title_field' => '{{{ skill_name }}} - {{{ skill_value.size }}}%',
            ]
        );
        $this->end_controls_section();

        //Progress bar Box Style 
		$this->start_controls_section(
			'progress_bar_box_style',
			[
				'label' => __( 'Box Style', 'renev' ),
				'tab'   => Controls_Manager::TAB_STYLE,
                'condition' => [
                    'progress_layout' => 'layout-1',
                ]
			]
		);
	
        $this->add_control(
            'progress_bar_box_padding',
            [
                'label'      => __( 'Box Padding', 'renev' ),
                'type'       => Controls_Manager::DIMENSIONS,
                'size_units' => [ 'px', '%', 'em' ],
                'selectors'  => [
                    '{{WRAPPER}} .about1-section-area .about-header .bg-progress' => 'padding: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
                ],
            ]
        );        
		$this->add_control(
			'progress_bar_box_background',
			[
				'label'     => __( 'Box Background', 'renev' ),
				'type'      => Controls_Manager::COLOR,
				'selectors' => [
					'{{WRAPPER}} .about1-section-area .about-header .bg-progress' => 'background-color: {{VALUE}};',
				],
			]
		);
        $this->add_responsive_control(
            'progress_bar_box_radius',
            [
                'label'         => __( 'Border Radius', 'renev' ),
                'type'          => Controls_Manager::DIMENSIONS,
                'size_units'    => [ 'px', '%', 'em' ],
                'selectors'     => [
                    '{{WRAPPER}} .about1-section-area .about-header .bg-progress' => 'border-radius: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
                ],
            ]
        );
        $this->add_control(
            'progress_bar_box_margin',
            [
                'label'      => __( 'Box Margin', 'renev' ),
                'type'       => Controls_Manager::DIMENSIONS,
                'size_units' => [ 'px', '%', 'em' ],
                'selectors'  => [
                    '{{WRAPPER}} .about1-section-area .about-header .bg-progress .progress-bar' => 'margin: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
                ],
            ]
        ); 
        $this->end_controls_section();

		// Skill Name Color
        $this->start_controls_section(
			'skills_style',
			[
				'label' => __( 'Skills Section', 'renev' ),
				'tab'   => Controls_Manager::TAB_STYLE,
			]
		);
        $this->add_responsive_control(
            'progressbar_gap',
            [
                'label' => __( 'Progress Bar Gap', 'renev' ),
                'type' => \Elementor\Controls_Manager::SLIDER,
                'size_units' => [ 'px', 'em' ],
                'range' => [
                    'px' => [
                        'min' => 0,
                        'max' => 100,
                    ],
                    'em' => [
                        'min' => 0,
                        'max' => 10,
                    ],
                ],
                'selectors' => [
                    '{{WRAPPER}}  .row.gap' => 'gap: {{SIZE}}{{UNIT}};',
                ],
                'condition' => [
                    'progress_layout' => 'layout-2',
                ]
            ]
        );
		$this->add_control(
			'skill_name_color',
			[
				'label'     => __( 'Skill Name Color', 'renev' ),
				'type'      => Controls_Manager::COLOR,
				'selectors' => [
					'{{WRAPPER}} .about1-section-area .about-header .bg-progress label' => 'color: {{VALUE}};',
                    '{{WRAPPER}} .progresbar .content-area h4' => 'color: {{VALUE}};',
                    '{{WRAPPER}} .progresbar .progressbar .count' => 'color: {{VALUE}};',
				],
			]
		);
        $this->add_group_control(
            Group_Control_Typography::get_type(),
            [
                'name' => 'skill_name_typography',
                'label' => __( 'Typography', 'renev' ),
                'selector' => '{{WRAPPER}} .about1-section-area .about-header .bg-progress label, {{WRAPPER}} .progresbar .content-area h4, {{WRAPPER}} .progresbar .progressbar .count',
            ]
        );
        $this->add_responsive_control(
            'skill_name_margin',
            [
                'label' => __( 'Slider Icon Margin', 'renev' ),
                'type' => Controls_Manager::DIMENSIONS,
                'size_units' => [ 'px', 'em', '%' ],
                'selectors' => [
                    '{{WRAPPER}} .about1-section-area .about-header .bg-progress label' => 'margin: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
                    '{{WRAPPER}} .progresbar .content-area' => 'margin: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
                ],
            ]
        );
        
        $this->end_controls_section();

		// Progress Bar Height
        $this->start_controls_section(
			'progress_style',
			[
				'label' => __( 'Progress Bar', 'renev' ),
				'tab'   => Controls_Manager::TAB_STYLE,
                'condition' => [
                    'progress_layout' => 'layout-1',
                ]
			]
		);
		$this->add_control(
			'progress_bar_height',
			[
				'label'     => __( 'Progress Bar Height', 'renev' ),
				'type'      => Controls_Manager::SLIDER,
				'range'     => [
					'px' => [
						'min' => 3,
						'max' => 50,
					],
				],
				'selectors' => [
					'{{WRAPPER}} .about1-section-area .about-header .bg-progress .progress' => 'height: {{SIZE}}px;',
				],
			]
		);
        $this->add_control(
            'progress_bar_background',
            [
                'label'     => __( 'Progress Background', 'renev' ),
                'type'      => \Elementor\Controls_Manager::COLOR,
                'selectors' => [
                    '{{WRAPPER}} .about1-section-area .about-header .bg-progress .progress' => 'background: {{VALUE}};',
                ],
            ]
        );        
        $this->add_responsive_control(
            'progress_bar_radius',
            [
                'label'         => __( 'Border Radius', 'renev' ),
                'type'          => Controls_Manager::DIMENSIONS,
                'size_units'    => [ 'px', '%', 'em' ],
                'selectors'     => [
                    '{{WRAPPER}} .about1-section-area .about-header .bg-progress .progress' => 'border-radius: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
                ],
            ]
        );

        //progress bar inner style
        $this->add_group_control(
            Group_Control_Background::get_type(),
            [
                'name' => 'progress_bar_inner_background',
                'label' => __( 'Progress Inner Background', 'renev' ),
                'types' => [ 'classic', 'gradient', 'video' ],
                'selector' => '{{WRAPPER}} .about1-section-area .about-header .bg-progress .progress-inner',
            ]
        );       
        $this->add_responsive_control(
            'progress_bar_inner_radius',
            [
                'label'         => __( 'Border Inner Radius', 'renev' ),
                'type'          => Controls_Manager::DIMENSIONS,
                'size_units'    => [ 'px', '%', 'em' ],
                'selectors'     => [
                    '{{WRAPPER}} .about1-section-area .about-header .bg-progress .progress-inner' => 'border-radius: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
                ],
            ]
        );
		$this->end_controls_section();
	}

	// Render Function
    protected function render() {
        $settings = $this->get_settings_for_display();
        $layout = $settings['progress_layout'];
        $progress_list = $settings['skills'];
        
    	?>
            <?php
                if ( $layout) {
                    include('progress/'.$layout.'.php');
                }
            ?> 
		<?php
    }    
}

// Register the widget
$widgets_manager->register( new \Renev_Progress_Bar() );
