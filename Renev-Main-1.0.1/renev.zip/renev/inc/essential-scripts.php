<?php
/**
 * @Packge     : Renev
 * @Version    : 1.0
 * @Author     : Mthemeus
 * @Author URI : https://www.mthemeus.com/
 *
 */

// Block direct access
if ( ! defined( 'ABSPATH' ) ) {
    exit;
}

/**
 * Enqueue scripts and styles.
 */
function renev_essential_scripts() {

	

    // google font
    wp_enqueue_style( 'renev-fonts', renev_google_fonts() ,array(), wp_get_theme()->get( 'Version' ) );

    // aos css
    wp_enqueue_style( 'aos', get_theme_file_uri( '/assets/css/aos.css' ) ,array(), wp_get_theme()->get( 'Version' ) );

    // Bootstrap 
    wp_enqueue_style( 'bootstrap.min', get_theme_file_uri( '/assets/css/bootstrap.min.css' ) ,array(), '5.2.0' );

    // fontawesome
    wp_enqueue_style( 'fontawesome-all.min', get_theme_file_uri( '/assets/css/fontawesome.css' ) ,array(), '6.4.2' );

    // magnific popup css
    wp_enqueue_style( 'magnific-popup', get_theme_file_uri( '/assets/css/magnific-popup.css' ) ,array(), wp_get_theme()->get( 'Version' ) );
    
    // owlcarousel
    wp_enqueue_style( 'owlcarousel-css', get_theme_file_uri( '/assets/css/owlcarousel.min.css' ) ,array(), '2.3.4' );

    // Sidebar css
    wp_enqueue_style( 'sidebar-css', get_theme_file_uri( '/assets/css/sidebar.css' ) ,array(), '3.0.6' );
   
    // nice select css
    wp_enqueue_style( 'nice-select', get_theme_file_uri( '/assets/css/nice-select.css' ) ,array(), wp_get_theme()->get( 'Version' ) );

    // Slisk slider css
    wp_enqueue_style( 'slick-slider', get_theme_file_uri( '/assets/css/slick-slider.css' ) ,array(), wp_get_theme()->get( 'Version' ) );
    
    // Swiper Bundle css
    wp_enqueue_style( 'swiper-bundle-css', get_theme_file_uri( '/assets/css/swiper-bundle.css' ) ,array(), '11.1.15' );

    // blog-default.css
    wp_enqueue_style( 'blog-default.css', get_theme_file_uri('/assets/css/blog-default.css') ,array(), wp_get_theme()->get( 'Version' ) );

    // default.css
    wp_enqueue_style( 'default.css', get_theme_file_uri('/assets/css/default.css') ,array(), wp_get_theme()->get( 'Version' ) );

    // renev-custom.css
    wp_enqueue_style( 'renev-custom.css', get_theme_file_uri('/assets/css/renev-custom.css') ,array(), wp_get_theme()->get( 'Version' ) );

    // renev-unit.css
    wp_enqueue_style( 'renev-unit.css', get_theme_file_uri('/assets/css/renev-unit.css') ,array(), wp_get_theme()->get( 'Version' ) );

    // renev main style
    wp_enqueue_style( 'renev-main-style', get_theme_file_uri('/assets/css/main.css') ,array(), wp_get_theme()->get( 'Version' ) );

    wp_enqueue_style( 'renev-style', get_stylesheet_uri() ,array(), wp_get_theme()->get( 'Version' ) );

    
    // Load Js =====

    // bootstrap
    wp_enqueue_script( 'bootstrap.min', get_theme_file_uri( '/assets/js/bootstrap.min.js' ), array( 'jquery' ), '5.2.0', true );

    // aos Js
    wp_enqueue_script( 'aos', get_theme_file_uri( '/assets/js/aos.js' ), array('jquery'), wp_get_theme()->get( 'Version' ), true );

    // circle progres Js
    wp_enqueue_script( 'circle-progress', get_theme_file_uri( '/assets/js/circle-progress.js' ), array( 'jquery' ), '1.2.2', true );
    
    // Counter Js
    wp_enqueue_script( 'counter', get_theme_file_uri( '/assets/js/counter.js' ), array( 'jquery' ), '1.0.3', true );

    // Fontwesome Js
    wp_enqueue_script( 'fontawesome', get_theme_file_uri( '/assets/js/fontawesome.js' ), array( 'jquery' ), '6.4.2', true );

    // Gsap Js
    wp_enqueue_script( 'gsap.min', get_theme_file_uri( '/assets/js/gsap.min.js' ), array( 'jquery' ), '3.11.2', true );
    
    // jquery.magnific-popup.min
    wp_enqueue_script( 'jquery.magnific-popup.min', get_theme_file_uri( '/assets/js/magnific-popup.js' ), array( 'jquery' ), '1.1.0', true );

    //nice-select.js
    wp_enqueue_script( 'nice-select', get_theme_file_uri( '/assets/js/nice-select.js' ), array( 'jquery' ), '1.1.0', true );

    //owlcarousel.min.js
    wp_enqueue_script( 'owlcarousel.min.js', get_theme_file_uri( '/assets/js/owlcarousel.min.js' ), array( 'jquery' ), '2.3.4', true );

    // ScrollTrigger.min
    wp_enqueue_script( 'ScrollTrigger.min', get_theme_file_uri( '/assets/js/ScrollTrigger.min.js' ), array( 'jquery' ), '3.11.2', true );

    // Sidbar-js
    wp_enqueue_script( 'siodebar-js', get_theme_file_uri( '/assets/js/sidebar.js' ), array( 'jquery' ), '3.0.6', true );

    // slick-slider.js
    wp_enqueue_script( 'slick-slider.js', get_theme_file_uri( '/assets/js/slick-slider.js' ), array('jquery'), wp_get_theme()->get( 'Version' ), true );

    // SmoothScroll.js
    wp_enqueue_script( 'smoothScroll.js', get_theme_file_uri( '/assets/js/SmoothScroll.js' ), array( 'jquery' ), '1.4.10', true );

    // Splitetext.js
    wp_enqueue_script( 'splitetext-js', get_theme_file_uri( '/assets/js/Splitetext.js' ), array( 'jquery' ), '3.6.1', true );

    // swiper.js
    wp_enqueue_script( 'swiper-js', get_theme_file_uri( '/assets/js/swiper.js' ), array( 'jquery' ), '11.0.5', true );

    // waypoints.js
    wp_enqueue_script( 'waypoints.js', get_theme_file_uri( '/assets/js/waypoints.js' ), array( 'jquery' ), '4.0.0', true );

    // main js
    wp_enqueue_script( 'main-js', get_theme_file_uri( '/assets/js/main.js' ), array('jquery'), wp_get_theme()->get( 'Version' ), true );

    // comment reply
	if ( is_singular() && comments_open() && get_option( 'thread_comments' ) ) {
		wp_enqueue_script( 'comment-reply' );
	}
}
add_action( 'wp_enqueue_scripts', 'renev_essential_scripts',99 );


function renev_block_editor_assets( ) {
    // Add custom fonts.
	wp_enqueue_style( 'renev-editor-fonts', renev_google_fonts(), array(), null );
}

add_action( 'enqueue_block_editor_assets', 'renev_block_editor_assets' );
 
function renev_google_fonts() {
    $font_families = array(
        'Space Grotesk:300,400,500,600,700,800',
        'Figtree:300,400,500,600,700,800',
    );

    $familyArgs = array(
        'family' => urlencode( implode( '|', $font_families ) ),
        'subset' => urlencode( 'latin,latin-ext' ),
    );

    $fontUrl = add_query_arg( $familyArgs, '//fonts.googleapis.com/css' );

    return esc_url_raw( $fontUrl );
}