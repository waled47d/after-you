<div class="about-images-area">
    <img src="<?php echo esc_url( $settings['circle_icon_img']['url'] ); ?>" alt="" class="elements13 keyframe5">
</div>